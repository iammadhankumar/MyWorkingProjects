package nutrimeals.views;



import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="view_product")
@Immutable
public class ProductView {
	
	@Id
	@JsonIgnore
	private long pkey;
	
	private long id;
	
	private float price;
	
	private String productDescription;
	
	private  String productId;
	
	private String productImage;
	
	private String productName;
	
	private String preparationMethod;
	
	private String allIngredients;
	
	private long productType;
	
	private String calories;
	
	private String protein;
	
	private String sodium;
	
	private String fat;
	
	private String fiber;
	
	private String sugar;
	
	private long kid;
	
	private long StockQuantity;
	


	public long getPkey() {
		return pkey;
	}

	public void setPkey(long pkey) {
		this.pkey = pkey;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getPreparationMethod() {
		return preparationMethod;
	}

	public void setPreparationMethod(String preparationMethod) {
		this.preparationMethod = preparationMethod;
	}

	public String getAllIngredients() {
		return allIngredients;
	}

	public void setAllIngredients(String allIngredients) {
		this.allIngredients = allIngredients;
	}


	public long getProductType() {
		return productType;
	}

	public void setProductType(long productType) {
		this.productType = productType;
	}

	public String getCalories() {
		return calories;
	}

	public void setCalories(String calories) {
		this.calories = calories;
	}

	public String getProtein() {
		return protein;
	}

	public void setProtein(String protein) {
		this.protein = protein;
	}

	public String getSodium() {
		return sodium;
	}

	public void setSodium(String sodium) {
		this.sodium = sodium;
	}

	public String getFat() {
		return fat;
	}

	public void setFat(String fat) {
		this.fat = fat;
	}

	public String getFiber() {
		return fiber;
	}

	public void setFiber(String fiber) {
		this.fiber = fiber;
	}

	public String getSugar() {
		return sugar;
	}

	public void setSugar(String sugar) {
		this.sugar = sugar;
	}



	public long getStockQuantity() {
		return StockQuantity;
	}

	public void setStockQuantity(long stockQuantity) {
		StockQuantity = stockQuantity;
	}

	public long getKid() {
		return kid;
	}

	public void setKid(long kid) {
		this.kid = kid;
	}




}
