package nutrimeals.views;

import java.util.Date;
import java.util.HashMap;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Immutable;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="view_kiosk")
@Immutable
public class KioskView {
	
	@Id
	private long id;
	
	private boolean active;
	
	private long kioskId;
	
	private String kioskName;
	
	private double latitude;
	
	private double longitude;
	
	private String address;
	
	private Date startTime;
	
	private Date endTime;
	
	@Transient
	private HashMap<String,Double> coordinate;
	
	@Transient
	@JsonIgnore
	private String miles;


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public long getKioskId() {
		return kioskId;
	}

	public void setKioskId(long kioskId) {
		this.kioskId = kioskId;
	}

	public String getKioskName() {
		return kioskName;
	}

	public void setKioskName(String kioskName) {
		this.kioskName = kioskName;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	
	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public HashMap<String, Double> getCoordinate() {
		return coordinate;
	}



	public void setCoordinate(HashMap<String, Double> coordinate) {
		this.coordinate = coordinate;
	}
	
	
	public String getMiles() {
		return miles;
	}

	public void setMiles(String miles) {
		this.miles = miles;
	}

}
