package nutrimeals.customdomain;

public class Product_Kiosk_Input {
	 
	 //private long id;
	
	 //private String productName;
	
	 private long quantity;
	 
	 private String profileimage;
	 
	 private String price;
	 
	 private long kiosk_id;
		
	 private long primaryProductId;

	 
//	 public String getProductName() {
//		 return productName;
//		}
//
//		public void setProductName(String productName) {
//			this.productName = productName;
//		}
//		
		
		public long getQuantity() {
			return quantity;
		}

		public void setQuantity(long quantity) {
			this.quantity = quantity;
		}
	 
		
		
		public String getProfileimage() {
			return profileimage;
		}

		public void setProfileimage(String profileimage) {
			this.profileimage = profileimage;
		}
		
		
		
		
		public String getPrice() {
			return price;
		}

		public void setPrice(String price) {
			this.price = price;
		}
		
		
		public long getKiosk_id() {
			return kiosk_id;
		}

		public void setKiosk_id(long kiosk_id) {
			this.kiosk_id = kiosk_id;
		}

		public long getPrimaryProductId() {
			return primaryProductId;
		}

		public void setPrimaryProductId(long primaryProductId) {
			this.primaryProductId = primaryProductId;
		}

		
	
 

		
}
