package nutrimeals.customdomain;

import java.util.List;

import nutrimeals.domain.DietaryPreference;

public class UserProfileInput {
	
	private String primaryLocation;
	
	private List<DietaryPreference> dietaryId;
	
	private String foodAllergies;
	
	private boolean locationService;
	
	private String creditCardName;
	
	private String creditCardNumber;
	
	private String zipCode;
	
	private String securityCode;

	public String getPrimaryLocation() {
		return primaryLocation;
	}

	public void setPrimaryLocation(String primaryLocation) {
		this.primaryLocation = primaryLocation;
	}

	public List<DietaryPreference> getDietaryId() {
		return dietaryId;
	}

	public void setDietaryId(List<DietaryPreference> dietaryId) {
		this.dietaryId = dietaryId;
	}

	public String getFoodAllergies() {
		return foodAllergies;
	}

	public void setFoodAllergies(String foodAllergies) {
		this.foodAllergies = foodAllergies;
	}

	public boolean isLocationService() {
		return locationService;
	}

	public void setLocationService(boolean locationService) {
		this.locationService = locationService;
	}

	public String getCreditCardName() {
		return creditCardName;
	}

	public void setCreditCardName(String creditCardName) {
		this.creditCardName = creditCardName;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getSecurityCode() {
		return securityCode;
	}

	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	}

}
