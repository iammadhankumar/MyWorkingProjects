package nutrimeals.customdomain;

import java.util.List;

import nutrimeals.domain.DietaryPreference;

public class SignupDomain {
	
	
	String firstName;
	
	String lastName;
	
	String email;
	long kioskId;
	
	
	String password;
	 
	boolean termsAndCondition;
	
	boolean subscribe;
	
	long userType;
	
	private List<DietaryPreference> userDietaryPreference;
	
	private String foodAllergies;
	
	private String  primaryLocation;
	

	private String dob;




	public String getFoodAllergies() {
		return foodAllergies;
	}

	public void setFoodAllergies(String foodAllergies) {
		this.foodAllergies = foodAllergies;
	}

	public String getPrimaryLocation() {
		return primaryLocation;
	}

	public void setPrimaryLocation(String primaryLocation) {
		this.primaryLocation = primaryLocation;
	}

	public long getUserType() {
		return userType;
	}

	public void setUserType(long userType) {
		this.userType = userType;
	}

	public boolean isSubscribe() {
		return subscribe;
	}

	public void setSubscribe(boolean subscribe) {
		this.subscribe = subscribe;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isTermsAndCondition() {
		return termsAndCondition;
	}

	public void setTermsAndCondition(boolean termsAndCondition) {
		this.termsAndCondition = termsAndCondition;
	}
	
	public long getKioskId() {
		return kioskId;
	}

	public void setKioskId(long kioskId) {
		this.kioskId = kioskId;
	}


	
	public List<DietaryPreference> getUserDietaryPreference() {
		return userDietaryPreference;
	}

	public void setUserDietaryPreference(List<DietaryPreference> userDietaryPreference) {
		this.userDietaryPreference = userDietaryPreference;
	}
	

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

}
