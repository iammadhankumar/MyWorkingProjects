package nutrimeals.customdomain;

import java.util.Date;

//import pharmabox.domain.DietaryPreference;

public class signupCustomDomain {
	
    
	private long userId;
	private long user_id;
	private String email;
	private boolean active;
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	private String password;
	private String first_name;
	private String last_name;
	private boolean termsAndCondition;
	private boolean promotions;
	private String profileimage;
	private boolean notification;
	private Date updated_on;
	private String deviceToken;
	private String deviceType;
	
	public long getUser_id() {
		return user_id;
	}
	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}
	private String latitude;
	private String longitude;
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	

   
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public Date getUpdated_on() {
		return updated_on;
	}
	public void setUpdated_on(Date updated_on) {
		this.updated_on = updated_on;
	}
	public boolean isNotification() {
		return notification;
	}
	public void setNotification(boolean notification) {
		this.notification = notification;
	}
	
	public String getProfileimage() {
		return profileimage;
	}
	public void setProfileimage(String profileimage) {
		this.profileimage = profileimage;
	}
	public boolean isTermsAndCondition() {
		return termsAndCondition;
	}
	public void setTermsAndCondition(boolean termsAndCondition) {
		this.termsAndCondition = termsAndCondition;
	}

	public boolean isPromotions() {
		return promotions;
	}
	public void setPromotions(boolean promotions) {
		this.promotions = promotions;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	
	
	 public String getDeviceToken() {
			return deviceToken;
		}
		public void setDeviceToken(String deviceToken) {
			this.deviceToken = deviceToken;
		}
	

	public String getCorporateName() {
		return corporateName;
	}
	public void setCorporateName(String corporateName) {
		this.corporateName = corporateName;
	}
	//	@JsonFormat(pattern = "MM-dd-yyyy")
//	private Date dob;
	private long userType;
	private boolean actions;
	private String corporateName;
	private String facebook_id;
//	private String zipcode;
//	private long primaryKioskId;
//	private String foodAllergies;
	//private List<DietaryPreference> dietaryPreference;
//
//	public List<DietaryPreference> getDietaryPreference() {
//		return dietaryPreference;
//	}
//	public void setDietaryPreference(List<DietaryPreference> dietaryPreference) {
//		this.dietaryPreference = dietaryPreference;
//	}

//	public long getPrimaryKioskId() {
//		return primaryKioskId;
//	}
//	public void setPrimaryKioskId(long primaryKioskId) {
//		this.primaryKioskId = primaryKioskId;
//	}
//	public String getFoodAllergies() {
//		return foodAllergies;
//	}
//	public void setFoodAllergies(String foodAllergies) {
//		this.foodAllergies = foodAllergies;
//	}

	public String getEmail(){
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	
	public long getUserType() {
		return userType;
	}
	public void setUserType(long userType) {
		this.userType = userType;
	}
	public boolean isActions() {
		return actions;
	}
	public void setActions(boolean actions) {
		this.actions = actions;
	}
	
	public String getFacebook_id() {
		return facebook_id;
	}
	public void setFacebook_id(String facebook_id) {
		this.facebook_id = facebook_id;
	}
	

}
