package nutrimeals.customdomain;

public class AddBasketInput {
	private long user_id;
	
	
	private long productkioskid;

	private long primarypId;
	
	private long quantity;
	
	private long kioskId;
	

	public long getQuantity() {
		return quantity;
	}

	public long getKioskId() {
		return kioskId;
	}

	public void setKioskId(long kioskId) {
		this.kioskId = kioskId;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	private String type;
	
	public String getType() {
		return type;
	}
	
	public long getPrimarypId() {
		return primarypId;
	}

	public void setPrimarypId(long primarypId) {
		this.primarypId = primarypId;
	}

	public void setType(String type) {
		this.type = type;
	}

	public long getUser_id() {
		return user_id;
	}

	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}

	public long getProductkioskid() {
		return productkioskid;
	}

	public void setProductkioskid(long productkioskid) {
		this.productkioskid = productkioskid;
	}


	
	
}
