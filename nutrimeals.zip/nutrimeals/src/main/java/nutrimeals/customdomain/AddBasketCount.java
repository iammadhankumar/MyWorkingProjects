package nutrimeals.customdomain;

import nutrimeals.domain.Basket;

public class AddBasketCount {
	
	private long Basketcount;
	
	public long getBasketcount() {
		return Basketcount;
	}

	public void setBasketcount(long basketcount) {
		Basketcount = basketcount;
	}

	private  Basket BasketList;
	




	public Basket getBasketList() {
		return BasketList;
	}



	public void setBasketList(Basket basketList) {
		this.BasketList = basketList;
	}	
	
	
	
	
	
	
}
