package nutrimeals.customdomain;

public class BasketCountByUser {
private long Basketcount;
	
	public long getBasketcount() {
		return Basketcount;
	}



	public void setBasketcount(long basketcount) {
		Basketcount = basketcount;
	}

}
