package nutrimeals.customdomain;

import nutrimeals.domain.BillingAddress;
import nutrimeals.domain.ShippingAddress;

public class AddressInput {
	
	private BillingAddress billingAddress;
	private ShippingAddress shippingAddress;
	private boolean billing;
	public BillingAddress getBillingAddress() {
		return billingAddress;
	}
	public void setBillingAddress(BillingAddress billingAddress) {
		this.billingAddress = billingAddress;
	}
	public ShippingAddress getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddring(ShippingAddress shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	public boolean isBilling() {
		return billing;
	}
	public void setBilling(boolean billing) {
		this.billing = billing;
	}
	
	

}
