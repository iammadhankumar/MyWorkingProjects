package nutrimeals.helper;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import nutrimeals.domain.Basket;
import nutrimeals.domain.DietaryPreference;
import nutrimeals.domain.FavProduct;
import nutrimeals.domain.Kiosk;
import nutrimeals.domain.Product;
import nutrimeals.domain.ProductKiosk;
import nutrimeals.domain.UserInfo;
import nutrimeals.repository.FavProductRepository;
import nutrimeals.repository.ProductRepository;
import nutrimeals.response.DietaryPreferenceResponse;
import nutrimeals.response.FavouriteMessage;
import nutrimeals.response.FavouriteMessages;
import nutrimeals.response.ProductMessage;
import nutrimeals.response.ProductMessages;
import nutrimeals.response.ResponseStatus;
import nutrimeals.response.ResponseStatusCode;
import nutrimeals.service.IAddProductKioskService;
import nutrimeals.service.IBasketService;
import nutrimeals.service.IKioskService;
import nutrimeals.service.IProductService;
import nutrimeals.utils.UserByToken;
import nutrimeals.views.ProductView;



@Service
public class ProductHelper {
	
	private static final Logger logger = LoggerFactory
			.getLogger(ProductHelper.class);
	
	@Autowired
	IProductService productService;
	
	@Autowired
	IKioskService kioskService;
	
	@Autowired
	IBasketService basketService;

	@Autowired
	IAddProductKioskService productkioskService;
	
	@Autowired
	UserByToken tokenUser;
	
	@Autowired
	ProductRepository productRepo;
	
	@Autowired
	FavProductRepository favProductRepo;
	

	
	public DietaryPreferenceResponse dietaryPreferenceList(@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,HttpServletRequest request, final HttpServletResponse response) throws Exception
	{
		ResponseStatus status=null;
		List<DietaryPreference> dietaryList=null;
		long dietaryCount=0;
		try
		{
			
			dietaryList=productService.getAllDietaryPreferenceList(pagenumber, pagerecord);
			if(dietaryList==null)
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Records Found");
				 return new DietaryPreferenceResponse(status,null,0);
				 
			}
			else
			{
				dietaryCount=productService.getAllDietaryPreferenceListCount();
				status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");
			}
			
		}
		
		catch(Exception e)
		{
			logger.error("dietarylist Exception", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"INTERNAL ERROR");
			response.setStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR); 
		}
		return new DietaryPreferenceResponse(status,dietaryList,dietaryCount);
		
	}
	

	
	public ProductMessages getproductbyproductid(@RequestParam("id") long id,final HttpServletResponse response,HttpServletRequest request)
	{
		ResponseStatus status=null;
		Product product=null;
		UserInfo user=null;
		ProductKiosk productKiosk=null;
		Basket basket=null;
		List<String> favProductList=null;
		try {
			user = tokenUser.getUserByToken(request);
			if(id>0 )
			{
				product=productRepo.getById(id);

				if(product != null)
				{
					if(user != null) 
					{
						favProductList=favProductRepo.getFavProductListByUser(user.getUserId(),true);
						if(favProductList!=null)
						{
								if(favProductList.contains(String.valueOf(product.getId())))
								{
									product.setProductFavourite(true);
								}
							
						}
						productKiosk=productService.getQuantityByKiosk(user.getPrimaryLocationPreference().getId(),product.getId());
						basket=productKiosk!=null?basketService.getBasketByProductKiosk(productKiosk.getId()):null;
						if(basket!=null)
						{
						    product.setStockQuantity(productKiosk.getQuantity()-basket.getQuantity());
						}
					
					}

					status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
				}
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"NO RECORD FOUND");
					return new ProductMessages(status,null);	

				}
			}
			else 
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"Product Not Found");
				return new ProductMessages(status,null);	

			}
		}
		catch(Exception e)
		{
			logger.error("Product Info Exception", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"INTERNAL ERROR");
			response.setStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR); 
		}
		return new ProductMessages(status,product);	
	}
	
	
	public FavouriteMessages addToFavourites(@RequestParam("id")long id,final HttpServletRequest request,final HttpServletResponse response)
	{
		ResponseStatus status=null;
		UserInfo user=null;
		Product product=null;
		FavProduct favProduct=null;
		user = tokenUser.getUserByToken(request);

		try
		{
			if(user!=null)
			{ 
				product=productRepo.getById(id);
				if(product!=null)
				{
					favProduct=favProductRepo.getByProductandUserId(id,user.getUserId());
					if(favProduct==null)
					{
						favProduct=new FavProduct();
						favProduct.setActive(true);
						favProduct.setProduct(product);
						favProduct.setUser(user);
						favProduct.setCreatedOn(new Date());
					}
					else
					{
						favProduct.setActive(!favProduct.isActive());
						favProduct.setUpdatedOn(new Date());
					}

					favProductRepo.save(favProduct);
					status = new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
				}
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NOTEXIST,"Product Not Found");
					return new FavouriteMessages(status,null);
				}
			}
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED,"User Not Found");
				return new FavouriteMessages(status,null);
			}

		}
		catch(Exception e)
		{
			logger.error(" Fav Product Exception", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"INTERNAL ERROR");
			response.setStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR); 
		}

		return new FavouriteMessages(status,favProduct);


	}
	
	

	public FavouriteMessage getFavLists(@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletRequest request,final HttpServletResponse response)
	{
		ResponseStatus status=null;
		List<FavProduct> favProduct=null;
		UserInfo user=null;
		user = tokenUser.getUserByToken(request);
		long count=0;
		
		try
		{
			if(user!=null)
			{
				favProduct=productService.getAllFavProductList(user.getUserId(),pagenumber,pagerecord);
				if(favProduct==null)
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No Record Found");
					return new FavouriteMessage(status,null);
				}
				
			count =favProductRepo.getFavProductListsByUserAndActive(user.getUserId(),true);
				status = new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
				
			}
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED,"User Not Found");
				return new FavouriteMessage(status,null);
			}
		}
		
		catch(Exception e)
		{
			logger.error(" Fav Product Exception", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"INTERNAL ERROR");
			response.setStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR); 
		}
		
		
		
		
		return new FavouriteMessage(status,favProduct,count);
	}
	
	public ProductMessage getAllProducListByKiosk(@RequestParam(value="categoryId",defaultValue="0") long categoryId,@RequestParam(value="searchValue",required=false) String searchValue,@RequestParam(value="kid",required=false,defaultValue="0") long kid, @RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletRequest request,final HttpServletResponse response){
		ResponseStatus status = null;
		List<ProductView> productList=null;
		long productcount=0;
		Kiosk kiosk=null;
		UserInfo user=null;
		response.setHeader("Cache-Control", "no-cache");
		try {
			user = tokenUser.getUserByToken(request);
			if(user!=null)
			{
				
				kiosk=kid>0?kioskService.getKioskById(kid):kioskService.getKioskById(user.getPrimaryLocationPreference().getId());

				if(kiosk!=null)
				{

					productList=productService.getAllProductByKiosk(kiosk.getId(),searchValue,categoryId,pagenumber,pagerecord);

					if (productList !=null)
					{
				
						productcount=productService.getAllProductCountByKiosk(kiosk.getId(),searchValue,categoryId);
                        
					}

					else{
						status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No Records Found");
						return new ProductMessage(status,null);

					}



					status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");

				}

				else
				{
					status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"Product Not Found");
					return new ProductMessage(status,null);
				}

			}
			else
			{
				status=new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED,"User Not Found");
				return new ProductMessage(status,null);
			}
		}catch(Exception e){
			logger.error("getAllProducListByKiosk", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}

		return new ProductMessage(status,productList,productcount);
	}


}
