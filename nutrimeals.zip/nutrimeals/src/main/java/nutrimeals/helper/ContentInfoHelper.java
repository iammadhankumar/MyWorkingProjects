package nutrimeals.helper;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import nutrimeals.domain.ContentManagement;
import nutrimeals.repository.ContentManagementRepository;
import nutrimeals.response.ResponseMessages;
import nutrimeals.response.ResponseStatus;
import nutrimeals.response.ResponseStatusCode;
import nutrimeals.service.ContentManagementService;
import nutrimeals.utils.CommonUtils;
import nutrimeals.validation.BasicValidation;

@Service
public class ContentInfoHelper {
	
	private static final Logger logger = LogManager.getLogger(ContentInfoHelper.class);
	
	
	@Autowired 
	private ContentManagementService contentManagementService;
	
	
	@Autowired
	BasicValidation basicValidation;

	
	@Autowired
	ContentManagementRepository contentManagementRepository;
	
	CommonUtils commonUtils 		= CommonUtils.getInstance();
	

	
	
	
	public ResponseMessages<ContentManagement> getContentManagementByType(@RequestParam(value="label")String label,HttpServletResponse response) {
		ResponseStatus status = null;
		ContentManagement cms = null;
		try
		{
		cms = contentManagementService.getContentManagementByContentType(label);
		if(cms != null)
		{
			status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"SUCCESS");
		}
		else
		{
			status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"NO RECORD FOUND");
			return new ResponseMessages<>(status,null);
		}
		}
		catch(Exception e)
		{
			logger.error("getContentManagementByType ",e);
			status=new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"InternalError");
		}
		return new ResponseMessages<>(status,cms);
	}
	
	

	
	
	
	

}
