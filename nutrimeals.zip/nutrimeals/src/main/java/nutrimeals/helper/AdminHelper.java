package nutrimeals.helper;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import nutrimeals.customdomain.RewardsInput;
import nutrimeals.domain.Basket;
import nutrimeals.domain.Rewards;
import nutrimeals.domain.RewardsMaintain;
import nutrimeals.domain.UserInfo;
import nutrimeals.repository.BasketRepository;
import nutrimeals.repository.RewardsMaintainRepository;
import nutrimeals.response.ResponseStatus;
import nutrimeals.response.ResponseStatusCode;
import nutrimeals.response.RewardCalculation;
import nutrimeals.response.RewardMessage;
import nutrimeals.response.RewardMessages;
import nutrimeals.response.UserMessage;
import nutrimeals.response.UserMessages;
import nutrimeals.service.IAddProductKioskService;
import nutrimeals.service.IAdminService;
import nutrimeals.service.IBasketService;
import nutrimeals.service.IKioskService;
import nutrimeals.service.IOrderService;
import nutrimeals.service.IProductService;
import nutrimeals.service.UserInfoService;
import nutrimeals.utils.CommonUtils;
import nutrimeals.utils.UserByToken;
import nutrimeals.customdomain.signupCustomDomain;
import nutrimeals.customdomain.KioskInput;
import nutrimeals.domain.Kiosk;
import nutrimeals.domain.User;


@Service
public class AdminHelper {
	

	private static final Logger logger = LogManager.getLogger(AdminHelper.class);

	
	@Autowired
	UserByToken tokenUser;

	@Autowired
	IKioskService kioskService;
	
	@Autowired
	IBasketService basketService;
	
	@Autowired
	BasketRepository basketRepository;
	
	@Autowired
	RewardsMaintainRepository rewardMaintainRepo;

	@Autowired
	IAdminService adminService;

	@Autowired
	IProductService productService;

	@Autowired
	IOrderService orderService;
	
	@Autowired
	UserInfoService userInfoService;

	@Autowired
	IAddProductKioskService productKioskService;

	CommonUtils commonUtils = CommonUtils.getInstance();
	
	
	public UserMessages viewUsers(@RequestParam(value="stat",required=false) int stat,final HttpServletResponse response) 
	{
	ResponseStatus status = null;
	List<UserInfo> user = null;


	response.setHeader("Cache-Control", "no-cache");
	try {
		       user = userInfoService.getAllUsersByStatus(stat);

		if (user != null) {

			status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");

		}

		else {
			status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No record found");
			return new UserMessages(status, null);
		}
	} catch (Exception e) {
		e.printStackTrace();
		System.out.println(e.getMessage());
		status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
	}
	return new UserMessages(status, user);
}
	
	
	public UserMessage viewProfile(@FormParam("email") String email,final HttpServletResponse response){
		ResponseStatus status = null;
		UserInfo entity=null;
		response.setHeader("Cache-Control", "no-cache");
		try {
			entity=userInfoService.getUserByEmail(email);
			if(entity!=null) {

				status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
			} else {
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No record found");
			}
		}catch(Exception e){
			logger.error("viewProfile ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return new UserMessage(status, entity);
	}
	
	public RewardMessages getRewardList(
			@RequestParam(value = "all", required = false, defaultValue = "0") int all,
			@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,
			@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,
			HttpServletRequest request)
	{
		ResponseStatus status = null;
		List<Rewards> rewardcheck = null;
		List<Rewards> reward = null;
		List<Rewards> rewardObj = null;
		UserInfo user = null;
		user = tokenUser.getUserByToken(request);
		long rewardsCount = 0;
		try {
			if (user != null) {
				rewardObj = all==0?adminService.getAllRewardsList(user.getUserId()):adminService.getRewardList();

				if (rewardObj != null) {
					rewardcheck =all==0?adminService.getRewardsList(user.getUserId(), pagenumber, pagerecord):adminService.getallRewardsListWithOutActiveCheck( pagenumber, pagerecord);

					if (rewardcheck != null && rewardcheck.size() > 0) {
						reward = rewardcheck;
						rewardsCount = rewardObj.size();
						System.out.println("COUNT :" + rewardcheck.size());

					}

				} else {
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "NO REWARDS LIST ADDED");
					return new RewardMessages(status, null, 0);
				}

			}

			else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "User Not Found");
				return new RewardMessages(status, null, 0);
			}
		}

		catch (Exception e) {
			logger.error("getRewardList ",e);			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new RewardMessages(status, null, 0);

		}
		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success ");
		return new RewardMessages(status, reward, rewardsCount);
	}
	
	
	public RewardMessage getRewardById(@RequestParam(value = "rewardId") long rewardId,
			HttpServletRequest request) {
		ResponseStatus status = null;
		UserInfo user = null;
		Rewards reward = null;
		user = tokenUser.getUserByToken(request);
		try {
			if (user != null) {

				reward = adminService.getRewardById(rewardId);
				if (reward == null) {
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Reward Found");
					return new RewardMessage(status, null);
				}
			}

			else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED, "Unauthorized User");
				return new RewardMessage(status, null);
			}
		}

		catch (Exception e) {
			logger.error("getRewardById ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
			return new RewardMessage(status, null);

		}
		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");
		return new RewardMessage(status, reward);
	}
	
	
	public  RewardCalculation applyrewards(@RequestBody RewardsInput rewardsInputObj,final HttpServletRequest request)
	{
		ResponseStatus status=null;
		UserInfo user=null;
		Rewards rewardObj=null;
		List<Basket> basket=null;
		float totalPrice=0;
		RewardsMaintain rewardsMaintain=null;
		float offerPrice=0;
		float discountPrice=0;
		double percentage=0;
		float grandTotal=0;
		user = tokenUser.getUserByToken(request);
		try
		{
			if(user!=null)
			{  
				basket=basketService.getBasketByRewards(rewardsInputObj.getBasketId());
				if(basket!=null)
				{
					rewardObj=(rewardsInputObj.getType()==1)?adminService.getRewardById(rewardsInputObj.getRewardId()):(rewardsInputObj.getType()==2)?adminService.getRewardByPromoCode(rewardsInputObj.getCouponCode()):null;
					if(rewardObj!=null)
					{	

						basketService.updaterewardsInBasket(user.getUserId());
						percentage=rewardObj.getPercentage();
						totalPrice=(float) basketService.getSumOfBasketPrice(user.getUserId());
						grandTotal=((totalPrice*13)/100)+totalPrice;
						discountPrice=(float) (grandTotal*percentage)/100;
						offerPrice=grandTotal-discountPrice;

						rewardsMaintain=adminService.getRewardsMaintainByUser(rewardObj.getId(), user.getUserId());
						
						if(rewardsMaintain!=null)
						{
							status = new ResponseStatus(ResponseStatusCode.STATUS_ALREADY_EXISTS, "This Reward Already Applied");
							return new RewardCalculation(status,0,0,0,0);
						}
						
						rewardsMaintain =new RewardsMaintain();
						rewardsMaintain.setActive(true);
						rewardsMaintain.setReward(rewardObj);
						rewardsMaintain.setUser(user);

						adminService.registerRewardsInfoByUser(rewardsMaintain);
						
						status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "SUCCESS");
					}

					else{
						status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"Please Enter RewardId or Promocode");
						return new RewardCalculation(status,0,0,0,0);
					}	
				}

				else{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"Basket Not Found");
					return new RewardCalculation(status,0,0,0,0);
				}	




			}

			else{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"User Not Found");
				return new RewardCalculation(status,0,0,0,0);
			}		

		}

		catch (Exception e) {
			logger.error("applyrewards ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return new RewardCalculation(status,grandTotal,percentage,discountPrice,offerPrice);                
	}
	
	
	
	public ResponseStatus removerewards(@RequestParam(value="rewardId") long rewardId,@RequestParam(value="bid") List<Long> bid,final HttpServletRequest request)
	{

		ResponseStatus status=null;
		UserInfo user=null;
		List<Basket> basket=null;
		RewardsMaintain rewardsMaintain=null;
		user = tokenUser.getUserByToken(request);
		try
		{
			if(user!=null)
			{
				rewardsMaintain=adminService.getRewardsMaintainByUser(rewardId, user.getUserId());
				if(rewardsMaintain!=null)
				{
					adminService.removeRewards(rewardsMaintain.getReward().getId());
					basket=basketService.getBasketbyRewardPurchase(bid,user.getUserId());
					if(basket!=null)
					{
						basketService.removeRewards(user.getUserId());

					//	rewardsMaintain=adminService.getRewardsMaintainByUser(rewardId, user.getUserId());
						rewardsMaintain.setActive(false);
						rewardMaintainRepo.save(rewardsMaintain);
						status = new ResponseStatus(ResponseStatusCode.STATUS_OK,"Successfully Removed This Reward");
					}
					else
					{
						status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"Basket Not Found");
					}
				}
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No Rewards Added Against This User");
				}
			}
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"User Not Found");

			}	
		}
		catch (Exception e)
		{
			logger.error("removerewards ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return status;
	}
	
	
	public ResponseStatus updateKioskStatus(@RequestBody KioskInput kioskObj, final HttpServletRequest request,final HttpServletResponse response)
	{
		ResponseStatus status=null;
		Kiosk kiosk=null;
		UserInfo user=null;
		user = tokenUser.getUserByToken(request);
		try
		{
			
			if(user!=null)
			{
				kiosk=kioskService.getKioskByIdWithoutActiveCheck(kioskObj.getKioskId());
				if(kiosk!=null)
				{
					kiosk.setActive(!kiosk.isActive());
					kioskService.updateKiosk(kiosk);
					status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Kiosk Status Updated");
				}
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No Kiosk Found");
				}
			}
			else
			{
			status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED, "Unauthorized User");
			}

		}
		catch(Exception e)
		{
			logger.error("updateKioskStatus ",e);				
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return status;
		
	}
	
	
	public ResponseStatus updateRewardsStatus(@RequestBody RewardsInput rewardObj, final HttpServletRequest request,final HttpServletResponse response)
	{
		ResponseStatus status=null;
		Rewards reward=null;
		UserInfo user=null;
		user = tokenUser.getUserByToken(request);
		try
		{
			System.out.println(user);
			
			if(user!=null)
			{
				reward=adminService.getRewardByIdWithoutActiveCheck(rewardObj.getId());
				if(reward!=null)
				{
					reward.setActive(!reward.isActive());
					adminService.updateRewards(reward);
					status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "reward Status Updated");
				}
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "No reward Found");
				}
			}
			else
			{
			status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED, "Unauthorized User");
			}

		}
		catch(Exception e)
		{
			logger.error("updateRewardsStatus ",e);				
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return status;
	}
	
	
	public @ResponseBody ResponseStatus updateUserStatus(@RequestBody signupCustomDomain userObj, final HttpServletRequest request,final HttpServletResponse response)
	{
		ResponseStatus status=null;
		UserInfo user=null;
		UserInfo userEntity = tokenUser.getUserByToken(request);
		try
		{
			if(userEntity!=null)
			{
				user=userObj.getUser_id()>0?userInfoService.getUserByIdWithoutActiveCheck(userObj.getUser_id()):null;
				System.out.println("DKJHh"+user);
				if(user!=null)
				{
					user.setActive(!user.isActive());
					userInfoService.updateUser(user);
					status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"User Active Status Updated");
				}
				else
				{
					status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No User Selected");
				}
			}
			else
			{	
				status=new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED,"UnAuthorized User");	
			}

		}

		catch(Exception e)
		{
			logger.error("updateUserStatus ",e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return status;
	}
	


	

}


