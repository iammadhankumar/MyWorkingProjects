package nutrimeals.helper;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.Barcode128;

import nutrimeals.customdomain.OrderInput;
import nutrimeals.domain.Basket;
import nutrimeals.domain.Order;
import nutrimeals.domain.OrderBasket;
import nutrimeals.domain.Product;
import nutrimeals.domain.ProductKiosk;
import nutrimeals.domain.Rewards;
import nutrimeals.domain.RewardsMaintain;
import nutrimeals.domain.RewardsPurchaseInfo;
import nutrimeals.domain.UserInfo;
import nutrimeals.repository.RewardPurchaseRepository;
import nutrimeals.repository.RewardsMaintainRepository;
import nutrimeals.response.OrderInfo;
import nutrimeals.response.OrderMessage;
import nutrimeals.response.OrderMessages;
import nutrimeals.response.ResponseStatus;
import nutrimeals.response.ResponseStatusCode;
import nutrimeals.service.IAddProductKioskService;
import nutrimeals.service.IAdminService;
import nutrimeals.service.IBasketService;
import nutrimeals.service.IOrderService;
import nutrimeals.utils.CommonProperties;
import nutrimeals.utils.CommonUtils;
import nutrimeals.utils.UserByToken;
import nutrimeals.views.OrderView;

@Service
public class OrderHelper {
	
	private static final Logger logger = LogManager.getLogger(OrderHelper.class);

	
	@Autowired
	UserByToken tokenUser;

	@Autowired
	private IOrderService orderService;

	@Autowired
	private IAdminService adminService;

	@Autowired
	private IBasketService basketService;
	
	@Autowired
	private RewardPurchaseRepository rewardsPurchaseRepo;
	

	@Autowired
	private RewardsMaintainRepository rewardMaintainRepo;


	@Autowired
	private IAddProductKioskService  AddProductKioskService;

	CommonUtils commonUtils = CommonUtils.getInstance();
	
	
	
	@SuppressWarnings("unused")
	public OrderMessage addOrderInfo(@RequestBody OrderInput orderInputObj,final HttpServletRequest request,final HttpServletResponse response) throws Exception 
	{
		ResponseStatus status = null;
		UserInfo user=null;
		Product product = null;
		Order order = null;
		List<Basket> basket = null;
		List<Basket> basketObj=null;
		Basket basketobj=null;
		RewardsPurchaseInfo rewardsPurchase=null;
		RewardsMaintain rewardsMaintain=null;
		float basketTotal=0;
		float grandTotalPrice=0;
		float dicountPrice=0;
		float offerPrice=0;
		String transactionID=null;
		Rewards rewardObj=null;
		OrderBasket orderBasketObj=null;
		List<OrderBasket> orderBasketlist=new ArrayList<>();
		user = tokenUser.getUserByToken(request);
		String orderNo = null;
		try 
		{
		
			if (user != null)
			{
//				if((orderInputObj.getNonceToken()!=null && ! orderInputObj.getNonceToken().isEmpty()) && (orderInputObj.getAmount()>0))
//				{
//				//System.out.println(orderInputObj.getNonceToken());
//					BraintreeGateway gateway = new BraintreeGateway(
//							Environment.SANDBOX,
//							"7tqb9bqyq6dyyfpt",
//							"9sb465cwq5ys68fz",
//							"0bd5057c4b622a1395fb67d29d7e08a1"
//							);
//					
//					Float f=orderInputObj.getAmount();
//					
//
//							
//					TransactionRequest req = new TransactionRequest()
//							.amount(new BigDecimal(Float.toString(orderInputObj.getAmount())))		
//							.paymentMethodNonce(orderInputObj.getNonceToken())
//							.options()
//							.submitForSettlement(true)
//							.done();
//
//
//					Result<Transaction> result = gateway.transaction().sale(req);
//
//					if (result.isSuccess()) {
//						Transaction transaction = result.getTarget();
//						System.out.println("Success! This is a valid nonce token:");
//						transactionID=transaction.getId();
//
//						System.out.println(transactionID);
//					} 
//
//					else if (result.getTransaction() != null) 
//					{
//						Transaction transaction = result.getTransaction();
//						System.out.println("Error processing transaction:");
//						System.out.println("  Status: " + transaction.getStatus());
//						System.out.println("  Code: " + transaction.getProcessorResponseCode());
//						System.out.println("  Text: " + transaction.getProcessorResponseText());	
//
//						status=new ResponseStatus(ResponseStatusCode.STATUS_AlREADY_EXPIRED,"Nonce Token Expired");
//						return new OrderMessage(status,null);       
//
//					} 
//
//					else {
//						for (ValidationError error : result.getErrors().getAllDeepValidationErrors()) 
//						{
//							System.out.println("Attribute: " + error.getAttribute());
//							System.out.println("  Code: " + error.getCode());
//							System.out.println("  Message: " + error.getMessage());
//							status=new ResponseStatus(ResponseStatusCode.STATUS_INVALID,"Invalid Nonce Token");
//						
//
//						}
//						return new OrderMessage(status,null);
//					}
//
//			    	}
//
//				else
//				{
//					status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, "Nonce Token and amount Required");
//					return new OrderMessage(status, null);
//				}
				basket=basketService.getBasketbyListCheck(orderInputObj.getBid(),user.getUserId());
				if ( basket!=null) 
				{
					String barcodepath=CommonProperties.getBaseURL()+CommonProperties.getImagePath()+CommonProperties.getBarcode();
					orderNo = commonUtils.randomNumbers();
					JSONObject json = generateBarcode(orderNo);
					String code =json.get("values").toString();
					String path=json.get("path").toString();
					System.out.println(orderNo);
					order=new Order();
					order.setOrderNo(orderNo);
					order.setBasketStatus(basketService.setBasketStatus(4));
					order.setPurchaseStatus(true);  
					order.setUser(user);
					order.setBarcode(path);
					order.setTransactionId(transactionID);
					order.setBarcode(barcodepath+"/"+order.getBarcode());
					order.setCreatedOn(new Date());
					
						basketObj=basketService.getBasketByUser(user.getUserId(),orderInputObj.getBid());
						if(basketObj != null) 
						{
							System.out.println("IN BASKETOBJ");
							basketTotal= (float) basketService.getSumOfBasketPrice(user.getUserId());
							grandTotalPrice=((basketTotal*13)/100)+basketTotal;
							for(int i=0;i<basketObj.size();i++) {
								rewardObj=basketObj.get(0).getReward();
								orderBasketObj=new OrderBasket();
								orderBasketObj.setBasket(basketObj.get(i));
								orderBasketlist.add(orderBasketObj);
							ProductKiosk productKioskObj=AddProductKioskService.getProductKioskBypId(basketObj.get(i).getProductKiosk().getId());
		
							if(productKioskObj != null)
							{
								basketobj=productKioskObj.getId()>0?basketService.getbasketDetailsbypid(productKioskObj.getId(),user.getUserId()):null;
								product= productKioskObj.getId()>0 ? productKioskObj.getProduct():null;
								if(basketobj!=null)
								{
								if(product !=null && productKioskObj.getQuantity()>=basketobj.getQuantity())
								{		System.out.println("IN PRODUCT QUANT CHECK");
												
			                         	System.out.println("IN BASKET CHECK");
										productKioskObj.setQuantity((productKioskObj.getQuantity()-basket.get(i).getQuantity()));
										AddProductKioskService.updateProductKiosk(productKioskObj);
										basketTotal= (float) basketService.getSumOfBasketPrice(user.getUserId());
										basketService.UpdateBasketActive(basket.get(i).getBid());
								}
								}
								else
								{
									status = new ResponseStatus(ResponseStatusCode.STATUS_NOTEXIST, " Out of stock");
									return new OrderMessage(status, null);
								}
							}
						
							}
						}
					if(rewardObj!=null)
					{
						System.out.println("IN REWARDS OBJ CHECK");
						System.out.println("USER "+user.getUserId());
						order.setReward(rewardObj);
						order.setPrice(grandTotalPrice);
						dicountPrice=(float) ((grandTotalPrice*rewardObj.getPercentage())/100);
						rewardsPurchase=new RewardsPurchaseInfo();
						rewardsPurchase.setDiscountPrice(dicountPrice);
						offerPrice=grandTotalPrice-dicountPrice;
						rewardsPurchase.setOfferPrice(offerPrice);
						rewardsPurchase.setActive(true);
					RewardsPurchaseInfo rp=	rewardsPurchaseRepo.save(rewardsPurchase);
					rewardsMaintain=adminService.getRewardsMaintainByUser(rewardObj.getId(), user.getUserId());
						order.setRewardsPurchase(rp);
						if(rewardsMaintain!=null)
						 {  rewardsMaintain.setActive(true);
							rewardsMaintain.setPurchase(true);
							rewardMaintainRepo.save(rewardsMaintain);		
						}
					}
					else
					{
						order.setPrice(grandTotalPrice);
					}
					order.setOrderBasket(orderBasketlist);
					long orderId=  orderService.registerNewOrder(order);   
					status = new ResponseStatus(ResponseStatusCode.STATUS_OK,"success ");
				}
				else 
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, " Basket Not Found.");
					return new OrderMessage(status, null);
				}
			}
			else 
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_INVALID, " User Not Found.");
				return new OrderMessage(status, null);
			}

		}
		catch (Exception e)
		{
			logger.error("addOrderInfo ", e);

		}
		return new OrderMessage(status, order,user);
	}	


	@SuppressWarnings("unchecked")
	private JSONObject generateBarcode(String orderNo) throws DocumentException{
		JSONObject json=new JSONObject();
		String path1=CommonProperties.getBasePath();
		 String path2 = commonUtils.createExportDirectory(path1,CommonProperties.getImagePath());
		 String path = commonUtils.createExportDirectory(path2,CommonProperties.getBarcode());
		try {   
			Barcode128 code128 = new Barcode128();
			code128.setCode(orderNo);   
			java.awt.Image rawImage = code128.createAwtImage(Color.BLACK, Color.WHITE);
			BufferedImage resizedImage = new BufferedImage(500,120, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = resizedImage.createGraphics();
			g.drawImage(rawImage, 0, 0,500,120,null);
			ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
			ImageIO.write(resizedImage, "png", bytesOut);
			g.dispose();
			byte[] pngImageData = bytesOut.toByteArray();
			try(FileOutputStream fos = new FileOutputStream(path+"/"+orderNo+".png"))
			{
			fos.write(pngImageData);
			fos.close();
			json.put("values", orderNo);
			json.put("path", orderNo+".png");
			return json;
			}
		} catch(Exception e) {
			logger.error("generateBarcode ", e);
		} return json;
	}


	public OrderInfo GetMyOrder(@RequestParam(value="orderId",required=false,defaultValue="0") Long orderId,@RequestParam(value="orderNo",required=false) String orderNo,final HttpServletRequest request, final HttpServletResponse response) throws Exception {

		ResponseStatus status = null;
		Order order = null;
		UserInfo user = null;
		user = tokenUser.getUserByToken(request);
		try 
		{
			if (user != null) 
			{
			
					order=orderService.getOrderInfoById(user.getUserId(),orderNo,orderId);
					if(order==null )
					{
						status = new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED, "Order Not Found");
						return new OrderInfo(status, null);
					}
					
			}
			else {
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "User Not Found");
				return new OrderInfo(status, null);
			}
		}

		catch (Exception e) 
		{
			logger.error("GetMyOrder", e);

		}
		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "success ");
		return new OrderInfo(status, order);
	}

	public OrderMessages GetMyOrderList(@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,final HttpServletRequest request, final HttpServletResponse response) throws Exception 
	{
		ResponseStatus status = null;
		List<OrderView> order = null;
		UserInfo user = null;
		user = tokenUser.getUserByToken(request);
		long orderCount = 0;
		try 
		{
			if (user != null)
			{
				order = orderService.getOrderInfoByUser(user.getUserId(), pagenumber, pagerecord);
				orderCount = orderService.getorderCount(user.getUserId(), true);
				if (order==null ) 
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No Record");
					return new OrderMessages(status, null, 0);
				}
			} 
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED, "User Not Found");
				return new OrderMessages(status, null, 0);
			}
		}

		catch (Exception e) 
		{
			logger.error("Order List Error", e);

		}
		status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "success ");
		return new OrderMessages(status, order, orderCount);
	}
	
	
	
	
}
