package nutrimeals.helper;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import nutrimeals.customdomain.SignupDomain;
import nutrimeals.domain.Kiosk;
import nutrimeals.domain.UserInfo;
import nutrimeals.repository.KioskRepository;
import nutrimeals.repository.UserInfoRepository;
import nutrimeals.response.KioskMessage;
import nutrimeals.response.ResponseStatus;
import nutrimeals.response.ResponseStatusCode;
import nutrimeals.service.IKioskService;
import nutrimeals.utils.UserByToken;
import nutrimeals.views.KioskView;

@Service
public class KioskHelper {
	
	private static final Logger logger = LoggerFactory
			.getLogger(KioskHelper.class);
	
	@Autowired
	private IKioskService kioskService;

	
	@Autowired
	private KioskRepository kioskRepo;
	
	
	@Autowired
	UserByToken tokenUser;
	
	@Autowired
	UserInfoRepository userInfoRepo;
	
	
	public KioskMessage getNearerKioskLocationDetails(@RequestParam(value="latitude") double latitude,@RequestParam(value="longitude") double longitude,@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletRequest request, HttpServletResponse response){
		ResponseStatus status = null;
		List<KioskView> kiosk=null;
		long count=0;
		UserInfo user=null;
		response.setHeader("Cache-Control", "no-cache");
		try {
			user = tokenUser.getUserByToken(request);
			if(user!=null)
			{
			 kiosk = kioskService.getAllKioskMap(latitude,longitude,pagenumber,pagerecord);
			 double lat1= latitude;
		     double long1= longitude;
		 	if (kiosk !=null) {
		 		count=kioskService.getAllKioskMapCount(latitude, longitude);
				System.out.println("COUNT "+count);
		 		for(KioskView k:kiosk){
					double  lat2= k.getLatitude();
					double  long2= k.getLongitude();
					double miles=distBetween(lat1,long1,lat2,long2);
					String mile=String.valueOf(miles );
					k.setMiles(mile);
					HashMap<String,Double> coordinate = new HashMap<>();
					coordinate.put("latitude", k.getLatitude());
					coordinate.put("longitude",  k.getLongitude());
					k.setCoordinate(coordinate);
					
				}
		
				status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
			
			}else {
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No Records");
				return new KioskMessage(status,null,0);
			}
		 	
			}
			
			else {
				status=new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED,"Unauthorized User");
				return new KioskMessage(status,null,0);
			}
		}catch(Exception e){
			logger.error("kiosklist Exception", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"INTERNAL ERROR");
			response.setStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR); 
		}
		return new KioskMessage(status,kiosk,count);
	}
	
	
	public static double  distBetween(double lat1, double lng1, double lat2, double lng2) {
	double theta = lng1 - lng2;
	double dist = Math.sin(Math.toRadians(lat1)) * Math.sin(Math.toRadians(lat2)) + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.cos(Math.toRadians(theta));
	dist = Math.acos(dist);
	dist = Math.toDegrees(dist);
	dist = dist * 60 * 1.1515;
	dist = dist * 1.609344;
	return (dist);
	}
	
	
	public KioskMessage getAllKioskList(@RequestParam(value="all",required=false,defaultValue="0") int all,@RequestParam(value="sortColumn",required=false,defaultValue="0") int sortColumn,@RequestParam(value="sortType",required=false,defaultValue="0") String sortType,@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletResponse response){
		ResponseStatus status = null;
		List<KioskView> kioskList=null;
		long kioskcount=0;
		response.setHeader("Cache-Control", "no-cache");
		try {
			kioskList = kioskService.getAllKioskList(all,sortColumn,sortType,pagenumber,pagerecord);
			System.out.println(kioskList);
			if (kioskList !=null){
				for(KioskView k:kioskList){

					HashMap<String,Double> coordinate = new HashMap<String,Double>();
				
					coordinate.put("latitude", k.getLatitude());
		
					coordinate.put("longitude",  k.getLongitude());
					k.setCoordinate(coordinate);
					
				}
				kioskcount=kioskRepo.count();
				status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
			} 
			else{
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"No Kiosk Records");
				return new KioskMessage(status,null,0);

			}
		}catch(Exception e){
			logger.error("getAllKioskList", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		
		
		return new KioskMessage(status,kioskList,kioskcount);
	}
	
	
	public ResponseStatus updateProfile(@RequestBody SignupDomain signupObj,HttpServletRequest request, final HttpServletResponse response) throws Exception
	{
		ResponseStatus status=null;
		UserInfo user=null;
		Kiosk kiosk=null;
		try
		{
			user = tokenUser.getUserByToken(request);
			
			if(user!=null)
			{
				kiosk=signupObj.getKioskId()>0?kioskService.getKioskByKioskId(signupObj.getKioskId()):null;
				if(kiosk==null)
				{
					status=new ResponseStatus(ResponseStatusCode.STATUS_NOTEXIST,"Prefered Location Not Found");
					return status;
				}
				
				user.setPrimaryLocationPreference(kiosk);
				userInfoRepo.save(user);
				status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Prefered Location Updated");
			}
			else
			{
			status=new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED,"Unauthorized User");
			return status;
			}
			
		}
		
		catch(Exception e) {
			logger.error("updateProfile", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}	

		return status;
		
	}
	
	
	
	

}
