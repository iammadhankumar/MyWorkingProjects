package nutrimeals.helper;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import nutrimeals.customdomain.AddBasketInput;
import nutrimeals.customdomain.BasketCountByUser;
import nutrimeals.domain.Basket;
import nutrimeals.domain.CartTotal;
import nutrimeals.domain.Kiosk;
import nutrimeals.domain.Product;
import nutrimeals.domain.ProductKiosk;
import nutrimeals.domain.UserInfo;
import nutrimeals.repository.BasketRepository;
import nutrimeals.repository.BasketStatusRepository;
import nutrimeals.repository.KioskRepository;
import nutrimeals.repository.ProductKioskRepository;
import nutrimeals.repository.ProductRepository;
import nutrimeals.response.BasketCountByUserMessage;
import nutrimeals.response.BasketMessage;
import nutrimeals.response.BasketMessages;
import nutrimeals.response.ResponseStatus;
import nutrimeals.response.ResponseStatusCode;
import nutrimeals.service.IAddProductKioskService;
import nutrimeals.service.IBasketService;
import nutrimeals.utils.UserByToken;
import nutrimeals.views.CartListView;

@Service
public class BasketHelper {
	
	
	
	private static final Logger logger = LoggerFactory
			.getLogger(BasketHelper.class);
	
	@Autowired
	UserByToken tokenUser;
	
	@Autowired
	ProductKioskRepository productKioskRepo;
	
	@Autowired
	IAddProductKioskService productKioskService;
	
	@Autowired
	ProductRepository productRepo;
	
	@Autowired
	KioskRepository kioskRepo;
	
	@Autowired
	IBasketService basketService;
	
	@Autowired
	BasketRepository basketRepo;
	
	@Autowired
	BasketStatusRepository basketStatusRepo;

	
	
	
	public BasketMessage addtoCart(@RequestBody AddBasketInput AddBasketInputObj,final HttpServletRequest request, HttpServletResponse response) 
	{
		ResponseStatus status=null;
		UserInfo user=null;
		Product product=null;
		Kiosk kiosk=null;
		Basket basket=null;
		Basket basketCheck=null;
		List<Basket> basketListByUser=null;
		ProductKiosk productKiosk=null;
		try
		{
			user = tokenUser.getUserByToken(request);
			if(user!=null)
			{
				if(AddBasketInputObj.getPrimarypId()>0)
				{
					basketListByUser=user.getUserId()>0?basketService.getBasketListByUser(user.getUserId()):null;
					product=productRepo.getById(AddBasketInputObj.getPrimarypId());
					kiosk=kioskRepo.getById(user.getPrimaryLocationPreference().getId());
					productKiosk=product!=null&&kiosk!=null?productKioskService.getByProductAndKioskId(AddBasketInputObj.getPrimarypId(),user.getPrimaryLocationPreference().getId()):null;
					if(productKiosk!=null)
					{
						basketCheck=productKiosk.getId()>0?basketService.getBasketByProductKioskAndUser(productKiosk.getId(),user.getUserId()):null;

						if(basketListByUser!=null && !basketListByUser.isEmpty() )
						{
							if(basketListByUser.get(0).getProductKiosk().getKiosk().getId()!=user.getPrimaryLocationPreference().getId())
							{
								status = new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED, "Please Complete The Order to purchase more");
								return new BasketMessage(status,null);
							}
							if(basketListByUser.size()>=4 && basketService.getBasketByProductKioskandUser(productKiosk.getId(),user.getUserId())==false)
							{
								status = new ResponseStatus(ResponseStatusCode.STATUS_LIMIT_REACHED, "Oops! only allowed to purchase 4 products");
								return new BasketMessage(status,null);	
							}
						}
						if(basketCheck!=null)
						{

							if(productKiosk.getQuantity()<=basketCheck.getQuantity())
							{
								status = new ResponseStatus(ResponseStatusCode.STATUS_NOTEXIST, "Out Of Stock");
								return new BasketMessage(status,null);
							}
							basketCheck.setQuantity(basketCheck.getQuantity()+1);
							basketCheck.setPrice(basketCheck.getPrice()+product.getPrice());
							basketRepo.save(basketCheck);
							status = new ResponseStatus(ResponseStatusCode.STATUS_ALREADY_EXISTS, "Quantity Increased");
							return new BasketMessage(status,null);


						}

						else
						{
							basket=new Basket();
							basket.setActive(true);
							basket.setCreatedOn(new Date());
							basket.setPrice(product.getPrice());
							basket.setUser(user);
							basket.setProductKiosk(productKiosk);
							basket.setQuantity(1);
							basket.setActions(true);
							basket.setBasketStatus(basketStatusRepo.getBybasketStatusId(1));
							basket.setPurchase(false);
							basketRepo.save(basket);
							status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");
						}
					}
					else
					{
						status = new ResponseStatus(ResponseStatusCode.STATUS_NOTEXIST, "The Product in this Kiosk not Found");
						return new BasketMessage(status,null);
					}
				}
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, "Both Product Id");
					return new BasketMessage(status,null);
				}
			}
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED, "Unauthorized User");
				return new BasketMessage(status,null);
			}
		}
		catch(Exception e)
		{
			logger.error("Add to cart Exception", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"INTERNAL ERROR");
			response.setStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR); 
		}
		return new BasketMessage(status,basket);
	}
	

	public BasketMessages getCartList(final HttpServletRequest request, HttpServletResponse response) 
	{
		ResponseStatus status=null;
		UserInfo user=null;
		List<CartListView> basket=null;
		CartTotal cartInfo=null;
		double cartTotal=0;
		double tax=0;
		double grandTotal=0;
		long count=0;
		try
		{
			user = tokenUser.getUserByToken(request);
			if(user!=null)
			{
				basket=basketService.getBasketlistByUserid(user.getUserId());
				if(basket==null)
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "Cart is Empty");
					return new BasketMessages(status,null);
				}
				else
				{
					count=basketService.getBasketCountByQuantity(user.getUserId());
					cartTotal=basketService.getSumOfBasketPrice(user.getUserId());
					tax=(cartTotal*13)/100;
					grandTotal=cartTotal+tax;

					cartInfo=new CartTotal();
					cartInfo.setTotal(cartTotal);
					cartInfo.setTax(tax);
					cartInfo.setCartSubtotal(grandTotal);	
					cartInfo.setCount(count);
					status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");
					
				}
			}
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED, "Unauthorized User");
				return new BasketMessages(status,null);
			}
		}
		catch(Exception e)
		{
			logger.error("Get Cart List Exception", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"INTERNAL ERROR");
			response.setStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR); 
		}
		return new BasketMessages(status,basket,cartInfo,user);

	}
	
	
	public BasketCountByUserMessage getBasketCountByUser(final HttpServletRequest request, HttpServletResponse response) 
	{
		ResponseStatus status=null;
		UserInfo user=null;
		BasketCountByUser basketCountObj=null;

		long count=0;
		try
		{
			user = tokenUser.getUserByToken(request);
			if(user!=null)
			{
				count=basketService.getBasketCountByQuantity(user.getUserId());
				basketCountObj=new BasketCountByUser();
				basketCountObj.setBasketcount(count);
				
				status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");
			}
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED, "Unauthorized User");
				return new BasketCountByUserMessage(status,null);
			}
		}
		catch(Exception e)
		{
			logger.error("Get Cart count Exception", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"INTERNAL ERROR");
			response.setStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR); 
		}
		return new BasketCountByUserMessage(status,basketCountObj);
		
	}
	
	
	public BasketMessages deleteCart(@RequestParam("bid") long bid,final HttpServletRequest request, HttpServletResponse response)
	{
		ResponseStatus status=null;
		Basket basket=null;
		UserInfo user=null;
		List<CartListView> basketList=null;
		double cartTotal=0;
		double tax=0;
		double grandTotal=0;
		long count=0;
		CartTotal cartInfo=null;
		try
		{
			user = tokenUser.getUserByToken(request);

			if(user!=null)
			{
				basket=basketService.getBasketByBasketIdandUser(bid,user.getUserId());
				if(basket==null)
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "Basket Not Found"); 
					return new BasketMessages(status);
				}
				else
				{
			
					
					basketList=basketService.getBasketlistByUserid(user.getUserId());
					
					if(basketList!=null)
					{
						count=basketService.getBasketCount(user.getUserId());
						cartTotal=basketService.getSumOfBasketPrice(user.getUserId());
						tax=(cartTotal*13)/100;
						grandTotal=cartTotal+tax;

						cartInfo=new CartTotal();
						cartInfo.setTotal(cartTotal);
						cartInfo.setTax(tax);
						cartInfo.setCartSubtotal(grandTotal);	
						cartInfo.setCount(count);
					}
					
					basket.setActive(false);
					basketRepo.save(basket);

					status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Deleted Successfully"); 
				
				} 

			}

			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED, "Unauthorized User");
				return new BasketMessages(status);
			}
		}
		catch(Exception e)
		{
			logger.error("Delete Cart count Exception", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"INTERNAL ERROR");
			response.setStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR); 
		}
		return new BasketMessages(status,basketList,cartInfo,user);
	}
}
