package nutrimeals.helper;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;

import org.apache.commons.lang.RandomStringUtils;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.Barcode128;

import nutrimeals.customdomain.SignupDomain;
import nutrimeals.domain.UserDietaryPreference;
import nutrimeals.domain.UserInfo;
import nutrimeals.domain.UserType;
import nutrimeals.domain.VerificationCode;
import nutrimeals.email.EmailManager;
import nutrimeals.oauth2.TokenGeneration;
import nutrimeals.repository.DietaryPreferenceRepository;
import nutrimeals.repository.KioskRepository;
import nutrimeals.repository.UserDietaryRepositary;
import nutrimeals.repository.UserInfoRepository;
import nutrimeals.repository.UserProfileRepository;
import nutrimeals.response.ResponseStatus;
import nutrimeals.response.ResponseStatusCode;
import nutrimeals.response.UserInfoMessage;
import nutrimeals.response.UserMessage;
import nutrimeals.service.IUserInfoService;
import nutrimeals.service.IVerificationService;
import nutrimeals.utils.CommonProperties;
import nutrimeals.utils.CommonUtils;
import nutrimeals.utils.UserByToken;
import nutrimeals.validation.UserInfoValidation;
import nutrimeals.validation.UserValidation;

@Service
public class UserHelper {
	
	private static final Logger logger = LoggerFactory
			.getLogger(UserHelper.class);
	
	@Autowired
	UserByToken tokenUser;
	
	@Autowired
	UserDietaryRepositary userDietaryRepo;
	
	@Autowired
	DietaryPreferenceRepository dietaryPreferenceRepo;
	
	@Autowired
	IUserInfoService userInfoService;
	
	@Autowired
	IVerificationService verificationService;
	

	@Autowired
	KioskRepository kioskRepo;
	
	@Autowired
	UserInfoRepository userInfoRepo;
	
	@Autowired
	TokenGeneration tokenGeneration;
	
	@Autowired UserProfileRepository userProfileRepo;
	
	
	@Autowired
	PasswordEncoder passwordencoder;
	
	CommonUtils commonUtils = CommonUtils.getInstance();
	
	
	String cmnUtils = CommonUtils.getBasicAuthHeader("nutrimeals","nutrimeals");

	
	public UserInfoMessage createUser(@RequestBody SignupDomain signupObj,HttpServletRequest request, final HttpServletResponse response) throws Exception
	{
		ResponseStatus status=null;
		UserInfo user=null;
		UserType usertype=null;
		JSONObject token=null;
		UserInfo emailCheck=null;
		UserDietaryPreference userDietary=null;
		List<UserDietaryPreference> userDietaryPrefList=new ArrayList<>();
		response.setHeader("Cache-Control", "no-cache");
		String UserValidation="";	
		try
		{
			System.out.println("INN");
			UserValidation=UserInfoValidation.checkUserInfoFieldsEmpty(signupObj.getFirstName(), signupObj.getLastName(), signupObj.getEmail(), signupObj.getPassword(),signupObj.isTermsAndCondition(),signupObj.getUserType(),signupObj.getUserDietaryPreference(),signupObj.getKioskId(),signupObj.getFoodAllergies(),signupObj.getDob());
			usertype=userInfoService.getUserTypeById(signupObj.getUserType());
			if(UserValidation.equalsIgnoreCase("success"))
			{
				if(UserInfoValidation.isEmailFormat(signupObj.getEmail()))
				{
					
					if(UserInfoValidation.isAlphaNumeric(signupObj.getPassword()))
					{
						emailCheck=userInfoService.getUserByEmail(signupObj.getEmail());
						if(emailCheck==null)
						{
						user=new UserInfo();
						user.setFirstName(signupObj.getFirstName());
						user.setLastName(signupObj.getLastName());
						user.setEmail(signupObj.getEmail());
						user.setPassword(passwordencoder.encode(signupObj.getPassword()));
						System.out.println(passwordencoder.encode(signupObj.getPassword()));
						user.setActive(true);
						user.setCreated_on(new Date());
						user.setTermsAndConditions(signupObj.isTermsAndCondition());
						user.setSubscribe(signupObj.isSubscribe());
						user.setUserType(usertype);
						if(kioskRepo.getByKioskId(signupObj.getKioskId())==null)
						{
							status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "Kiosk Not Found");
							return new UserInfoMessage(status,null);
						}
						user.setPrimaryLocationPreference(kioskRepo.getByKioskId(signupObj.getKioskId()));
						
						user.setFoodAllergies(signupObj.getFoodAllergies());
						user.setDob(signupObj.getDob());
						for(int i=0;i<signupObj.getUserDietaryPreference().size();i++)
						{
							userDietary=new UserDietaryPreference();
							if(dietaryPreferenceRepo.getDeitaryByDietaryIdAndActive(signupObj.getUserDietaryPreference().get(i).getDietaryId(),true)!=null)
						    {
							userDietary.setDietaryPreference(dietaryPreferenceRepo.getDeitaryByDietaryIdAndActive(signupObj.getUserDietaryPreference().get(i).getDietaryId(),true));
						    }
							else
							{
								status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, "Dietary Id Not Found");
								return new UserInfoMessage(status,null);
							}
							userDietaryPrefList.add(userDietary);
						}
						user.setUserDietaryMap(userDietaryPrefList);
					 userInfoService.registerNewUser(user);
						
						token =  tokenGeneration.loginwithregister(signupObj.getEmail(),signupObj.getPassword());
						status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Success");
						}
						else
						{
							status = new ResponseStatus(ResponseStatusCode.STATUS_ALREADY_EXISTS, "User Already Exists");
						    return new UserInfoMessage(status,null);
						}
						
					}
					else
					{
						status = new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED, "Password should have one number, minimum of eight characters and a symbol");
						 new UserInfoMessage(status);
					}
					
					
				}
				
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED, "Please Check Your Email Pattern");
					return new UserInfoMessage(status);
				}
			}
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_NORECORD, UserValidation);
			}
			
		}
		
		catch(Exception e)
		{
			logger.error("Register User Exception", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"INTERNAL ERROR");
			response.setStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR); 
		}
		
		return new UserInfoMessage(status,user,token);
	}
	
	
	
	public UserInfoMessage loginUser(@FormParam("email") String email,@FormParam("password") String password,@FormParam("devicetoken") String deviceToken,@FormParam("devicetype") String deviceType,final HttpServletResponse response){
		ResponseStatus status = null;
		UserInfo user=null;
		JSONObject token=null;
		//response.setHeader("Cache-Control", "no-cache");
		try{
			user=userInfoService.getUserByEmail(email);
		//	password=passwordencoder.encode(password);
			System.out.println("PASSWORD"+password);
			if(user!=null) {
				System.out.println("CHECK "+passwordencoder.matches(password, user.getPassword()));
				if(!user.isActive())
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_INVALID, "User is not active");
					return new UserInfoMessage(status,null);
				}
				System.out.println(user.getPassword());
				System.out.println(password);

				if(passwordencoder.matches(password, user.getPassword())) {
					System.out.println("equal");
					status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Success");
					token = tokenGeneration.loginwithregister(email,password);
				} 
				else {
					status = new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED, "Invalid Username or Password, please try again!");
					return new UserInfoMessage(status,null);
				}
			} else {
				response.setStatus(ResponseStatusCode.STATUS_INVALID);
				status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"Please Enter Valid Username and Password");
				return new UserInfoMessage(status,null);
			}
		} catch(Exception e) {
			logger.error("Login ", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR, "INTERNAL_ERROR");
		}
		return new UserInfoMessage(status,user,token);
	}
	
	
	public ResponseStatus forgetPassword(@RequestParam("email") String email,final HttpServletResponse response,final HttpServletRequest request)
	{
		ResponseStatus status = null;
		UserInfo userEmailCheck=null;
		VerificationCode verificationcode= new VerificationCode();
		List<VerificationCode> verificationList=null;
		String filepath="";
		try
		{
			filepath=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.getBannerImage();
			if(!email.isEmpty() && email != null)
			{
				System.out.println("INN");
				if(UserInfoValidation.isEmailFormat(email))
				{
					userEmailCheck=userInfoService.getUserByEmail(email);
					if(userEmailCheck==null)
					{
						status = new ResponseStatus(ResponseStatusCode.STATUS_UNAUTHORIZED, "Unauthorized User");
					   return status; 
					}
					verificationList = verificationService.getVerificationListByUserId(userEmailCheck.getUserId());

					if(verificationList != null && verificationList.size() > 0) {
						for(VerificationCode vc : verificationList) {
							vc.setActive(false);
							vc.setUpdatedOn(new Date());
							verificationService.update(vc);

						}
					}
						String values=RandomStringUtils.randomAlphanumeric(8).toUpperCase();
						
						verificationcode.setVerificationCode(commonUtils.generateEncryptedPwd(values));
						verificationcode.setCreatedOn(new Date());
						verificationcode.setUpdatedOn(new Date());
						verificationcode.setUser(userEmailCheck);
						verificationcode.setActive(true);
						verificationService.save(verificationcode);
						
						String imagelogo=CommonProperties.getBaseURL()+CommonProperties.getContextPath()+CommonProperties.gettemplate();
						String name=userEmailCheck.getFirstName()+" "+userEmailCheck.getLastName();
						EmailManager.forgotPwd1(email,values,filepath,name,imagelogo);
						status = new ResponseStatus(ResponseStatusCode.STATUS_OK, "Verification Code has been sent");
						
						}
					
					
				
				else
				{
					status = new ResponseStatus(ResponseStatusCode.STATUS_INVALID, "Please Enter Valid Email Address");
					return status; 
				}
				
			}
			
			else
			{
				status = new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED, "Email Required");
				return status; 
			}
			
		}
			catch(Exception e)
			{
				logger.error("Register User Exception", e);
				status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"INTERNAL ERROR");
				response.setStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR); 
			}
		return status;

	}
	
	
	
	
	public UserMessage resetpassword(@RequestParam("email") String email,@RequestParam("newpassword") String newpassword,@RequestParam("confirmpassword") String confirmpassword,@FormParam("verificationCode") String verificationCode,final HttpServletResponse response){
		ResponseStatus status = null;
		UserInfo user=null;
		UserInfo userInfo=null;
		VerificationCode verificationObj = null;
		response.setHeader("Cache-Control", "no-cache");

		try{

			if(newpassword != null && !newpassword.isEmpty()) {

				if(confirmpassword!=null && !confirmpassword.isEmpty()) 
				{
					if(verificationCode != null && !verificationCode.isEmpty()) {
						if (UserValidation.isAlphaNumeric(newpassword) && UserValidation.isAlphaNumeric(confirmpassword)) {
							System.out.println(newpassword);
							System.out.println(confirmpassword);

							if(newpassword.equals(confirmpassword))
							{

								String encrpted  = commonUtils.generateEncryptedPwd(verificationCode);
								userInfo=email!=null?userInfoService.getUserByEmail(email):null;
								verificationObj = userInfo!=null?verificationService.getVerificationByverificationCode(encrpted,userInfo.getUserId()):null;
								if(verificationObj != null && verificationObj.getUser() != null) {				

									user=userInfoService.getUserById(verificationObj.getUser().getUserId());

									if(user!=null) {
										Instant then = null;
										if (verificationObj != null){
											then = verificationObj.getCreatedOn().toInstant();
										}
										Instant now = Instant.now();
										Instant twentyFourHoursEarlier;
										twentyFourHoursEarlier = now.minus(24, ChronoUnit.HOURS);
										Boolean within24Hours = (then != null) ? (!then.isBefore(twentyFourHoursEarlier)) && then.isBefore(now) : false;
										if(!within24Hours) 
										{
											status=new ResponseStatus(ResponseStatusCode.STATUS_OTP_EXPIRED,"Otp expired");	
											return new UserMessage(status, null);
										}
										user.setPassword(passwordencoder.encode(newpassword));				
										userInfoRepo.save(user);
										verificationObj.setActive(false);
										verificationObj.setUpdatedOn(new Date());
										verificationService.update(verificationObj);
										status=new ResponseStatus(ResponseStatusCode.STATUS_OK,"Password changed successfully");	
									}else {
										status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"user  doesn't exists");
									}
								} else {
									status=new ResponseStatus(ResponseStatusCode.STATUS_NORECORD,"Invalid verification code");
								}
							}

							else {
								status=new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED 	,"password mismatch");
							}

						}


						else
						{
							status=new ResponseStatus(ResponseStatusCode.STATUS_NOTMATCHED,"Password should have one number, minimum of eight characters and a symbol");	
						}

					}
					else
					{
						status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"Verification code is Required");
					}


				}
				else
				{
					status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"confirm password is Required");
				}	

			}
			else
			{
				status=new ResponseStatus(ResponseStatusCode.STATUS_REQUIRED,"new password is Required");
			}


		}

		catch(Exception e) {
			logger.error("resetpassword ", e);
			status = new ResponseStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR,"INTERNAL ERROR");
			response.setStatus(ResponseStatusCode.STATUS_INTERNAL_ERROR); 
		}	

		return new UserMessage(status, null);		
	}
	
	
	
	
	
	
	@SuppressWarnings({ "unchecked", "unused" })
	private JSONObject generateBarcode() throws DocumentException{
		JSONObject json=new JSONObject();
		String values=RandomStringUtils.randomAlphanumeric(13).toUpperCase();
		String path=CommonProperties.getBasePath()+CommonProperties.getImagePath() + CommonProperties.getBarcode();		
		try {
			Barcode128 code128 = new Barcode128();
			code128.setCode(values); 
			java.awt.Image rawImage = code128.createAwtImage(Color.BLACK, Color.WHITE);

			BufferedImage resizedImage = new BufferedImage(500,120, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = resizedImage.createGraphics();
			g.drawImage(rawImage, 0, 0,500,120,null);
			ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
			ImageIO.write(resizedImage, "png", bytesOut);
			g.dispose();

			byte[] pngImageData = bytesOut.toByteArray();
			try(FileOutputStream fos = new FileOutputStream(path+"/"+values+".png"))
			{
			fos.write(pngImageData);
			fos.close();
			json.put("values", values);
			//json.put("path", path1+"/"+values+".png");
			json.put("path", values+".png");			
			return json;
			}
		}
		catch(Exception e){
			logger.error("generateBarcode ", e);
		}	return json;

	}

	
	
	
	
	
	
	

}
