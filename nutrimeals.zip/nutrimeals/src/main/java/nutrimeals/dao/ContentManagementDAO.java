package nutrimeals.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import nutrimeals.domain.ContentManagement;



@Transactional
@Repository
public class ContentManagementDAO implements IContentManagementDAO{

	private static final Logger logger = LoggerFactory.getLogger(ContentManagementDAO.class);
	
	@Autowired
	EntityManager em;
	


	private Session getSession(){ 
		return  em.unwrap(Session.class);
	}
	


	
	@Override
	public List<ContentManagement>  getAllContentManagement()
	{
		List<ContentManagement> list = null;
		try
		{
			TypedQuery<ContentManagement> query =em.createQuery("from ContentManagement", ContentManagement.class);
			list =query.getResultList();
		}
		catch(Exception e)
		{
			logger.error("getAllContentManagement ",e);
		}
		return (list != null && !list.isEmpty())? list:null;
		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public ContentManagement  getContentManagementByContentType(String label)
	{
		List<ContentManagement> list = null;
		try
		{
			list=getSession().createQuery("from ContentManagement where label =:label").setParameter("label", label).list();
			
		}
		catch(Exception e)
		{
			logger.error("getContentManagementByContentType ",e);
		}
		return (list != null && !list.isEmpty())? list.get(0):null;
		
	}
	

	
	
}
