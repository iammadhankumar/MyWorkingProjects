package nutrimeals.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import nutrimeals.domain.ContentInfo;

@SuppressWarnings("unchecked")
@Repository
@Transactional
public class ContentInfoDAO implements IContentInfoDAO {
	
	
	private static final Logger logger = LoggerFactory.getLogger(ContentInfoDAO.class);

	
	@Autowired
	private EntityManager em;
	

	private Session getSession(){
		return  em.unwrap(Session.class);
	
	}

	@Override
	public ContentInfo getSunboxInfo() {
		List<ContentInfo> list = null;
		try {
			list = getSession().createQuery("from ContentInfo where title_id=1").list();
		} catch(Exception e) {
			logger.error("getSunboxInfo ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}

	@Override
	public ContentInfo getPrivacyPolicyInfo() {
		List<ContentInfo> list = null;
		try {
			list = getSession().createQuery("from ContentInfo where title_id=2").list();
		} catch(Exception e) {
			logger.error("getPrivacyPolicyInfo ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;

	}

	@Override
	public ContentInfo getTermsInfo() {
		List<ContentInfo> list = null;
		try{
			list = getSession().createQuery("from ContentInfo where title_id=1").list();
		} catch(Exception e) {
			logger.error("getTermsInfo ",e);
		}		
		return (list!=null && list.size()>0)?list.get(0):null;
	}

	@Override
	public void update(ContentInfo contentInfo) {
		try {
			getSession().update(contentInfo);
		} catch(Exception e) {
			logger.error("update ",e);
		}
	}
}