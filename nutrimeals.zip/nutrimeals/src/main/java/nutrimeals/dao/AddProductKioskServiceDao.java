package nutrimeals.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import nutrimeals.domain.ProductKiosk;
import nutrimeals.repository.ProductKioskRepository;

@Repository("IAddProductKioskServiceDao")
@Transactional
public class AddProductKioskServiceDao implements IAddProductKioskServiceDao {
	
	private static final Logger logger = LoggerFactory.getLogger(AddProductKioskServiceDao.class);

	@Autowired
	private EntityManager em;
	
	@Autowired
	ProductKioskRepository pkRepo;
	
	

	
	public ProductKiosk getKioskBypId(long product_id) {
		List<ProductKiosk> list = null;
		try {
			TypedQuery<ProductKiosk> q=em.createQuery("from ProductKiosk where product.id=:product_id",ProductKiosk.class).setParameter("product_id", product_id);
			list=q.getResultList();
		} catch(Exception e) {
			logger.error("getKioskBypId ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	public ProductKiosk getProductKioskBypId(long id) {
		List<ProductKiosk> list = null;
		try {
			TypedQuery<ProductKiosk> q=em.createQuery("from ProductKiosk where id=:pk",ProductKiosk.class).setParameter("pk", id);
			list=q.getResultList();

		} catch(Exception e) {
			logger.error("getProductKioskBypId ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	
	
	public ProductKiosk getProductKioskByproductId(long productId,long kioskid) {
		List<ProductKiosk> list = null;
		try {
			TypedQuery<ProductKiosk> q=em.createQuery("from ProductKiosk where product.id=:productId and kiosk.id=:kioskid",ProductKiosk.class).setParameter("productId", productId).setParameter("kioskid", kioskid);
			list=q.getResultList();
		} catch(Exception e) {
			logger.error("getProductKioskByproductId ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	
	public ProductKiosk getProductkiosk_id(long kioskId) {
		List<ProductKiosk> list = null;
		try {
			TypedQuery<ProductKiosk> q=em.createQuery("select id from ProductKiosk where kiosk.id=:kioskId",ProductKiosk.class).setParameter("kioskId", kioskId);
			list = q.getResultList();
		} catch(Exception e) {
			logger.error("getProductkiosk_id ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	

	public List<ProductKiosk> getAllProductlistByProductTypeandKiosk(long kioskId,List<Long> productObj,long productType,int pagenumber,int pagerecord)
	{
		List<ProductKiosk> list=null;
		try
		{   
						
			TypedQuery<ProductKiosk> q=em.createQuery("from ProductKiosk where kiosk.id=:kioskId and product IN (select productObj from Product where productType.id=:productType)",ProductKiosk.class).setParameter("kioskId", kioskId);
			
			System.out.println("PAGE NUMBER :"+pagenumber);
			System.out.println("PAGE Record :"+pagerecord);
		

			 if(pagenumber > 0 && pagerecord > 0)
			 {
				 System.out.println("IN PAGINATION");
			q.setFirstResult(((pagenumber-1) * pagerecord));
		      q.setMaxResults(pagerecord);
			 }
			
			list = q.getResultList();

		}
		catch(Exception e) {
			logger.error("getAllProductlistByProductTypeandKiosk ",e);
		}
	return (list!=null && list.size()>0)?list:null;
	}
	
	public ProductKiosk getProductkiosk(long pid) {
		List<ProductKiosk> list = null;
		try {
			TypedQuery<ProductKiosk> q=em.createQuery("from ProductKiosk where product.id=:pid",ProductKiosk.class).setParameter("pid", pid);
			list=q.getResultList();
		} catch(Exception e) {
			logger.error("getProductkiosk ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}
	
	public ProductKiosk getProductAndKiosk(long productId) {
		List<ProductKiosk> list = null;
		try { 	
			TypedQuery<ProductKiosk> q=em.createQuery("from ProductKiosk where product.id=:productId",ProductKiosk.class).setParameter("productId", productId);
					list=q.getResultList();
		} catch(Exception e) {
			logger.error("getProductAndKiosk ",e);
		}
		return (list!=null && list.size()>0)?(ProductKiosk)list.get(0):null;
	}
	
	
	public List<ProductKiosk> getProductKioskId(long productId) {
		List<ProductKiosk> list = null;
		try { 
			
			TypedQuery<ProductKiosk> q=em.createQuery("from ProductKiosk where product.id=:productId",ProductKiosk.class).setParameter("productId", productId);
			list=q.getResultList();
		} catch(Exception e) {
			logger.error("getProductKioskId ",e);
		}
		return (list!=null && !list.isEmpty())?list:null;
	}
	
	

	public ProductKiosk registerNewProductKiosk(ProductKiosk productkiosk) {
	
		ProductKiosk pk=null;
		try {
			pk =pkRepo.save(productkiosk);
		} catch(Exception e) {		
			logger.error("registerNewProductKiosk ",e);
		}
		return pk;
	}


	@Override
	public List<ProductKiosk> getAllProductlist(long kiosk_id ,long product_type_id,String searchText) {
		List<ProductKiosk> list = null;
		try {
			
			if(product_type_id <= 0) {
				TypedQuery<ProductKiosk> q=em.createQuery("from ProductKiosk where kiosk.kioskId =:kiosk_id",ProductKiosk.class).setParameter("kiosk_id", kiosk_id);
			   list=q.getResultList();
			}
			else if(product_type_id > 0) {
				TypedQuery<ProductKiosk> q=em.createQuery("from ProductKiosk where kiosk.kioskId =:kiosk_id and product.id IN (select id from Product where productType.id = :product_type_id and productName like '%"+searchText+"%')",ProductKiosk.class).setParameter("kiosk_id", kiosk_id).setParameter("product_type_id", product_type_id);
				   list=q.getResultList();

			}
			
		} catch(Exception e) {
			logger.error("getAllProductlist ",e);

		}
		return list;
		
				}
	

	@Override
	public ProductKiosk checkQuantity(long productkiosk_id) {
		List<ProductKiosk> list = null;
		try {
			TypedQuery<ProductKiosk> q=em.createQuery("from ProductKiosk where productkiosk_id=?",ProductKiosk.class).setParameter(0, productkiosk_id);
		   list=q.getResultList();
		} catch(Exception e) {
			logger.error("checkQuantity ",e);
		}
		return (list!=null && !list.isEmpty())?(ProductKiosk)list.get(0):null;
	}

	@Override
	public void updateProductKiosk(ProductKiosk productKiosk) {
		try {
			pkRepo.save(productKiosk);
		} catch(Exception e) {
			logger.error("updateProductKiosk ",e);
		}	
	}
	
	@Override
	public ProductKiosk getKioskByProductKioskId(long productkioskid) {
		List<ProductKiosk> list = null;
		try {
			TypedQuery<ProductKiosk> q = em.createQuery("from ProductKiosk where id=:productkioskid ",ProductKiosk.class).setParameter("productkioskid",productkioskid);
		     list=q.getResultList();
		} catch(Exception e) {
			logger.error("getKioskByProductKioskId ",e);
}
		return (list!=null && list.size()>0)?(ProductKiosk)list.get(0):null;
		
}
	
	
	@Override
	public List<Long> getKioskIdByProductKioskId(List<ProductKiosk> productkioskid) {

		List<Long> list = null;
		try {
			System.out.println("kiosk id dao");
			TypedQuery<Long>  q= em.createQuery("select kiosk.id from ProductKiosk where id=:productkioskid ",Long.class).setParameter("productkioskid",productkioskid);
            list=q.getResultList();
		} catch(Exception e) {
			logger.error("getKioskIdByProductKioskId ",e);
}
		return (list!=null && list.size()>0)?list:null;
		
}
	
	@Override
	public List<ProductKiosk> getProductKioskbyKiosk(long kioskId)
	{
		List<ProductKiosk> list=null;
		try
		{
           TypedQuery<ProductKiosk> q=em.createQuery("from ProductKiosk where kiosk.id=:kioskId",ProductKiosk.class).setParameter("kioskId", kioskId);
           list=q.getResultList();
		}

		catch(Exception e) 
		{
			logger.error("getProductKioskbyKiosk ",e);
		}
		return (list!=null && !list.isEmpty())?list:null;
	}	

	
	
	@Override
	public ProductKiosk getProductKioskByProductandKioskId(long kioskId,long productId) 
	{
		List<ProductKiosk> list = null;
		try {
			TypedQuery<ProductKiosk> q = em.createQuery("from ProductKiosk where kiosk.id=:kioskId and product.id=:productId ",ProductKiosk.class).setParameter("kioskId",kioskId).setParameter("productId",productId);
             list=q.getResultList();
		} catch(Exception e) {
			logger.error("getProductKioskByProductandKioskId ",e);
}
		return (list!=null && list.size()>0)?(ProductKiosk)list.get(0):null;
		
}
	
	
	
	@Override
	public ProductKiosk getProductKioskInfo(long kioskId,long productId,long qt) 
	{
		List<ProductKiosk> list = null;
		try {
			TypedQuery<ProductKiosk> q = em.createQuery("from ProductKiosk where kiosk.id=:kioskId and product.id=:productId and quantity=:qt",ProductKiosk.class).setParameter("kioskId",kioskId).setParameter("productId",productId).setParameter("qt",qt);
		    list=q.getResultList();
		
		} catch(Exception e) {
			logger.error("getProductKioskInfo ",e);
}
		return (list!=null && !list.isEmpty())?(ProductKiosk)list.get(0):null;
		
}


	@Override
	public List<Long> getKioskByproductId(long pid) {

		List<Long> list = null;
		try
		{
			TypedQuery<Long> q = em.createQuery("select kiosk.id from ProductKiosk where product.id=:pid and quantity>0 ",Long.class).setParameter("pid",pid);
            list=q.getResultList();
		}
		catch(Exception e) {
			logger.error("getKioskByproductId ",e);
}
		return (list!=null && !list.isEmpty())?list:null;
	}


	@Override
	public long getKioskCount(long pid) {
		long count = 0;
		try
		{
			TypedQuery<Long> q = em.createQuery("from ProductKiosk where product.id=:pid ",Long.class).setParameter("pid",pid);
			count=q.getSingleResult();
		}
		catch(Exception e) {
			logger.error("getKioskCount ",e);
}
		return count;
	}


	

	@Override
	public void updateProductKioskQuantity(long qt,long pid)
	{
		try
		{
	     em.createQuery("Update ProductKiosk SET quantity=:qt where id=:pid").setParameter("qt",qt).setParameter("pid",pid).executeUpdate();
		}
		
		catch(Exception e) {
			logger.error("updateProductKioskQuantity ",e);
		}
	
		
	}
	
	
	@Override
	public List<Long> getProductByKioskId(long kioskId) 
	{
		List<Long> list = null;
		try {
			TypedQuery<Long> q = em.createQuery("select product.id from ProductKiosk where kiosk.id=:kioskId",Long.class).setParameter("kioskId",kioskId);
			list=q.getResultList();
		} catch(Exception e) {
			logger.error("getProductByKioskId ",e);
}
		return (list!=null && !list.isEmpty())?list:null;
		
}


	@Override
	public ProductKiosk getByProductAndKioskId(long primarypId, long kioskId) {
		List<ProductKiosk> list = null;
		try {
			TypedQuery<ProductKiosk> q = em.createQuery("from ProductKiosk where kiosk.id=:kioskId and product.id=:primarypId",ProductKiosk.class).setParameter("kioskId",kioskId).setParameter("primarypId", primarypId);
		   list=q.getResultList();
		} catch(Exception e) {
			logger.error("getByProductAndKioskId ",e);
}
		return (list!=null && !list.isEmpty())?list.get(0):null;
		
	}


	@Override
	public ProductKiosk getProductQuantityByKiosk(long pid, long kid) {
		List<ProductKiosk> list = null;
		try {
			TypedQuery<ProductKiosk> q = em.createQuery("from ProductKiosk where kiosk.id=:kid and product.id=:primarypId",ProductKiosk.class).setParameter("kid",kid).setParameter("primarypId", pid);
		     list=q.getResultList();
		} catch(Exception e) {
			logger.error("getProductQuantityByKiosk ",e);
}
		return list!=null?list.get(0):null;
}

	@Override
	public List<ProductKiosk> getAllProductListByProductTypeandKiosk(long kioskId, List<Long> productObj,
			long productType, int pagenumber, int pagerecord) {
	
		return null;
	}
	
}

	

	
	

	
	
	
	
	
	
	
	
	
	
	

