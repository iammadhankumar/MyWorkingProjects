package nutrimeals.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import nutrimeals.domain.Basket;
import nutrimeals.domain.BasketStatus;
import nutrimeals.domain.Kiosk;
import nutrimeals.views.CartListView;


@Repository("IBasketDAO")
@Transactional
public class BasketDAO  implements IBasketDAO{
	
	private static final Logger logger = LoggerFactory.getLogger(BasketDAO.class);

//	
//	@Autowired
//	private SessionFactory sessionFactory;
//
//	private Session getSession1(){
//		return sessionFactory.getCurrentSession();
//	}

	
	@Autowired
	private EntityManager em;
	
	private Session getSession(){
		return  em.unwrap(Session.class);
	
	}

	@Override
	public long registerNewToBasket(Basket basket) {
		Long id = -1L;
		try {
			id=(Long) getSession().save(basket);
		} catch(Exception e) {		
			logger.error("registerNewToBasket ",e);
		}
		return id;
	}
	
	
	
	@Override
	public void delete(long bid) {
		try {			
			getSession().createQuery("Update Basket SET active=0 where bid= ?").setParameter(0,bid).executeUpdate();
		} catch(Exception e) {
			logger.error("delete ",e);
		}
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Basket> getBasket() {
		List<Basket> list = null;
		try {
			list=getSession().createQuery("from Basket where active=1").list();
		} catch(Exception e) {
			logger.error("getBasket ",e);
		}
		return list;
		
				}
	
	
	@Override
	public List<Basket> getBasketbyList(List<Long> bid) {
		List<Basket> list = null;
		try {
//	          CriteriaBuilder cb=em.getCriteriaBuilder();  
//	          AbstractQuery<Basket> cq=cb.createQuery(Basket.class);  
//	          Root<Basket> bask=cq.from(Basket.class); 
	          //cq.where(cb.eq(bask.get("s_age"),cb).value(22).value(24));  
			
//		    CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
//		    CriteriaQuery <Basket> criteriaQuery = criteriaBuilder.createQuery(Basket.class);
//		    Root <Basket> root = criteriaQuery.from(Basket.class);
//
//	       //  list.add(criteriaBuilder.like(root.get(Basket_.active),true));

//
//			list=em.createQuery("")
//
//
//
//
//			Criteria c=getSession().createCriteria(Basket.class);
//			c.add(Restrictions.eq("active",true)).
//			add(Restrictions.in("bid", bid));
//			list = c.list();
		} catch(Exception e) {
			logger.error("getBasketbyList ",e);
		}
		return (list!=null && list.size()>0)?list:null;
		
				}
	
	
	
	@Override
	public List<Basket> getBasketbyListCheck(List<Long> bid,long userId)
	{
		List<Basket> list = null;
		try {
			
			list=em.createQuery("from Basket where active=1 and user.userId=:userId and bid in(:bid)",Basket.class).setParameter("bid", bid).setParameter("userId", userId).getResultList();

//			Criteria c=getSession().createCriteria(Basket.class);
//			c.add(Restrictions.eq("active",true)).
//		   add(Restrictions.eq("user.id", userId)).   
//			add(Restrictions.in("bid", bid));
//			list = c.list();
		} catch(Exception e) {
			logger.error("getBasketbyListCheck ",e);
		}
		return (list!=null && list.size()>0)?list:null;
		
				}
	
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Basket> getBasketbyRewardPurchase(List<Long> bid,long userId) {
		List<Basket> list = null;
		try {

			
			list=em.createQuery("from Basket where active=1 and rewardsUsed=1 and user.userId=:userId and bid in(:bid) ").setParameter("bid",bid).setParameter("userId", userId).getResultList();
//			Criteria c=getSession().createCriteria(Basket.class);
//			c.add(Restrictions.eq("active",true)).
//		    add(Restrictions.eq("rewardsUsed",true)).
//		    add(Restrictions.eq("user.userId",userId)).
//			add(Restrictions.in("bid", bid));
//			list = c.list();
		} catch(Exception e) {
			logger.error("getBasketbyRewardPurchase ",e);
		}
		return (list!=null && list.size()>0)?list:null;
		
				}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Basket> getBasketByIdandPurchase(Long userId,boolean purchase){
		List<Basket> list = null;
		try {
			list=getSession().createQuery("from Basket where active=1 and purchase = :purchase")
					.setParameter("purchase", purchase).list();
		} catch(Exception e) {
			logger.error("getBasketByIdandPurchase ",e);
		}
		return (list!=null && !list.isEmpty())?list:null;
		
	}

		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getBid(Long bid) {
			List<Basket> list = null;
			try {
				list=getSession().createQuery("from Basket where bid=:bid and active=1").setParameter("bid", bid).list();
			
			} catch(Exception e) {
				logger.error("getBid ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
	}

		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getBasketByBid(long bid) {
			List<Basket> list = null;
			try {
				list=getSession().createQuery("from Basket where bid=:bid").setParameter("bid", bid).list();
			
			} catch(Exception e) {
				logger.error("getBasketByBid ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
	}
		
		
	

		
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getBasketId(long bid) {
			List<Basket> list = null;
			try {
				System.out.println("buc id query:"+bid);
				list=getSession().createQuery("from Basket where bid=:bid and active=1 ").setParameter("bid", bid).list();
			
			} catch(Exception e) {
				logger.error("getBasketId ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
	}
		
		@SuppressWarnings("unchecked")
		public List<Basket> getBasketByRewards(List<Long> bid)
		{
		List<Basket> list = null;
		try {
			System.out.println("buc id query:"+bid);
			
		list=em.createQuery("from Basket where active=1 and rewardsUsed=0 and bid in(:bid)").setParameter("bid", bid).getResultList();	
			
//			Criteria c=getSession().createCriteria(Basket.class);
//			c.add(Restrictions.eq("active",true)).
//			//add(Restrictions.eq("rewardsUsed",false)).
//			add(Restrictions.in("bid", bid));
//			list = c.list();
			
		
		} catch(Exception e) {
			logger.error("getBasketByRewards ",e);
		}
		return (list!=null && !list.isEmpty())?list:null;
}
		
		
		@SuppressWarnings("unchecked")
		public Basket getBasketByRewardsCheck(long bid)
		{
		List<Basket> list = null;
		try {
			list=getSession().createQuery("from Basket where bid IN(select bid from Basket) and active=1 and rewardsUsed=0;").setParameter("bid", bid).list();
		
		} catch(Exception e) {
			logger.error("getBasketByRewardsCheck ",e);
		}
		return (list!=null && !list.isEmpty())?list.get(0):null;
}

		@SuppressWarnings("unchecked")
		@Override
		public Basket getProductkioskAndUser(long productkiosk_id, long user_id) {
			List<Basket> list = null;
			try { 
				
				
				list=getSession().createQuery("from Basket where ProductKiosk.productkiosk_id=? and user.user_id=? and active=1")
						.setParameter(0, productkiosk_id)
						.setParameter(1, user_id).list();
			} catch(Exception e) {
				logger.error("getProductkioskAndUser ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
		}

		@Override
		public void updateBasket(Basket basket) {

			try {
				getSession().update(basket);
			} catch(Exception e) {
				logger.error("updateBasket ",e);
			}
		}

		@Override
		public long getBasketByIdandPurchaseCount(long userId, boolean purchase) {
			long basketcount = 0;
			try {
				basketcount = getSession().createQuery("from Basket where active=1 and user.user_id = :userId and purchase = :purchase").setParameter("userId", userId)
				.setParameter("purchase", purchase).list().size();
			} catch(Exception e) {
				logger.error("getBasketByIdandPurchaseCount ",e);
			}
			return basketcount;
			
		}

		@Override
		public void updateBasketQuantity(long qt,long pid)
		{
			
			try
			{
	        	getSession().createQuery("Update Basket SET quantity=:qt where ProductKiosk.id=:pid").setParameter("qt",qt).setParameter("pid",pid).executeUpdate();
			}
			
			catch(Exception e) {
				logger.error("updateBasketQuantity ",e);
			}
			
			
		}
		
		@Override
		public List<Basket> getpaypalid(long paypalId) {

			List<Basket> list = null;
			try {
				list=em.createQuery("from Basket where basketStatus=2 and payPalTransaction.PaypalId=?",Basket.class).setParameter(0, paypalId).getResultList();
			
			} catch(Exception e) {
				logger.error("getpaypalid ",e);
			}
			return (list!=null && !list.isEmpty())?list:null;
			
	}

		@Override
		public BasketStatus setBasketStatus(long id) {
			List<BasketStatus> list = null;
			try {
				list=em.createQuery("from BasketStatus where basketStatusId=:id",BasketStatus.class).setParameter("id", id).getResultList();
			
			} catch(Exception e) {
				logger.error("setBasketStatus ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
			
	}
		
		

		@Override
		public Kiosk getKioskbyProduct(long pid)
		{
		List<Kiosk> list=null;
			try
			{
				list=em.createQuery("Select kiosk.id from Product where id=:pid",Kiosk.class).setParameter("pid",pid).getResultList();

			}
			
		
			catch(Exception e) {
				logger.error("getKioskbyProduct ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
		}


		@Override
		public List<Basket> getBasketByIdandPurchaseandstatus(long userId, long basketStatusId, boolean purchase) {
			
				List<Basket> list = null;
				try {   
				
					list=em.createQuery("from Basket where active=1 and purchase=:purchase  and user.user_id=:userId and basketStatus.basketStatusId=:basketStatusId",Basket.class).setParameter("purchase", purchase).setParameter("userId", userId).setParameter("basketStatusId", basketStatusId).getResultList();
				} catch(Exception e) {
					logger.error("getBasketByIdandPurchaseandstatus ",e);
				}
				return (list!=null && !list.isEmpty())?list:null;
				
			}

	
		
		
		@Override
		public List<Basket> getAllBasketByStatus(long basketstatusId) {

			List<Basket> list = null;
			try {

			//	TypedQuery<Basket> sub3Week = em.createSQLQuery("select DATE_SUB( NOW() , INTERVAL 1 HOUR ) ");
				///List<Date> sub3WeekList = sub3Week.getResultList();
			//	System.out.println(sub3WeekList.get(0).toString());
				//DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				//list=getSession().createQuery("from Basket where active=1 and basketStatus.basketStatusId = :basketstatusId and payPalTransaction.created_on <= :createdDate").setParameter("basketstatusId", basketstatusId).setParameter("createdDate", sdf.parse(sub3WeekList.get(0).toString())).list();
			
			} catch(Exception e) {
				logger.error("getAllBasketByStatus ",e);
			}
			return (list!=null && !list.isEmpty())?list:null;

}

		
		

		@Override
		public Basket getBasket(long userId) {

			List<Basket> list = null;
			try {
				System.out.println("in dao");
				list= em.createQuery(" from Basket where active=1 and basketStatus.basketStatusId =1 and user.user_id = :userId ",Basket.class).setParameter("userId", userId).getResultList();
			
			System.out.println(list);
			}catch(Exception e) {
				logger.error("getBasket ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
					
		}
		
		
		

		@Override
		public List<Basket> getBasketByUser(long userId,List<Long> bid) {

			List<Basket> list = null;
			try {
				list= em.createQuery(" from Basket where bid In(:bid) and active=1 and basketStatus.basketStatusId =1 and user.userId = :userId and purchase=0 ",Basket.class).setParameter("userId", userId).setParameter("bid", bid).getResultList();
			
			System.out.println(list);
			}catch(Exception e) {
				logger.error("getBasketByUser ",e);
			}
			return (list!=null && !list.isEmpty())?list:null;
					
		}
		

		

		@Override
		public List<Basket> getBasketInfo(long userId) {
			List<Basket> list = null;
			try {
				list= em.createQuery(" from Basket where active=1 and basketStatus.basketStatusId =1 and user.user_id = :userId ",Basket.class).setParameter("userId", userId).getResultList();
						}catch(Exception e) {
				logger.error("getBasketInfo ",e);
			}
			return (list!=null && !list.isEmpty())?list:null;
					
		}
		

		
		
		
		@Override
       public List<Basket> getBasketlist(long user_id,int pagenumber, int pagerecord) {
			
			List<Basket> list = null;
			TypedQuery<Basket> q=null;
			try {
				q= em.createQuery(" from Basket where active=1 and basketStatus.basketStatusId =1 ",Basket.class);
				 if(pagenumber > 0 && pagerecord > 0)
	    		 {
	    		q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
	    		 }
	    	
	    		list=q.getResultList() ;
						
			} catch(Exception e) {
				logger.error("getBasketlist ",e);
			}
			return (list!=null && !list.isEmpty())?list:null;
			
	}

        
     
		@SuppressWarnings("unchecked")
		@Override
		public List<CartListView> getBasketlistByUserid(long user_id) {

			System.out.println(user_id);
			
			List<CartListView> list = null;
			try {
				list= em.createQuery(" from CartListView where active=1 and purchase=0 and userId = :user_id ").setParameter("user_id", user_id).getResultList();
			
			} catch(Exception e) {
				logger.error("getBasketlistByUserid ",e);
			}
			return (list!=null && !list.isEmpty())?list:null;
			
	}

		
		@SuppressWarnings("unchecked")
		@Override
		public List<Basket> getBasketByrewardsCheck(long user_id) {
			System.out.println(user_id);
			
			List<Basket> list = null;
			try {
				list= em.createQuery(" from Basket where active=1 and rewardsUsed=1 and user.user_id = :user_id ").setParameter("user_id", user_id).getResultList();
			
			} catch(Exception e) {
				logger.error("getBasketByrewardsCheck ",e);
			}
			return (list!=null && !list.isEmpty())?list:null;
			
	}

		
		
		
		
		@SuppressWarnings("unchecked")
		@Override
		public List<Basket> getBasketBypaypalid(long paypalId) {

			System.out.println(paypalId);
			List<Basket> list = null;
			try {
				list=getSession().createQuery("from Basket where payPalTransaction.PaypalId=?").setParameter(0, paypalId).list();
			
			} catch(Exception e) {
				logger.error("getBasketBypaypalid ",e);
			}
			return (list!=null && !list.isEmpty())?list:null;
			
	}

		@Override
		public long getBasketCount(long userId) {
			long basketcount = 0;
			try {
				basketcount = getSession().createQuery("from Basket where active=1 and user.userId = :userId").setParameter("userId", userId)
				.list().size();
			} catch(Exception e) {
				logger.error("getBasketCount ",e);
			}
			return basketcount;
			
		}

		@SuppressWarnings("unchecked")
		@Override
		public List<Basket> getbasketforkioskcheck(long user_id) {
  	
			List<Basket> list = null;
			try {
				list= getSession().createQuery("from Basket where active=1 and purchase=0 and user.user_id = :user_id ").setParameter("user_id", user_id).list();
			
			} catch(Exception e) {
				logger.error("getbasketforkioskcheck ",e);
			}
			
			return (list!=null && !list.isEmpty())?list:null;
			
		}
		
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getQuantityOfBasketProduct(long user_id) {
			List<Basket> list = null;
			try {
				list= getSession().createQuery("select quantity from Basket where user.user_id = :user_id ").setParameter("user_id", user_id).list();
			
			} catch(Exception e) {
				logger.error("getQuantityOfBasketProduct ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
			
		}
		
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getKioskByBasketProductKioskId(long productKioskId)
		{
			List<Basket> list = null;
			try
			{
				list= getSession().createQuery(" from Basket where ProductKiosk = :productKioskId ").setParameter("productKioskId", productKioskId).list();
			}
			catch(Exception e) {
				logger.error("getKioskByBasketProductKioskId ",e);
			}
			
			return (list!=null && !list.isEmpty())?list.get(0):null;
			
		}
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getProductKioskUser(long productKioskId)
		{
			List<Basket> list=null;
			try
			{
				list= getSession().createQuery(" from Basket where ProductKiosk = :productKioskId ").setParameter("productKioskId", productKioskId).list();
			      
			}
			
			catch(Exception e) {
				logger.error("getProductKioskUser ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
		}
		
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getProductKioskByUser(long userId)
		{
			List<Basket> list=null;
			try
			{
				list= getSession().createQuery(" from Basket where user.user_id = :userId ").setParameter("userId", userId).list();
			}
			
			catch(Exception e) {
				logger.error("getProductKioskByUser ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
		}

		@SuppressWarnings("unchecked")
		@Override
		public List<Basket> getBasketlistByUseridwithpagination(long userId, int pagenumber, int pagerecord) {
			List<Basket> list = null;
			TypedQuery<Basket> q=null;
			try {
				q= getSession().createQuery(" from Basket where active=1 and user.user_id = :userId ");
				 q.setParameter("userId", userId);
				
				if(pagenumber > 0 && pagerecord > 0)
	    		 {
	    		q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
	    		 }
	    	
	    		list=q.getResultList();
						
			} catch(Exception e) {
				logger.error("getBasketlistByUseridwithpagination ",e);
			}
			return (list!=null && !list.isEmpty())?list:null;
			
		}

		@SuppressWarnings("unchecked")
		@Override
		public Basket getbyproductkioskid(long id) {
			List<Basket> list = null;
			try {
				list=getSession().createQuery("from Basket where ProductKiosk.id=:id").setParameter("id", id).list();
			
			} catch(Exception e) {
				logger.error("getbyproductkioskid ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
			
	}

		@SuppressWarnings("unchecked")
		@Override
		public Basket getbasketbyproductkioskidanduserid(long id, long userId) {
			List<Basket> list = null;
			try {
				list=getSession().createQuery("from Basket where ProductKiosk.id=:id and user.user_id = :userId and active=1").setParameter("id", id)
						.setParameter("userId", userId)
						.list();
			
			} catch(Exception e) {
				
				logger.error("getbasketbyproductkioskidanduserid ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
			
		
}
	
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getbasketbyCartDetails(long pid,long userId) {
			List<Basket> list = null;
			try {
				list=getSession().createQuery("from Basket where ProductKiosk.product.id=:pid and user.user_id = :userId and active=1")
						.setParameter("pid", pid)
						.setParameter("userId", userId)
						.list();
			} catch(Exception e) {
				
				logger.error("getbasketbyCartDetails ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
			

}
		
		@SuppressWarnings("unchecked")
		@Override
		public Basket getbasketDetailsbypid(long pid,long userId) {
			List<Basket> list = null;
			try {
				list=getSession().createQuery("from Basket where productKiosk.id=:pid and user.userId = :userId and active=1")
						.setParameter("pid", pid)
						.setParameter("userId", userId)
						.list();
			} catch(Exception e) {
				
				logger.error("getbasketDetailsbypid ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
			

}
		
		

		@Override
		public void UpdateBasketActive(long bid) {
			try {			
				getSession().createQuery("Update Basket SET active=0,purchase=1 where id=:bid").setParameter("bid",bid).executeUpdate();
			} catch(Exception e) {
				logger.error("UpdateBasketActive",e);
			}
		}

		@SuppressWarnings("unchecked")
		@Override
		public List<Basket> getBasketListByUser(long userId) {
			List<Basket> list=null;
			try
			{
				list=getSession().createQuery("from Basket where user.id=:userId and active=1").setParameter("userId",userId).list();
			}
			catch(Exception e) {
				logger.error("getBasketListByUser",e);
			}
			return (list!=null && !list.isEmpty())?list:null;
		}

		@SuppressWarnings("unchecked")
		@Override
		public Basket getBasketByProductKioskAndUser(long id, long userId) {
			List<Basket> list=null;
			try
			{
				list=getSession().createQuery("from Basket where productKiosk.id=:id and  user.userId=:userId and active=1").setParameter("id",id).setParameter("userId", userId).list();
			}
			catch(Exception e) {
				logger.error("getBasketByProductKioskAndUser",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
		}

		@Override
		public boolean getBasketByProductKioskandUser(long id, long userId) {
			long count=0;
			try
			{
				count=getSession().createQuery("from Basket where productKiosk.id IN (select productKiosk.id from Basket where productKiosk.id=:id and user.id=:userId) and active=1").setParameter("id",id).setParameter("userId", userId).list().size();
			}
			catch(Exception e) {
				logger.error("getBasketByProductKioskandUser",e);
			}
			return count>0?true:false;
		}

		@Override
		public double getSumOfBasketPrice(long userId) {
			double sum=0;
		
			try
			{
			

	
				TypedQuery<Double> q = em.createQuery("select COALESCE(sum(price),0) from Basket where user.userId=:userId and purchase=0 and active=1",Double.class).setParameter("userId", userId);
			      sum=q.getSingleResult();

		
			}
			catch(Exception e) {
				logger.error("getSumOfBasketPrice",e);
			}
			return sum;
		}

		   
		@Override
		public double getSumOfBaskets(long userId) {
			double sum=0;
		
			try
			{
//				Criteria criteria = getSession().createCriteria(Basket.class);
//				   criteria.add(Restrictions.eq("active", true));
//				   criteria.add(Restrictions.eq("purchase", false));
//				   criteria.add(Restrictions.eq("user.userId", userId));
//				   criteria.setProjection(Projections.sum("price"));
//	
//				   Double sum2 = (Double) criteria.uniqueResult();
//				   Long sum3 = (Long) criteria.uniqueResult();
//				   
//				
//				   System.out.println(sum2);
//				   System.out.println(sum3);

				   
			}
			catch(Exception e) {
				logger.error("getSumOfBaskets",e);
			}
			return sum;
	
		}
		@Override
		public long getBasketCountByQuantity(long userId) {
			long count=0;
			try
			{

				TypedQuery<Long> q = em.createQuery("select COALESCE(sum(quantity),0) from Basket where user.userId=:userId and purchase=0 and active=1",Long.class).setParameter("userId", userId);

                 count=q.getSingleResult();
				
			}
			catch(Exception e) {
				logger.error("getBasketCountByQuantity",e);
			}
			return count;
		}

		@Override
		public Basket getBasketByBasketIdandUser(long bid, long userId) {
		List<Basket> list=null;
		try
		{
			list=em.createQuery("from Basket where bid=:bid and user.userId=:userId and active=1",Basket.class).setParameter("bid",bid).setParameter("userId", userId).getResultList();

		}
		catch(Exception e) {
			logger.error("getBasketByBasketIdandUser",e);
		}
		return (list!=null && !list.isEmpty())?list.get(0):null;
		}

		@Override
		public void updaterewardsInBasket(long userId) {
			try
			{
				em.createQuery("update Basket set reward.id=1,rewardsUsed=1 where user.id=:userId").setParameter("userId",userId).executeUpdate();

			}
			catch(Exception e) {
				logger.error("updaterewardsInBasket",e);
			}
		}

		@Override
		public void removeRewards(long userId) {
			try
			{
				em.createQuery("update Basket set reward=null,rewardsUsed=0 where user.id=:userId").setParameter("userId",userId).executeUpdate();

			}
			catch(Exception e) {
				logger.error("removeRewards",e);
			}
			
		}
		

		@Override
		public Basket getBasketByProductKiosk(long pkid) {
			List<Basket> list=null;
			try
			{
				list=em.createQuery("from Basket where active=1 and purchase=0 and productKiosk.id=:pkid",Basket.class).setParameter("pkid", pkid).getResultList();
			}
			catch(Exception e)
			{
				logger.error("getBasketByProductKiosk ",e);

			}

			return list!=null && !list.isEmpty()?list.get(0):null;
		}




		}

		
		
		
		



