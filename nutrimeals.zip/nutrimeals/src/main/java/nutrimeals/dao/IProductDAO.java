package nutrimeals.dao;
import java.util.List;

import nutrimeals.domain.DietaryPreference;
import nutrimeals.domain.FavProduct;
import nutrimeals.domain.Product;
import nutrimeals.domain.ProductKiosk;
import nutrimeals.views.ProductView;


public interface IProductDAO 
{
	
	public  long getAllDietaryPreferenceListCount();
	public  List<DietaryPreference> getAllDietaryPreferenceList(int pagenumber,int pagerecord);
	public List<Product> getAllProductList(int pagenumber,int pagerecord);
	public List<Product> searchProductList(String searchValue,long categoryId,long kid,int pagenumber,int pagerecord);
	public List<FavProduct> getAllFavProductList(long userid,int pagenumber, int pagerecord);
	public Product getProductById(long pid);
	public List<Product> getProductsByCategory(long categoryId, int pagenumber, int pagerecord);
	public long getProductCountByCategory(long categoryId);
	public List<ProductView> getAllProductByKiosk(long kid, String searchValue, long categoryId, int pagenumber, int pagerecord);
	long getAllProductCountByKiosk(long kid,String searchValue,long categoryId);
	public long searchProductListCount(String searchValue,long kid);
	public ProductKiosk getQuantityByKiosk(long kid, long pid);

}
