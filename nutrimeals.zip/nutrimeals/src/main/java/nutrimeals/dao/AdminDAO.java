package nutrimeals.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import nutrimeals.domain.Rewards;
import nutrimeals.domain.RewardsMaintain;
import nutrimeals.domain.ScrollingContent;



@SuppressWarnings("unchecked")
@Repository
@Transactional
public class AdminDAO implements IAdminDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(AdminDAO.class);

	
	@Autowired
	private EntityManager em;
	

	private Session getSession(){
		return  em.unwrap(Session.class);
	
	}
	
	@Override
	public long registerRewardInfo(Rewards reward) {
		Long id = -1L;
		try {
			id=(Long) getSession().save(reward);
		} catch(Exception e) {			
			logger.error("registerRewardInfo ",e);
		}
		return id;
	}

	
	@Override
	public long registerScrollingContentInfo(ScrollingContent scrollingContent) {
		Long id = -1L;
		try {
			id=(Long) getSession().save(scrollingContent);
		} catch(Exception e) {			
			logger.error("registerScrollingContentInfo ",e);
		}
		return id>0?id:0;
	}
	
	@Override
	public RewardsMaintain getRewardsMaintainByUser(long rewardId,long userId)
	{
	List<RewardsMaintain> list=null;
	try
	{
		
	 list=em.createQuery("from RewardsMaintain where reward.id=:rewardId and user.userId=:userId and active=1 and purchase=0").setParameter("rewardId",rewardId).setParameter("userId", userId).getResultList();
	}
	 catch(Exception e) {			
			logger.error("getRewardsMaintainByUser ",e);
		}
	 return list!=null && !list.isEmpty()?list.get(0):null; 
	}
	@Override
	public long registerRewardsInfoByUser(RewardsMaintain rewardsMaintain) {
		Long id = -1L;
		try {
			id=(Long) getSession().save(rewardsMaintain);
		} catch(Exception e) {			
			logger.error("registerRewardsInfoByUser ",e);
		}
		return id;
	}
	
	
	@Override
	public void removeRewards(long rewardId) {
		try {			
			em.createQuery("Update RewardsMaintain SET active=0 where reward.id=:rewardId").setParameter("rewardId",rewardId).executeUpdate();
		} catch(Exception e) {
			logger.error("removeRewards ",e);
		}
	}
	
	
	
	@Override
	public void deleteRewards(long userId) {
		try {			
			em.createQuery("Update RewardsMaintain SET active=0 where user.id=:userId").setParameter("userId",userId).executeUpdate();
		} catch(Exception e) {
			logger.error("deleteRewards ",e);
		}
	}
	
	@Override
	public void updateRewards(Rewards reward) {
		try {
			getSession().update(reward);
		} catch(Exception e) {
			logger.error("updateRewards ",e);
		}
	}
	
	@Override
	public List<Rewards> getRewardsList(long userId,int pagenumber,int pagerecord)
	{
		List<Rewards> list=null;
		TypedQuery<Rewards> q=null;
		try
		{
			//String queryString="from Rewards where id NOT IN(select reward.id from RewardsMaintain where active=1 and user.userId=:userId) and  str_to_date(endDate,'%d-%m-%y')>=now()";
			q=em.createQuery("from Rewards where id not in (select reward.id from RewardsMaintain where user.userId=:userId and active=1) and str_to_date(endDate, '%d-%m-%Y')>now()",Rewards.class).setParameter("userId",userId);
			 if(pagenumber > 0 && pagerecord > 0)
    		 {
    		q.setFirstResult(((pagenumber-1) * pagerecord));
              q.setMaxResults(pagerecord);
    		 }
				list=	q.getResultList() ;
		}
		catch(Exception e)
		{
			logger.error("getRewardsList ",e);
		}
		   return list!=null && !list.isEmpty()?list:null; 
	}
	
	@Override
	public List<Rewards> getRewardsListByPromocode(String promocode)
	{
		List<Rewards> list=null;

		try
		{
			list=em.createQuery("from Rewards where promoCode=:promocode and active=1 ").setParameter("promocode",promocode).getResultList();
			
		 System.out.println("FAV LISTS :"+list);
		}
		catch(Exception e)
		{
			logger.error("getRewardsListByPromocode ",e);
		}
		   return list!=null && !list.isEmpty()?list:null; 
	}
	
	
	
	
	
	
	
	
	@Override
	public Rewards getRewardById(long id)
	{
		List<Rewards> list=null;
		try
		{
			list=getSession().createQuery("from Rewards where id=:id and active=1 ").setParameter("id",id).list();
			
		}
		catch(Exception e)
		{
			logger.error("getRewardById ",e);
		}
		   return list!=null && !list.isEmpty()?list.get(0):null; 
	}
	
	
	@Override
	public Rewards getRewardByIdWithoutActiveCheck(long id)
	{
		List<Rewards> list=null;
		try
		{
			list=em.createQuery("from Rewards where id=:id ",Rewards.class).setParameter("id",id).getResultList();
			
		}
		catch(Exception e)
		{
			logger.error("getRewardByIdWithoutActiveCheck ",e);
		}
		   return list!=null && !list.isEmpty()?list.get(0):null; 
	}
	
	

	@Override
	public RewardsMaintain getUsedRewardById(long id,long userId)
	{
		List<RewardsMaintain> list=null;
		try
		{
			list=em.createQuery("from RewardsMaintain where reward.id=:id and active=1 and user.id=:userId",RewardsMaintain.class).setParameter("id",id).setParameter("userId",userId).getResultList();
			
		 System.out.println("FAV LISTS :"+list);
		}
		catch(Exception e)
		{
			logger.error("getUsedRewardById ",e);
		}
		   return list!=null && !list.isEmpty()?list.get(0):null; 
	}



	
	
	@Override
	public Rewards getRewardByPromoCode(String code)
	{
		List<Rewards> list=null;
		try
		{
			list=getSession().createQuery("from Rewards where promoCode=:code and active=1 ").setParameter("code",code).list();
			System.out.println("sdjsaifhyui"+list);
		}
		catch(Exception e)
		{
			logger.error("getRewardByPromoCode ",e);
		}
		   return list!=null && !list.isEmpty()?list.get(0):null; 
	}
	
	
	@Override
	public Rewards getRewardByName(String rewardName)
	{
		List<Rewards> list=null;
		try
		{
			list=getSession().createQuery("from Rewards where name=:rewardName and active=1 ").setParameter("rewardName",rewardName).list();
		}
		catch(Exception e)
		{
			logger.error("getRewardByName ",e);
		}
		   return list!=null && !list.isEmpty()?list.get(0):null; 
	}
	
	@Override
	public List<Rewards> getAllRewardsList(long userId)
	{
		List<Rewards> list=null;
		TypedQuery<Rewards> q=null;
		try
		{

//SELECT * FROM `tbl_rewards` WHERE `DN_ID` NOT IN(SELECT `DN_REWARDS` FROM `tbl_user_rewards_maintain` WHERE `DN_ACTIVE`=1 AND `DN_USER`=2) 
q=em.createQuery("from Rewards where id not in (select reward.id from RewardsMaintain where user.userId=:userId and active=1) and str_to_date(endDate, '%d-%m-%Y')>now()",Rewards.class).setParameter("userId", userId);			
				list=	q.getResultList() ;
		 System.out.println("FAV LISTS :"+list);
		}
		catch(Exception e)
		{
			logger.error("getAllRewardsList ",e);
		}
		   return list!=null && !list.isEmpty()?list:null; 
	}
	
	
	
	
	@Override
	public List<Rewards> getOverAllRewardsList(int pagenumber,int pagerecord)
	{
		List<Rewards> list=null;
		TypedQuery<Rewards> q=null;
		try
		{


			q=em.createQuery("from Rewards where active=1",Rewards.class);

			if(pagenumber > 0 && pagerecord > 0)
			{
				q.setFirstResult(((pagenumber-1) * pagerecord));
				q.setMaxResults(pagerecord);
			}

			list=	q.getResultList() ;
			System.out.println("FAV LISTS :"+list);
		}
		catch(Exception e)
		{
			logger.error("getOverAllRewardsList ",e);
		}
		return list!=null && !list.isEmpty()?list:null; 
	}
	

	

	

	@Override
	public long getOverAllRewardsListCount()
	{
		long count=0;
		try
		{


			count=getSession().createQuery("from Rewards where active=1").list().size();



		}
		catch(Exception e)
		{
			logger.error("getOverAllRewardsListCount ",e);
		}
		return count; 
	}


	
	
	
	@Override
	public List<ScrollingContent> getAllScrollingContentList()
	{
		List<ScrollingContent> list=null;
		TypedQuery<ScrollingContent> q=null;
		try
		{
			q=getSession().createQuery("from ScrollingContent");
			
				list=	q.getResultList() ;
		}
		catch(Exception e)
		{
			logger.error("getAllScrollingContentList ",e);
		}
		   return list!=null && !list.isEmpty()?list:null; 
	
	}
	
	@Override
	public List<ScrollingContent> getScrollingContentList(int pagenumber,int pagerecord)
	{
		List<ScrollingContent> list=null;
		TypedQuery<ScrollingContent> q=null;
		try
		{
			q=getSession().createQuery("from ScrollingContent where active=1");
			 if(pagenumber > 0 && pagerecord > 0)
    		 {
    		q.setFirstResult(((pagenumber-1) * pagerecord));
              q.setMaxResults(pagerecord);
    		 }
				list=	q.getResultList() ;
		}
		catch(Exception e)
		{
			logger.error("getScrollingContentList ",e);
		}
		   return list!=null && !list.isEmpty()?list:null; 
	}

	@Override
	public Rewards getRewardId(long id) {

		return null;
	}

	@Override
	public List<Rewards> getRewardList() {
		List<Rewards> list=null;
		try
		{
			list=em.createQuery("from Rewards",Rewards.class).getResultList();
		}
		
		
		catch(Exception e)
		{
			logger.error("getRewardList ",e);
		}
		   return list!=null && !list.isEmpty()?list:null; 
	}

	@Override
	public List<Rewards> getallRewardsListWithOutActiveCheck(int pagenumber, int pagerecord) {
		List<Rewards> list=null;
		TypedQuery<Rewards> q=null;
		try
		{
			q=em.createQuery("from Rewards",Rewards.class);
		 if(pagenumber > 0 && pagerecord > 0)
   		 {
   		q.setFirstResult(((pagenumber-1) * pagerecord));
             q.setMaxResults(pagerecord);
   		 }
				list=	q.getResultList() ;
		}
		catch(Exception e)
		{
			logger.error("getRewardList ",e);
		}
		   return list!=null && !list.isEmpty()?list:null; 
	}	


}
