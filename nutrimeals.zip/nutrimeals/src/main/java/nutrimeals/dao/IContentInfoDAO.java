package nutrimeals.dao;

import nutrimeals.domain.ContentInfo;

public interface IContentInfoDAO {

	public  ContentInfo getSunboxInfo();

	public ContentInfo getPrivacyPolicyInfo();

	public ContentInfo getTermsInfo();

	public void update(ContentInfo contentInfo);
}