package nutrimeals.dao;

import java.util.List;

import nutrimeals.domain.Rewards;
import nutrimeals.domain.RewardsMaintain;
import nutrimeals.domain.ScrollingContent;

public interface IAdminDAO {
	
	public long registerRewardInfo(Rewards reward);
	
	public long registerRewardsInfoByUser(RewardsMaintain rewardsMaintain);
	
	public void removeRewards(long rewardId);
	
	public void updateRewards(Rewards reward);
	
	public List<Rewards> getAllRewardsList(long userId);
	
	public RewardsMaintain getRewardsMaintainByUser(long rewardId,long userId);
	
	public List<Rewards> getRewardsList(long userId,int pagenumber,int pagerecord);
	
	public List<Rewards> getOverAllRewardsList(int pagenumber,int pagerecord);
	
	public long getOverAllRewardsListCount();
	
	public long registerScrollingContentInfo(ScrollingContent scrollingContent);
	
	public List<ScrollingContent> getAllScrollingContentList();
	
	public List<ScrollingContent> getScrollingContentList(int pagenumber,int pagerecord);
	
	public Rewards getRewardById(long id);
	
	public void deleteRewards(long userId);
	
	public List<Rewards> getRewardsListByPromocode(String promocode);
	
	public RewardsMaintain getUsedRewardById(long id,long userId);
	
	public Rewards getRewardByPromoCode(String code);
	
	public Rewards getRewardByName(String rewardName);

	public Rewards getRewardId(long id);

	public List<Rewards> getRewardList();

	public List<Rewards> getallRewardsListWithOutActiveCheck(int pagenumber, int pagerecord);

	Rewards getRewardByIdWithoutActiveCheck(long id);



}
