package nutrimeals.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import nutrimeals.domain.Kiosk;
import nutrimeals.domain.ProductKiosk;
import nutrimeals.repository.KioskRepository;
import nutrimeals.views.KioskView;

@SuppressWarnings("unchecked")
@Repository
@Transactional
public class KioskDAO implements IKioskDAO {

	private static final Logger logger = LoggerFactory.getLogger(KioskDAO.class);

	@Autowired
	private EntityManager em;
	
	@Autowired
	private KioskRepository kioskRepo;
	

	private Session getSession(){
		return  em.unwrap(Session.class);
	
	}

	@Override
	public long registerKioskDetails(Kiosk kioskObj) {
		Long id = -1L;
		try {
			id=(Long) getSession().save(kioskObj);
		} catch(Exception e) {			
			logger.error("registerKioskDetails ",e);
		}
		return id;
	}

	@Override
	public void updateKiosk(Kiosk kiosk) {
		try {
			getSession().update(kiosk);
		} catch(Exception e) {
			logger.error("updateKiosk ",e);
		}
	}

	
	
	public Kiosk getKioskBypId(long product_id) {
	List<Kiosk> list = null;
		try {
		TypedQuery<Kiosk> q =	em.createQuery("select kiosk.id from ProductKiosk where product.id=:product_id", Kiosk.class);
		list = q.getResultList();
		} 	
		catch(Exception e) {
			logger.error("getKioskBypId ",e);
		}
		return ((list !=null && !list.isEmpty()) ?(Kiosk)list.get(0):null);
	}
	

	@Override
	public List<Kiosk> getAllSearchKioskDetails(String searchValue) {
		String appendStr = "";
		List<Kiosk> kioskList = null;
		if(searchValue!=null) {
			appendStr  = appendStr+" m.address1 LIKE '%"+searchValue+"%'";
			appendStr  = appendStr+" OR m.address2 LIKE '%"+searchValue+"%'";
			appendStr  = appendStr+" OR m.state LIKE '%"+searchValue+"%'";
			appendStr  = appendStr+" OR m.city LIKE '%"+searchValue+"%'";
			appendStr  = appendStr+" OR m.zipcode LIKE '%"+searchValue+"%'";
			appendStr  = " ( "+appendStr+" )";
		}
		String  SQL = "From Kiosk as m where m.IsDeleted=0 and "+appendStr;
		kioskList=em.createQuery(SQL).getResultList();
		if (kioskList!=null && kioskList.size() > 0 ) {
			return kioskList;
		}
		return kioskList!=null && !kioskList.isEmpty()?kioskList:null;
	}

	@Override
	public Kiosk getKioskById(long id) {
		List<Kiosk> list = null;
		try {
			list = em.createQuery("from Kiosk where id=:id and active=1").setParameter("id",id).getResultList();
		} catch(Exception e) {
			logger.error("getKioskById ",e);
		}
		return (list!=null && !list.isEmpty())?(Kiosk)list.get(0):null;
	}

	@Override
	public List<KioskView> getAllKioskMap(double latitude, double longitude,int pagenumber,int pagerecord) {
		List<KioskView> list = null;
		TypedQuery<KioskView> q=null;
		try {
			String SQL=
					" FROM KioskView WHERE   "
							+"( 3959 * ACOS( COS( RADIANS(latitude) ) * COS( RADIANS("+latitude+" ) ) * COS( RADIANS( longitude) - RADIANS("+longitude+") ) + "
							+"SIN( RADIANS(latitude) ) * SIN( RADIANS( "+latitude+" ) ) ) )   < 15 ORDER BY latitude ASC";
			q= em.createQuery(SQL,KioskView.class);
			
			if(pagenumber > 0 && pagerecord > 0)
   		 {
				q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
   		 }
			
			list=q.getResultList();
		} catch(Exception e)	{
			logger.error("getAllKioskMap ",e);
		}
		return ((list !=null && list.size()>0) ?list:null);
	}
	
	@Override
	public long getAllKioskMapCount(double latitude, double longitude) {
		long count = 0;
		List<KioskView> kiosk=null;
		try {
			String SQL=
					" FROM KioskView WHERE   "
							+"( 3959 * ACOS( COS( RADIANS(latitude) ) * COS( RADIANS("+latitude+" ) ) * COS( RADIANS( longitude) - RADIANS("+longitude+") ) + "
							+"SIN( RADIANS(latitude) ) * SIN( RADIANS( "+latitude+" ) ) ) )   < 15 ORDER BY latitude ASC";
			kiosk= em.createQuery(SQL).getResultList();
			
			count=kiosk.size();
			
			
	
		} catch(Exception e)	
		{
			logger.error("getAllKioskMapCount ",e);
		}
		return ((count !=0 && count>0) ?count:0);
	}

	@Override
	public List<KioskView> getAllKioskList(int all,int sortColumn,String sortType,int pagenumber,int pagerecord) {
		List<KioskView> list= null;
		String qstring=" ";
		 TypedQuery<KioskView> q=null;
		try {
			if(all>0)
			{
            switch(sortColumn)
            {
            case 1:qstring=sortType.equals("asc")?"from KioskView order by id asc":"from KioskView order by id desc";
            break;
            
            case 2:qstring=sortType.equals("asc")?"from KioskView order by kioskId asc":"from KioskView order by kioskId desc";
            break;
            
            case 3:qstring=sortType.equals("asc")?"from KioskView order by kioskName asc":"from KioskView order by kioskName desc";
            break;
            
            default:qstring="from KioskView where active=1 order by kioskName asc";
            
            }
            
			q = em.createQuery(qstring,KioskView.class);

			}
			else
			{
			q = em.createQuery("from KioskView where active=1 order by kioskName asc ",KioskView.class);
			}

			if(pagenumber > 0 && pagerecord > 0)
	    		 {
	    		q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
	    		 }
	    	
			list=q.getResultList();
		} catch(Exception e) {
			logger.error("getAllKioskList ",e);
		}
		return ((list !=null && list.size()>0) ?list:null);
	}
	
	
	@Override
	public List<Kiosk> getAllKioskListByKioskId(long kid) {
		List<Kiosk> list= null;
		try {
			list = em.createQuery("from Kiosk where id=:kid ORDER BY ASC ",Kiosk.class).setParameter("kid", kid).getResultList();
		} catch(Exception e) {
			logger.error("getAllKioskListByKioskId ",e);
		}
		return ((list !=null && list.size()>0) ?list:null);
	}

	@Override
	public List<Kiosk> getKioskLocationDetail(long kiosk_id) {
		List<Kiosk> list= null;
		try {
			list = em.createQuery("from Kiosk where kiosk_id=? and IsDeleted=0 ",Kiosk.class).setParameter(0,kiosk_id).getResultList();
		} catch(Exception e) {
			logger.error("getKioskLocationDetail ",e);
		}
		return ((list !=null && !list.isEmpty()) ?list:null);
	}

	@Override
	public void deleteKiosk(long kiosk_id) {
		try {
			em.createQuery("Update Kiosk SET IsDeleted=1 where id= ?",Kiosk.class).setParameter(0,kiosk_id).executeUpdate();
		} catch(Exception e) {
			logger.error("deleteKiosk ",e);
		}
	}

	@Override
	public List<Kiosk> getAllKioskListByActions() {
		List<Kiosk> kioskList = null;
		try {
			kioskList =em.createQuery("from Kiosk where active=1 and IsDeleted=0",Kiosk.class).getResultList();
		} catch(Exception e) {
			logger.error("getAllKioskListByActions ",e);
		}
		if (kioskList!=null && kioskList.size() > 0 ) {
			return kioskList;
		}
		return kioskList!=null && !kioskList.isEmpty()?kioskList:null;
	}

	@Override
	public Kiosk getKioskByKioskId(long id) {
		List<Kiosk> list = null;
		try {
			list = getSession().createQuery("from Kiosk where id=? and active=1",Kiosk.class).setParameter(0,id).getResultList();
		} catch(Exception e) {
			logger.error("getKioskByKioskId ",e);
		}
		return (list!=null && list.size()>0)?(Kiosk)list.get(0):null;
	}

	@Override
	public Kiosk getKioskId(long kioskId) {
		List<Kiosk> list = null;
		try {
			list = em.createQuery("from Kiosk where kioskId=:kioskId",Kiosk.class).setParameter("kioskId",kioskId).getResultList();
		} catch(Exception e) {
			logger.error("getKioskId ",e);
		}
		return (list!=null && list.size()>0)?list.get(0):null;
	}

	
	
	
	@Override
    public Kiosk getKioskName(String kioskName) {
        List<Kiosk> list = null;
        try {
            list=em.createQuery("from Kiosk where kioskName=:kioskName")
                    .setParameter("kioskName", kioskName).getResultList();
        } catch(Exception e) {
			logger.error("getKioskName ",e);
        }
        return (list!=null && list.size() > 0)?list.get(0):null;
                }
	
	@Override
	public Kiosk getKioskByKioskIdAction(long id) {
		List<Kiosk> list = null;
		try {
			list = getSession().createQuery("from Kiosk where id=?",Kiosk.class).setParameter(0,id).getResultList();
		} catch(Exception e) {
			logger.error("getKioskByKioskIdAction ",e);
		}
		return (list!=null && list.size()>0)?(Kiosk)list.get(0):null;
	}

	@Override
	public Kiosk getKioskByIdWithoutAction(long kiosk_id) {
		List<Kiosk> list = null;
		try {
			list = em.createQuery("from Kiosk where kiosk_id=?",Kiosk.class).setParameter(0,kiosk_id).getResultList();
		} catch(Exception e) {
			logger.error("getKioskByIdWithoutAction ",e);
		}
		return (list!=null && list.size()>0)?(Kiosk)list.get(0):null;
	}

@Override
	public ProductKiosk getKioskByProductKioskId(long productkioskid) {

		List<ProductKiosk> list = null;
		try {
			list =em.createQuery(" from ProductKiosk where id=:productkioskid ",ProductKiosk.class).setParameter("productkioskid",productkioskid).getResultList();
		} catch(Exception e) {
			logger.error("getKioskByProductKioskId ",e);
}
		return (list!=null && list.size()>0)?list.get(0):null;
		
}

public List<Kiosk> getAllKioskListUsingKioskId (List<Long> pkObj)
{
	List<Kiosk> list=null;

	try
	{
		
		list=em.createQuery("from Kiosk where id in(:kid) and active=1 order by kioskName asc ").setParameter("kid", pkObj).getResultList();
		
	}
	
	catch(Exception e) {
		logger.error("getAllKioskListUsingKioskId ",e);
}
	return (list!=null && list.size()>0)?list:null;
}

@Override
public List<Kiosk> getKioskListByProductId(long pid) {
	return null;
}

@Override
public List<Kiosk> getAllKioskByProduct(long pid,int pagenumber,int pagerecord) {
	
List<Kiosk> list=null;
TypedQuery<Kiosk> q=null;
try
{
	q=em.createQuery("from Kiosk where id in (select kiosk.id from ProductKiosk where product.id=:pid) and active=1",Kiosk.class).setParameter("pid",pid);
	
	if(pagenumber > 0 && pagerecord > 0)
	 {
	q.setFirstResult(((pagenumber-1) * pagerecord));
     q.setMaxResults(pagerecord);
	 }
	
	list=q.getResultList();

}
catch(Exception e) {
	logger.error("getAllKioskByProduct ",e);
}

return (list!=null && !list.isEmpty())?list:null;
}

@Override
public List<Kiosk> getAllKioskDetails() {
	return null;
}

@Override
public Kiosk getKioskByIdWithoutActionCheck(long kioskId) {
	List<Kiosk> list=null;
	try
	{
		list=em.createQuery("from Kiosk where kioskId=:kioskId",Kiosk.class).setParameter("kioskId",kioskId).getResultList();

	}
	catch(Exception e) {
		logger.error("getKioskByIdWithoutActionCheck ",e);
	}

	return (list!=null && !list.isEmpty())?list.get(0):null;
}
	}
		
		
