package nutrimeals.dao;

import nutrimeals.domain.OrderBasket;

public interface IOrderBasketDAO {

	long registerNewOrder(OrderBasket orderBasketObj);

}
