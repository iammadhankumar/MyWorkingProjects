package nutrimeals.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import nutrimeals.domain.VerificationCode;


@Repository
@Transactional
public class VerificationDAO implements IVerificationDAO {
	private static final Logger logger = LoggerFactory.getLogger(VerificationDAO.class);

	@Autowired
	private EntityManager em;
	
	
	private Session getSession(){
		return  em.unwrap(Session.class);
	
	}
	@Override
	public long save(VerificationCode verificationcode) {

		long code = 0;
		try {
			code = (long) getSession().save(verificationcode);
		} catch(Exception e) {
			logger.error("save ",e);		}
		return code;
	}
	
	@Override
	public void update(VerificationCode verificationcode) {
		try {
			getSession().update(verificationcode);
		} catch(Exception e) {
			logger.error("update ",e);		
			}
	}

	@SuppressWarnings("unchecked")
	@Override
	public VerificationCode getVerificationByverificationId(long id) {
		List<VerificationCode> list = null;
		try {
			list = em.createQuery("from VerificationCode where id = ?").setParameter(0, id).getResultList();
		}
		catch(Exception e) {
			logger.error("getVerificationByverificationId ",e);		
		}
		 return (list!=null && !list.isEmpty())?list.get(0):null;	}
	

	@SuppressWarnings("unchecked")
	@Override
	public VerificationCode getVerificationByverificationCode(String code,long userId) {
	List<VerificationCode> list = null;
	try {
		list = em.createQuery("from VerificationCode where verificationCode =:code and user.id=:userId and active = true").setParameter("code", code).setParameter("userId", userId).getResultList();
	}
	catch(Exception e) {
		logger.error("getVerificationByverificationCode ",e);		
	}
	 return (list!=null && list.size()>0)?list.get(0):null;	}
	
	 @SuppressWarnings("unchecked")
	@Override
	public List<VerificationCode> getVerificationListByUserId(long userId) {
	List<VerificationCode> list = null;
	try {
		list = em.createQuery("from VerificationCode where user.userId =:userId and active = 1").setParameter("userId", userId).getResultList();
	}
	catch(Exception e) {
		logger.error("getVerificationListByUserId ",e);		
	}
	 return (list!=null && !list.isEmpty())?list:null;	}
}
		

	
	

