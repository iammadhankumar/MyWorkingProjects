package nutrimeals.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import nutrimeals.domain.DietaryPreference;
import nutrimeals.domain.UserInfo;
import nutrimeals.domain.UserProfile;
import nutrimeals.domain.UserType;
import nutrimeals.repository.UserInfoRepository;

@Repository
@Transactional
public class UserInfoDAO implements IUserInfoDAO{
	
	private static final Logger logger = LoggerFactory.getLogger(UserInfoDAO.class);
	
	@Autowired
	UserInfoRepository userInfoRepo;
	
	@Autowired
	private EntityManager em;

	private Session getSession(){
		return  em.unwrap(Session.class);
	
	}
	
	@Override
	public long registerNewUser(UserInfo userObj) 
	{
		Long id = -1L;
		try {
		id=(Long) getSession().save(userObj);
		} catch(Exception e) {			
			logger.error("registerNewUser ",e);
		}
		return id;
	}
	
	
	
	@Override
	public long registerNewUserProfile(UserProfile userProfileObj) 
	{
		Long id = -1L;
		try {
			id=(Long) getSession().save(userProfileObj);
		} catch(Exception e) {			
			logger.error("registerNewUserProfile ",e);
		}
		return id;
	}
	
	@Override
	public void updateUser(UserInfo user) 
	{

		try {
			getSession().update(user);
		} catch(Exception e) {			
			logger.error("registerNewUserProfile ",e);
		}
	}
	
	
	@Override
	public UserInfo getUserByEmail(String email)
	{
	List<UserInfo> list=null;
	try
	{
		list =em.createQuery("from UserInfo where email=:email and active=1 ",UserInfo.class).setParameter("email", email).getResultList();
	}
	 catch(Exception e) {			
			logger.error("getUserByEmail ",e);
		}
		
	return (list!=null && list.size()>0)?(UserInfo)list.get(0):null;
	}
	
	

	@Override
	public UserInfo getUserById(long  userId)
	{
	List<UserInfo> list=null;
	try
	{
		list = em.createQuery("from UserInfo where userId=? and active=1",UserInfo.class).setParameter(0, userId).getResultList();
	}
	 catch(Exception e) {			
			logger.error("getUserById ",e);
		}
		
	return (list!=null && list.size()>0)?(UserInfo)list.get(0):null;
	}
	
	
	@Override
	public UserType getUserTypeById(long  userTypeId)
	{
	List<UserType> list=null;
	try
	{
		list =em.createQuery("from UserType where userTypeId=? ",UserType.class).setParameter(0, userTypeId).getResultList();
	}
	 catch(Exception e) {			
			logger.error("getUserTypeById ",e);
		}
		
	return (list!=null && list.size()>0)?(UserType)list.get(0):null;
	}
	
	
	@Override
	public List<DietaryPreference> getDeitaryById(List<DietaryPreference> id)
	{
	List<DietaryPreference> list=null;
	try
	{

     	list = em.createQuery("from DietaryPreference where dietaryId IN :id.deitaryId ",DietaryPreference.class).setParameter("id",id).getResultList();

	}
	 catch(Exception e) {			
			logger.error("getDeitaryById ",e);
		}
		
	return (list!=null && !list.isEmpty())?list:null;
	}



	@Override
	public List<UserInfo> getAllUsersByStatus(int stat) {
        String hql ="";
		
		switch(stat)
		{
		case 1:
			hql = "from UserInfo where active=1 ORDER BY created_on DESC ";
			break;

		case 2:
			hql = "from UserInfo where active=0 ORDER BY created_on DESC ";
			break;

		default:
			hql = "from UserInfo ORDER BY created_on DESC ";
			break;	
		}
		List<UserInfo> list = null;
		try {
			list = em.createQuery(hql,UserInfo.class).getResultList();			
			for(int i=0;i<list.size();i++);			
		} catch(Exception e) {
			logger.error("getAllUsersByStatus ",e);
		}
		return list!=null &&!list.isEmpty()?list:null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public UserInfo getUserByIdWithoutActiveCheck(long user_id) {
		List<UserInfo> list=null;
		try
		{
			list=em.createQuery("from UserInfo where userId=:user_id").setParameter("user_id",user_id).getResultList();
			System.out.println("LIST "+list);
		}
		catch(Exception e)
		{
			logger.error("getUserByIdWithoutActiveCheck",e);
		}
		return list!=null && !list.isEmpty()?list.get(0):null;
	}

}
