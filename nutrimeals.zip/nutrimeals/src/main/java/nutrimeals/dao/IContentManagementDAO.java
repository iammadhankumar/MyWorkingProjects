package nutrimeals.dao;

import java.util.List;

import nutrimeals.domain.ContentManagement;


public interface IContentManagementDAO {

	List<ContentManagement> getAllContentManagement();

	ContentManagement getContentManagementByContentType(String label);



}
