package nutrimeals.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import nutrimeals.domain.DietaryPreference;
import nutrimeals.domain.FavProduct;
import nutrimeals.domain.Product;
import nutrimeals.domain.ProductKiosk;
import nutrimeals.views.ProductView;

@Repository
@Transactional
public class ProductDAO implements IProductDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(ProductDAO.class);

	@Autowired
	private EntityManager em;
	
	@SuppressWarnings("unused")
	private Session getSession()
	{
		return  em.unwrap(Session.class);
	
	}
	
	@Override
	public  List<DietaryPreference> getAllDietaryPreferenceList(int pagenumber,int pagerecord) {		
		List<DietaryPreference> list = null;
		TypedQuery<DietaryPreference> q=null;
		try {
			q=em.createQuery("from DietaryPreference where active=1",DietaryPreference.class);
				
			 if(pagenumber > 0 && pagerecord > 0)
    		 {
    		  q.setFirstResult(((pagenumber-1) * pagerecord));
              q.setMaxResults(pagerecord);
    		 }
			
    		list=q.getResultList();
    		   
		} catch(Exception e) {
			logger.error("registerNewOrder ",e);
		}
		return (list!=null && !list.isEmpty())?list:null;

	}	
	
	public  long getAllDietaryPreferenceListCount()
	{
		long dietarycount = 0;
		try {
			dietarycount=em.createQuery("from DietaryPreference where active=1").getResultList().size();
    		   
		} catch(Exception e) {
			logger.error("getAllDietaryPreferenceListCount ",e);
		}
		return dietarycount;

	}	
	
			

	
	
	

	@Override
	public List<Product> getAllProductList(int pagenumber,int pagerecord) {
		List<Product> list = null;
		TypedQuery<Product> q=null;
		try {
			q = em.createQuery("from Product ",Product.class);
			
			if(pagenumber > 0 && pagerecord > 0)
	    		 {
	    		q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
	    		 }
	    	
			list=q.getResultList();
		} catch (Exception e) {
			logger.error("getAllProductList ",e);
		}
		return (list!=null && !list.isEmpty())?list:null;
	}
	
	
	

	@Override
	public List<Product> searchProductList(String searchValue,long categoryId,long kid,int pagenumber,int pagerecord) 
	{
		List<Product> list = null;
		String searchString="";
		TypedQuery<Product> q=null;
		try {
			searchString  = searchString+" m.productName LIKE '%"+searchValue+"%'";

			searchString  = " ( "+searchString+" )";

			
	
			q=em.createQuery("from Product where id IN (select product.id from ProductKiosk where kiosk.id=:kid) and productName like '%"+searchValue+"%' and productType.id=:categoryId",Product.class).setParameter("kid",kid).setParameter("categoryId", categoryId);
			if(pagenumber > 0 && pagerecord > 0)
			{
				q.setMaxResults(pagerecord);
			}

			list=q.getResultList();
		} catch (Exception e) {
			logger.error("searchProductList ",e);
		}
		return (list!=null && !list.isEmpty())?list:null;
	}

	

	@Override
	public long searchProductListCount(String searchValue,long kid) 
	{

		long count=0;
		try {

			count=em.createQuery("from Product where id IN (select product.id from ProductKiosk where kiosk.id=:kid) and productName like '%"+searchValue+"%' and productType.id=:categoryId").setParameter("kid",kid).getResultList().size();

		} catch (Exception e) {
			logger.error("searchProductListCount ",e);
		}
		return count;
	}





	@Override
	public List<FavProduct> getAllFavProductList(long userid,int pagenumber, int pagerecord) {
		List<FavProduct> list = null;
		TypedQuery<FavProduct> q=null;
		try {
			q = em.createQuery("from FavProduct where active=1 and user.userId=:userid",FavProduct.class).setParameter("userid", userid);
			
			if(pagenumber > 0 && pagerecord > 0)
	    		 {
	    		q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
	    		 }
	    	
			list=q.getResultList();
		} catch (Exception e) {
			logger.error("getAllFavProductList ",e);
		}
		return (list!=null && !list.isEmpty())?list:null;
	}




	@Override
	public Product getProductById(long pid) {
		List<Product> list = null;
		try
		{
			list = em.createQuery("from Product where id=:pid",Product.class).setParameter("pid", pid).getResultList();
		}
		 catch (Exception e) {
				logger.error("getProductById ",e);
			}
			return (list!=null && !list.isEmpty())?list.get(0):null;
	
	}




	@Override
	public List<Product> getProductsByCategory(long categoryId,int pagenumber,int pagerecord) {
		List<Product> list = null;
		System.out.println("CAT ID "+categoryId);
		TypedQuery<Product> q=null;
		try {
			q=em.createQuery("from Product where productType.id=:categoryId",Product.class)
					.setParameter("categoryId", categoryId);
				
			 if(pagenumber > 0 && pagerecord > 0)
    		 {
    		q.setFirstResult(((pagenumber-1) * pagerecord));
              q.setMaxResults(pagerecord);
    		 }
    	
    		
    		list=q.getResultList();
    	
    		   
		} catch(Exception e) {
			logger.error("getProductsByCategory ",e);
		}
		return (list!=null && !list.isEmpty())?list:null;

	}




	@Override
	public long getProductCountByCategory(long categoryId) {
	long count=0;
	try
	{
		count=em.createQuery("from Product p where productType.id=:categoryId")
				.setParameter("categoryId", categoryId).getResultList().size();
	}
	catch(Exception e) {
		logger.error("getProductCountByCategory ",e);
	}
	return count>0?count:0;
	}




	@Override
	public List<ProductView> getAllProductByKiosk(long kid,String searchValue,long categoryId, int pagenumber, int pagerecord) {
		List<ProductView> list=null;
		TypedQuery<ProductView> q=null;
		
		int c=0;
		boolean check = true;
		
		try
		{
	
			c=(check== categoryId>0 && kid>0 && searchValue==null?1 : searchValue!=null && categoryId>0  && kid>0?2: categoryId==0 && searchValue==null && kid>0?3 :0);
			System.out.println("C VAL "+c);
			
			switch(c)
			{
			case 1:
				q=em.createQuery("from ProductView where kid=:kid and productType=:categoryId",ProductView.class)
				.setParameter("categoryId", categoryId)
				.setParameter("kid", kid);break;
			case 2:
				q=em.createQuery("from ProductView where kid=:k and productType=:categoryId and productName like '%"+searchValue+"%' ",ProductView.class).setParameter("categoryId", categoryId)
				.setParameter("k", kid); break;		
				
			case 3:
				q=em.createQuery("from ProductView where kid=:kid",ProductView.class).setParameter("kid", kid);break;
				
				default :
					q=em.createQuery("from ProductView where kid=:kid and productType=:categoryId",ProductView.class)
						.setParameter("categoryId", categoryId)
						.setParameter("kid", kid);break;

			}
			 if(pagenumber > 0 && pagerecord > 0)
    		 {
    		q.setFirstResult(((pagenumber-1) * pagerecord));
              q.setMaxResults(pagerecord);
    	
    		 }
		
		list=q!=null?q.getResultList():null;
            			
//			if(categoryId>0 && kid>0 )
//			{
//		
//				q=em.createQuery("from ProductView where kid=:kid and productType=:categoryId",ProductView.class).setParameter("categoryId", categoryId)
//					.setParameter("kid", kid);
//				
//				
//				 if(pagenumber > 0 && pagerecord > 0)
//	    		 {
//	    		q.setFirstResult(((pagenumber-1) * pagerecord));
//	              q.setMaxResults(pagerecord);
//	    		 }
//			}
//			if(searchValue!=null && categoryId>0  && kid>0)
//			{
//				q=em.createQuery("from ProductView where kid=:k and productType=:categoryId and productName like '%"+searchValue+"%' ",ProductView.class).setParameter("categoryId", categoryId)
//						.setParameter("k", kid);
//				
//		 }
//	}
	
		
		}
		catch(Exception e) {
			logger.error("getAllProductByKiosk ",e);
		}
		return (list!=null && !list.isEmpty())?list:null;

	}
	
	
	@Override
	public long getAllProductCountByKiosk(long kid,String searchValue,long categoryId) {
		
		long count=0;
		int c=0;
		boolean check = true;
		
		try
		{
	
			c=(check== categoryId>0 && kid>0 && searchValue==null?1 : searchValue!=null && categoryId>0  && kid>0?2: categoryId==0 && searchValue==null && kid>0?3 :0);
			System.out.println("C VAL "+c);
			
			switch(c)
			{
			case 1:
				count=em.createQuery("from ProductView where kid=:kid and productType=:categoryId",ProductView.class)
				.setParameter("categoryId", categoryId)
				.setParameter("kid", kid).getResultList().size();break;
			case 2:
				count=em.createQuery("from ProductView where kid=:k and productType=:categoryId and productName like '%"+searchValue+"%' ",ProductView.class).setParameter("categoryId", categoryId)
				.setParameter("k", kid).getResultList().size(); break;		
				
			case 3:
				count=em.createQuery("from ProductView where kid=:kid",ProductView.class).setParameter("kid", kid).getResultList().size();break;
				
				default :
					count=em.createQuery("from ProductView where kid=:kid and productType=:categoryId",ProductView.class)
						.setParameter("categoryId", categoryId)
						.setParameter("kid", kid).getResultList().size();break;

			}
			
		}
		catch(Exception e) {
			logger.error("getAllProductCountByKiosk ",e);
		}
		return count;

	}




	@SuppressWarnings("unchecked")
	@Override
	public ProductKiosk getQuantityByKiosk(long kid, long pid) {
		List<ProductKiosk> list=null;
		try
		{
			list=em.createQuery("from ProductKiosk where product.id=:pid and kiosk.id=:kid").setParameter("pid",pid).setParameter("kid", kid).getResultList();
		}
		catch(Exception e)
		{
			logger.error("getQuantityByKiosk ",e);

		}
		return list!=null && !list.isEmpty()?list.get(0):null;
	}







	
}

	
	
	
