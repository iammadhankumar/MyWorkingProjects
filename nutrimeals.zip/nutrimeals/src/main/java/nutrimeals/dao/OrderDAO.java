package nutrimeals.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import nutrimeals.domain.Order;
import nutrimeals.domain.OrderBasket;
import nutrimeals.domain.Product;
import nutrimeals.domain.RewardsPurchaseInfo;
import nutrimeals.domain.User;
import nutrimeals.views.OrderView;

@Repository
@Transactional
public class OrderDAO implements IOrderDAO{
	
	private static final Logger logger = LoggerFactory.getLogger(OrderDAO.class);

	@Autowired
	private EntityManager em;

	private Session getSession(){
		return  em.unwrap(Session.class);
	
	}
	@Override
	public long registerNewOrder(Order order) {
		Long id = -1L;
		try {
			
			id=(Long) getSession().save(order);
		} catch(Exception e) {		
			logger.error("registerNewOrder ",e);
		}
		return id;
	}
	
	@Override
	public long registerRewardsPurchaseInfo(RewardsPurchaseInfo rewardPurchase) {
		Long id = -1L;
		try {
			
			id=(Long) getSession().save(rewardPurchase);
		} catch(Exception e) {		
			logger.error("registerRewardsPurchaseInfo ",e);
		}
		return id;
	}
	
	
	@Override
	public List<User> getUserInfo(long userId)
	{
		List<User> list=null;
		try {
			list= em.createQuery("from User where user_id=:userId",User.class).setParameter("userId", userId).getResultList();
		}
		
		catch(Exception e) {
			logger.error("getUserInfo ",e);
		}
		
		return list;
	}
	
	
	@Override
	public List<Product> getProductInfo(long pid)
	{
		List<Product> list=null;
		try {
			list= em.createQuery("from Product where id=:pid",Product.class).setParameter("pid", pid).getResultList();
		}
		
		catch(Exception e) {
			logger.error("getProductInfo ",e);
		}
		
		return list!=null && !list.isEmpty()?list:null;
	}
	
	
	@Override
	public RewardsPurchaseInfo getRewardPurchaseInfoById(long id)
	{
		List<RewardsPurchaseInfo> list=null;
		try {
					
			list= em.createQuery("from RewardsPurchaseInfo where id=:id",RewardsPurchaseInfo.class).setParameter("id", id).getResultList();
		             
			}
		
		catch(Exception e) {
			logger.error("getRewardPurchaseInfoById ",e);
		}
		
		return (list!=null && !list.isEmpty())?list.get(0):null;
	}
	
	
	@Override
	public Order getOrderInfo(String orderno)
	{
		List<Order> list=null;
		try {
			list=em.createQuery("from Order where orderNo=:orderno",Order.class).setParameter("orderno", orderno).getResultList();

		}
		
		catch(Exception e) {
			logger.error("getOrderInfo ",e);
		}
		
		return (list!=null && !list.isEmpty())?(Order)list.get(0):null;
	}


	@Override
	public List<OrderView> getOrderInfoByUser(long userId,int pagenumber,int pagerecord)
	{
		List<OrderView> list=null;
		TypedQuery<OrderView> q=null;
		try {
			q= getSession().createQuery("from OrderView where purchaseStatus=1 and userId=:userId",OrderView.class).setParameter("userId", userId);
		             
			if(pagenumber>0 && pagerecord>0) 
			{
				q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
			}
			list=q.getResultList();
		}
		
		catch(Exception e) {
			logger.error("getOrderInfoByUser ",e);
		}
		
		return (list!=null && !list.isEmpty())?list:null;
	}
	
	
	@Override
	public List<Order> getOrderInfoList(int pagenumber,int pagerecord)
	{
		List<Order> list=null;
		TypedQuery<Order> q=null;
		try {
			q= em.createQuery("from Order where purchaseStatus=1",Order.class);
		             
			if(pagenumber>0 && pagerecord>0) 
			{
				q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
			}
			list=q.getResultList();
		}
		
		catch(Exception e) {
			logger.error("getOrderInfoList ",e);
		}
		
		return (list!=null && !list.isEmpty())?list:null;
	}
	
	
	@Override
	public long getOrderInfoListCount()
	{
		long count=0;

		try {
			count= em.createQuery("from Order where purchaseStatus=1",Long.class).getResultList().size();

		}
		
		catch(Exception e) {
			logger.error("getOrderInfoListCount ",e);
		}
		
		return count;
	}
	
	
	
	@Override
	public Order getOrderInfoById(long userId,String orderNumber,long orderId)
	{
		List<Order> list=null;
		try {
			if(orderNumber!=null)
			{
		     list= em.createQuery("from Order where purchaseStatus=1 and user.userId=:userId and orderNo=:orderNumber ",Order.class).setParameter("orderNumber",orderNumber).setParameter("userId", userId).getResultList();
			}
			
			else
			{
				list= em.createQuery("from Order where purchaseStatus=1 and user.userId=:userId and id=:orderId",Order.class).setParameter("orderId",orderId).setParameter("userId", userId).getResultList();
				
			}
		
		}
		
		catch(Exception e) {
			logger.error("getOrderInfoById ",e);
		}
		
		return (list!=null && !list.isEmpty())?list.get(0):null;
	}
	
	
	
	@Override
	public Order getOrderInfoByBasket(long bid)
	{
		List<Order> list=null;
		try {
			
			list= em.createQuery("select orderBasket from Order IN ( from OrderBasket where basket.id=:bid)",Order.class).setParameter("bid", bid).getResultList();
		             
			}
		
		catch(Exception e) {
			logger.error("getOrderInfoByBasket ",e);
		}
		
		return (list!=null && !list.isEmpty())?list.get(0):null;
	}


	
	@Override
	public List<Order> getOrderDetailsByUser(long userId,int pagenumber,int pagerecord)
	{
		List<Order> list=null;
		TypedQuery<Order> q=null;
		try {
			q= em.createQuery("from Order where purchaseStatus=1 and user.user_id=:userId",Order.class).setParameter("userId", userId);
		             
			if(pagenumber>0 && pagerecord>0) 
			{
				q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
			}
			list=q.getResultList();
		}
		
		catch(Exception e) {
			logger.error("getOrderDetailsByUser ",e);
		}
		
		return list!=null && !list.isEmpty()?list:null;
	}

	
	@Override
	public List<OrderBasket> getOrderBasketInfoByUser(long userId,int pagenumber,int pagerecord)
	{
		List<OrderBasket> list=null;
		TypedQuery<OrderBasket> q=null;
		try {
			q= em.createQuery("select basket.product from OrderBasket where active=0 and purchase=1 and user.user_id=:userId",OrderBasket.class).setParameter("userId", userId);
		             
			if(pagenumber>0 && pagerecord>0) 
			{
				q.setFirstResult(((pagenumber-1) * pagerecord));
	              q.setMaxResults(pagerecord);
			}
			list=q.getResultList();
		}
		
		catch(Exception e) {
			logger.error("getOrderBasketInfoByUser ",e);
		}
		
		return list!=null && !list.isEmpty()?list:null;
	}

	@Override
	public List<Order>  getOrderInfoByUserId(List<User> userId)
	{
		List<Order> list=null;
		try
		{
			list=em.createQuery("from Order where user.user_id in( select user_id from User)",Order.class).getResultList();
		}
		

		catch(Exception e) {
			logger.error("getOrderInfoByUserId ",e);
		}
		return (list!=null && list.size()>0)?list:null;
	}
	
	
	@Override
	public long getorderCount(long userId,boolean purchase)
	{
		long count=0;
		try
		{
			count=em.createQuery("select distinct(orderNo) from OrderView where purchaseStatus=:purchase and userId=:userId",Long.class)
					.setParameter("purchase", purchase)
					.setParameter("userId", userId).getResultList().size();
		}

		catch(Exception e) {
			logger.error("getorderCount ",e);
		}
		return count;

	}


	
	

}
