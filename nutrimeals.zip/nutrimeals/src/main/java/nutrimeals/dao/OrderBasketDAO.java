package nutrimeals.dao;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import nutrimeals.domain.OrderBasket;


@Repository
@Transactional
public class OrderBasketDAO implements IOrderBasketDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(OrderBasketDAO.class);

	@Autowired
	private EntityManager em;

	private Session getSession(){
		return  em.unwrap(Session.class);
	
	}
	@Override
	public long registerNewOrder(OrderBasket orderBasketObj) {
		Long id = -1L;
		try {
			id=(Long) getSession().save(orderBasketObj);
		} catch(Exception e) {			
			logger.error("registerNewOrder ",e);
		}
		return id;
	}

	}
	

	

