package nutrimeals.dao;

import java.util.List;

import nutrimeals.domain.DietaryPreference;
import nutrimeals.domain.UserInfo;
import nutrimeals.domain.UserProfile;
import nutrimeals.domain.UserType;

public interface IUserInfoDAO {
	
	public long registerNewUser(UserInfo userObj);
	
	public UserInfo getUserByEmail(String email);
	
	public UserInfo getUserById(long  userId);
	
	public UserType getUserTypeById(long  userTypeId);

	public List<DietaryPreference> getDeitaryById(List<DietaryPreference> id);
	
	public long registerNewUserProfile(UserProfile userProfileObj);

	public List<UserInfo> getAllUsersByStatus(int stat);

	public UserInfo getUserByIdWithoutActiveCheck(long user_id);
	
	public void updateUser(UserInfo user);

}
