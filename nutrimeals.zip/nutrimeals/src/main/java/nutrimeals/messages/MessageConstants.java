package nutrimeals.messages;

public class MessageConstants {
	
private MessageConstants(){}
	public static final String FORGET ="FORGET";
	public static final String REGISTER ="REG";
	public static final String INVITE ="INVITE";
	public static final String CHANGEPASS ="CHANGEPASSWORD";
	public static final String ENHANCELIMIT ="ENHANCELIMIT";
	public static final String PHONEUPDATE ="PHONEUPDATE";
	public static final String EMAILUPDATE ="EMAILUPDATE";
	public static final String EMAILVERIFY ="EMAILVERIFY";
	public static final String PHONEVERIFY ="PHONEVERIFY";
	public static final String INVITEEMAILSUBJECT ="Invitation email for SendOnCard";
	public static final String OAUTHTC ="nutrimeals";
	public static final String OAUTH ="oauth/token";
	public static final String CHECKMOBIAPPID= "5F75ACB9-4DDF-4DC4-ABC6-3416085239C1";
	public static final String CHECKMOBIVERIFY ="https://api.checkmobi.com/v1/validation/verify";
	public static final String CHECKMOBIREQUEST ="https://api.checkmobi.com/v1/validation/request";
	public static final String CHECKMOBISMS = "https://api.checkmobi.com/v1/sms/send";
	public static final String PLIVOAUTHID ="MANDHLMZHLZDVKMZI1MM";
	public static final String PLIVOAUTHTOKEN ="NWYyOTgyZWY3NWI4MTM1MTRlZjFlNTc2NmU4MTg5";
	//public static final String FCMSERVERAPIKEY = "AAAAYKZfeAc:APA91bHb6Z50YMdRCCO7kUV1cr0Zrv1ziUvdPj5KJeFAJ0GTSen1OUEQVid7KwN3JcBL0C3v02nS8kgj0YIfctsaLvJF9kOUukRq33GOph7tnP0tTTUV7FHI0XaJY2aXK-6mZULrSphf";
	public static final String FCMSERVERAPIKEY = "AAAArxmJ1VU:APA91bFpbOFWwClbWERTU3hXGw62f41uRJ4WTI9m-967VQQ8Rvok7aDutmAZ-_f2QuHNR09mhREh160wc3C859sPjlVBVkD-BjMKJkR4QX7Ak_IeuHdTyAgwOAtChw075e7GgycQCs24";
	public static final String FCMURL = "https://fcm.googleapis.com/fcm/send";
	public static final String PULLSUCCESS = "PULLSUCCESS";
	public static final String PULLFAILURE ="PULLFAILURE";
	public static final String PUSHSUCCESS ="PUSHSUCCESS";
	public static final String PUSHFAILURE ="PUSHFAILURE";
	public static final String REVERSED ="REVERSED";
	public static final String SUCCESS ="SUCCESS";
	public static final String FAILURE ="FAILURE";
	public static final String PENDING ="PENDING";
	public static final String DECLINED ="Declined";

	public static final String REMAINING = "remaining";	
	public static final String DEFAULTRULES = "defaultRules";
	
	public static final String FACEBOOKAPPID ="2013235712068444";
	public static final String FACEBOOKAPPSECRET ="1053a677052903c278e5cf41585b652f";
	
	public static final String TWITTERCONSUMERKEY ="G0tSI0RvejpVSAR3dIT7o0LlG";
	public static final String TWITTERCONSUMERSECRET ="IwD8GjbQjBLeneTmJ2UtU3xQsJ9nr6I9iX8fMft7bZx2wVHoSE";
	public static final String TWITTERFRIENDLISTAPI = "/friends/list";
	
	public static final String FACEBOOKIOSAPPID ="209633976469044";
	public static final String FACEBOOKIOSSECRETKEY ="c1c0459fca7a2e54375d138d9bfa31a6";
	
	public static final String FACEBOOKANDROIDAPPID ="234601487097596";
	public static final String FACEBOOKANDROIDSECRETKEY ="adb2be8b404b483ece6a7534f8b2a725";
	
	public static final String GOOGLEFEEDCONTACTURL ="https://www.google.com/m8/feeds/contacts/default/full";
	public static final String GOOGLEAPPLICATIONNAME ="Mule-GoogleContactsConnector/1.0";
}
