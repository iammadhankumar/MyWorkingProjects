package nutrimeals.oauth2;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import nutrimeals.domain.UserInfo;
import nutrimeals.service.IUserInfoService;
import nutrimeals.utils.CommonProperties;
import nutrimeals.utils.CommonUtils;



@Service
public class TokenGeneration {
	
	@Autowired
	IUserInfoService userInfoService;
	
	
	
	public JSONObject  loginwithregister(String username, String password) throws UnsupportedEncodingException, ParseException {
		String baseUrl = CommonProperties.getBaseURL() + CommonProperties.getContextPath() + "oauth/token";
		HashMap<String,String> input = new HashMap<>();
		JSONObject json1 = new JSONObject();
		UserInfo user=null;
		user=userInfoService.getUserByEmail(username);
		System.out.println("UN "+username);
		System.out.println("Pass"+password);
		CommonUtils commonUtils = CommonUtils.getInstance();
		String cmnUtils = CommonUtils.getBasicAuthHeader("nutrimeals","nutrimeals");
		System.out.println(baseUrl);
		input.put("username", user.getEmail());
		input.put("password", password);
		input.put("grant_type","password");
       System.out.println("INPUT "+input);
    
		String body = getDataString(input);
		System.out.println(body);
		Client client = ClientBuilder.newClient();
		Builder builder = client.target(baseUrl).request();
	
		
		Invocation inv = builder
				.header("Content-type", MediaType.APPLICATION_FORM_URLENCODED)
				.header("Authorization", cmnUtils)
				.buildPost(Entity.entity(body, MediaType.APPLICATION_FORM_URLENCODED_TYPE));
		Response res = inv.invoke();
		String responseAsString = res.readEntity(String.class);

		System.out.println("kjhkjh***********************"+responseAsString);

		if(responseAsString != null)
		{
			JSONParser parser = new JSONParser();
			json1 = (JSONObject) parser.parse(responseAsString);

			if (responseAsString.indexOf("access_token") != -1){

				return json1;
			}
		}

		System.out.println("TOken OBJ**************************");
		return json1;
	}
	public static String getDataString(HashMap<String, String> params) throws UnsupportedEncodingException{
		StringBuilder result = new StringBuilder();
		boolean first = true;
		System.out.println(params);
		for(Map.Entry<String, String> entry : params.entrySet()){
			if (first)
				first = false;
			else
				System.out.println(entry.getKey());
			result.append("&");    
			result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
			result.append("=");
			result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
		}    
		return result.toString();
	}
	

}
