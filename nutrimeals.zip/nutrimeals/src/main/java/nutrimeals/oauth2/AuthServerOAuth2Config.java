package nutrimeals.oauth2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.error.OAuth2AccessDeniedHandler;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.TokenEnhancer;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JdbcTokenStore;

import nutrimeals.messages.MessageConstants;
import nutrimeals.response.PropertyConstants;





@Configuration
@EnableAuthorizationServer
public class AuthServerOAuth2Config extends AuthorizationServerConfigurerAdapter {

	private static final String RESOURCE_ID = "restservice";
	
	private static final Logger logger = LogManager.getLogger(AuthServerOAuth2Config.class);
	
	@Autowired
	ServletContext ctx;
	
	@Autowired
    private AuthenticationManager authenticationManager;
	
    @Autowired
    private CustomUserDetailsService userDetailsService;
    
    @Autowired
    private DataSource dataSource;
  
    @Bean
    public TokenStore tokenStore() {
        return new JdbcTokenStore(dataSource);
    }
    
 
    
    @Bean
    public OAuth2AccessDeniedHandler oauthAccessDeniedHandler() {
        return new OAuth2AccessDeniedHandler();
    }

    @Override
    public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
    	clients
		.inMemory()  
		.withClient(MessageConstants.OAUTHTC)
		.authorizedGrantTypes(PropertyConstants.PASS,"refresh_token")
		.authorities("USER")
		.scopes("read","write")
		.resourceIds(RESOURCE_ID)			
		.secret("$2a$11$Wo.IFjAFPB.GX4bySDffV.rH.4kHfYBDwwGSJNbJbbFuPuyzwAYPC")
		.accessTokenValiditySeconds(5000000);
    }
    
    @Override
    public void configure(AuthorizationServerEndpointsConfigurer endpoints) {
        endpoints.tokenStore(tokenStore()).authenticationManager(authenticationManager).userDetailsService(userDetailsService)
		.tokenEnhancer(tokenEnhancer());
    }
    
    
    
    @Bean
	@Primary
	public DefaultTokenServices tokenServices() {
		DefaultTokenServices tokenServices = new DefaultTokenServices();
		tokenServices.setSupportRefreshToken(true);
		tokenServices.setTokenStore(tokenStore());
		tokenServices.setTokenEnhancer(tokenEnhancer());
		return tokenServices;
	}
    
	@Bean
	public TokenEnhancer tokenEnhancer() {
		return new CustomTokenEnhancer();
	}
	public class CustomTokenEnhancer implements TokenEnhancer {
		
		@Override
		public OAuth2AccessToken enhance(OAuth2AccessToken accessToken, OAuth2Authentication authentication) {
			User user = (User) authentication.getPrincipal();
			final Map<String, Object> additionalInfo = new HashMap<>();

			List<String> tokenValues = new ArrayList<>();
			
			Collection<OAuth2AccessToken> tokens = tokenStore().findTokensByClientId(MessageConstants.OAUTHTC); 
			if (tokens!=null){
				for (OAuth2AccessToken token:tokens){
					tokenValues.add(token.getValue());
				}
			}			
			
			
			return accessToken;
		}
		
	}
}
