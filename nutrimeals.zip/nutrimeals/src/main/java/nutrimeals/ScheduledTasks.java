package nutrimeals;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;

import javax.imageio.ImageIO;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.Barcode128;

import nutrimeals.domain.Rewards;
import nutrimeals.service.IAdminService;
import nutrimeals.utils.CommonProperties;
import nutrimeals.utils.CommonUtils;
import nutrimeals.utils.UserByToken;

@Component
public class ScheduledTasks {
	
	private static final Logger logger = LoggerFactory
			.getLogger(ScheduledTasks.class);

	@Autowired
	private IAdminService adminService;


	@Autowired
	UserByToken tokenUser;


	
	CommonUtils commonUtils = CommonUtils.getInstance();
//	@Scheduled(cron = "0 59 23 * * *",zone="UTC")
//	public void getProductResponse() throws ParseException 
//	{
//		System.out.println("in loop");
//		JSONArray  jsonArray=new JSONArray();
//		String value=CommonProperties.getUserName()+CommonProperties.getPassword();
//		String user="944191bfbc1d87ee4117b800c06fd967";
//		try 
//		{   
//			URL url = new URL("http://dati.erentcinema.it/mobile_webservice/getProducts.php?user="+user);
//			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//			conn.setRequestMethod("GET");
//			conn.setRequestProperty("Accept", "application/json");
//			if (conn.getResponseCode() != 200)
//			{
//				throw new RuntimeException("Failed : HTTP error code : "+ conn.getResponseCode());
//			}
//			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
//			String output;
//			while ((output = br.readLine()) != null)
//			{
//				value= output;
//
//			}
//			System.out.println(value);
//			conn.disconnect();
//			jsonArray = kioskExternal(value);
//		} catch (MalformedURLException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//
//		//return jsonArray;
//	}
//
//	private JSONArray kioskExternal(String value)
//	{
//		JSONArray  jsonArray=new JSONArray();
//		try
//		{
//			long kiosk=0;
//			int z=0;
//			long kioskid=0;
//			long pi = 0;
//			ProductKiosk pk = new ProductKiosk();
//			JSONObject obj=(JSONObject) new JSONParser().parse(value);
//			JSONArray array=(JSONArray) obj.get("machines");
//			Iterator<?> k = array.iterator();
//			for (int m = 0; m < array.size(); m++) 
//			{
//				if(z<3)
//				{
//					kiosk=kiosk+1; 
//					z= z+1;
//				}
//				JSONObject json3 = (JSONObject) k.next();	
//				Kiosk kioskObj = kioskService.getKioskName((String)json3.get("name"));
//				if(kioskObj != null)
//				{
//					kioskid = kioskObj.getId();
//				}
//				if(kioskObj==null)
//				{
//					long mId = (long)json3.get("id");
//					String mName = (String)json3.get("name");	
//					kioskObj = new Kiosk();
//					kioskObj.setKioskId(mId);
//					kioskObj.setKioskName(mName);
//					kioskObj.setCreated_on(new Date());
//					kioskid = 	kioskService.registerKioskDetails(kioskObj);
//					kioskObj = kioskService.getKioskById(kioskid);
//					json3.put("name", mName);
//					json3.put("id",mId);
//					jsonArray.add(json3);	
//				}
//				pk.setKiosk(kioskObj);
//				Iterator<?> i = array.iterator();
//				long iii= 0;
//				while(i.hasNext())
//				{
//					JSONObject json1 = (JSONObject) i.next();	
//					String kioskId =  json1.get("id").toString();
//					if(json1.get("products")!=null)
//					{
//						JSONArray jarray2=(JSONArray) json1.get("products");
//						Iterator<?> j = jarray2.iterator();
//						while (j.hasNext())
//						{
//							JSONObject json=new JSONObject();
//							JSONObject json2 = (JSONObject) j.next();
//							String id = (String)json2.get("id");
//							String name = (String)json2.get("name");	
//							float price = json2.get("price") != null ? Float.parseFloat(json2.get("price").toString()):0;	
//							long qt = json2.get("qt") != null ?Long.parseLong(json2.get("qt").toString()):0;
//							Product productObj=productService.getProductId(id);
//							if(json2.get("categories")!=null && !(json2.get("categories") instanceof JSONArray))
//							{
//								JSONObject jarray3=!json2.isEmpty() ? (JSONObject) json2.get("categories"):null;
//								if(jarray3 != null) 
//								{
//									for(int s=0;s<jarray3.size();s++)
//									{
//										int check=0;
//										check++;
//										if(jarray3.toString() != null)
//										{						
//
//											String cname=(String) jarray3.get("cat_1");
//											String s1=cname.replace("&amp;","&");	
//											ProductType pt=new ProductType();
//											pt=productService.getProductTypeIdByProductTypeName(s1);		
//											if(productObj == null)
//											{
//												productObj=new Product();
//												productObj.setProductId(id);
//												productObj.setProductName(name);
//												productObj.setPrice(price);
//												productObj.setProductType(pt);
//												pi =productService.addNewProduct(productObj);
//												productObj = productService.getById(pi);
//
//											} 
//
//
//										}
//									}
//								}
//								pk.setProduct(productObj);									
//							}
//
//							Product productOb=productService.getProductName( (String)json2.get("name"));
//							if(productObj==null)
//							{
//								productObj=new Product();
//								productObj.setProductId(id);
//								productObj.setProductName(name);
//								productObj.setPrice(price);
//								productObj.setQuantity(qt);
//
//								pi =	productService.addNewProduct(productObj);
//								productObj = productService.getById(pi);
//							}
//							pk.setProduct(productObj);
//							json.put("name", name);
//							json.put("id",id);
//							json.put("price", price);
//							json.put("qt",qt);
//
//							jsonArray.add(json);	
//							System.out.println("KIOSK ID "+pk.getKiosk().getId());
//							System.out.println("PRODUCT ID"+pk.getProduct().getId());
//
//							ProductKiosk prk = productKioskService.getProductKioskByProductandKioskId(pk.getKiosk().getId(), pk.getProduct().getId());
//							if(prk == null)
//							{
//								productKioskService.registerNewProductKiosk(pk);
//							}
//
//						}
//
//					}
//				}
//			}
//
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//		}
//		return jsonArray;
//	}
	
	
	@Scheduled(cron = "0 0/1 9 * * *",zone="UTC")
	public void getPromotionResponse() throws ParseException 
	{

		JSONObject  jsonObject=new JSONObject();
		String value=" ";

		String user="944191bfbc1d87ee4117b800c06fd967";
		try {   
			URL url = new URL("https://data.point24h.com/mobile_webservice/getAvailablePromo.php?user="+user);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "+ conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			String output;
			while ((output = br.readLine()) != null) {
				value= output;
			}
			conn.disconnect();
			jsonObject =getPromo(value);
		} catch (MalformedURLException e) {
			logger.error("getPromotionResponse ",e);		
			}
		catch (IOException e) {
			logger.error("getPromotionResponse ",e);
		}
	

	}


	private JSONObject getPromo(String value) 
	{
		Rewards reward=null;
		try
		{
			System.out.println("JSON "+value);
			JSONArray obj=(JSONArray) new JSONParser().parse(value);
			JSONArray jo = (JSONArray) obj; 

			for(int i=0;i<jo.size();i++)
			{
				JSONObject jsonObject = (JSONObject) jo.get(i);
				String code=(String) jsonObject.get("code");
				String name=(String) jsonObject.get("name");
				String startDate=(String) jsonObject.get("start_date");
				String endDate=(String) jsonObject.get("end_date");
				String productCode=(String) jsonObject.get("product_code");
				String productName=(String) jsonObject.get("product_name");
				String machine=(String) jsonObject.get("machine");
				String barcodepath1 = CommonProperties.getBasePath()
						+ CommonProperties.getImagePath() + CommonProperties.getBarcode();
				System.out.println(barcodepath1);
				System.out.println("ajdhuywgdty"+(CommonProperties.getBasePath()+CommonProperties.getContextPath()));

				reward=adminService.getRewardByPromoCode(code);
				if(reward==null)
				{
					String barcodepath = CommonProperties.getBaseURL()+CommonProperties.getContextPath()
							+ CommonProperties.getImagePath() + CommonProperties.getBarcode();
					System.out.println("BAX"+barcodepath);
				
					JSONObject json = generateBarcode(code);
					System.out.println(barcodepath);
					System.out.println("INN PROMOTION ");
					reward=new Rewards();
					reward.setPromoCode(code);
					reward.setActive(true);
					reward.setCreatedOn(new Date());
					reward.setRewardsName(name);
					reward.setStartDate(startDate);
					reward.setEndDate(endDate);
					reward.setProductName(productName);
					reward.setProductCode(productCode);
					reward.setMachine(machine);
					String path = json.get("path").toString();
					reward.setBarcode(path);
					reward.setBarcode(barcodepath + "/" + reward.getBarcode());
					adminService.registerRewardInfo(reward);
		
				
				}




			}
		}
		catch(Exception e)
		{
			logger.error("getPromo ",e);		
			}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	private JSONObject generateBarcode(String couponCode) throws DocumentException, IOException {
		JSONObject json = new JSONObject();
		System.out.println("ajdhuywgdty"+CommonProperties.getBasePath());
		String path1 = CommonProperties.getBasePath()+CommonProperties.getContextPath() ;
        String path2 =commonUtils.createExportDirectory(path1, CommonProperties.getImagePath());
		String	path =commonUtils.createExportDirectory(path2, CommonProperties.getBarcode());
		try {
			Barcode128 code128 = new Barcode128();
			code128.setCode(couponCode);
			java.awt.Image rawImage = code128.createAwtImage(Color.BLACK, Color.WHITE);
			BufferedImage resizedImage = new BufferedImage(500, 120, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = resizedImage.createGraphics();
			g.drawImage(rawImage, 0, 0, 500, 120, null);
			ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
			ImageIO.write(resizedImage, "png", bytesOut);
			g.dispose();

			byte[] pngImageData = bytesOut.toByteArray();
			try(FileOutputStream fos = new FileOutputStream(path + "/" + couponCode + ".png"))
			{
			fos.write(pngImageData);
			fos.close();
			json.put("values", couponCode);
			json.put("path", couponCode + ".png");
			return json;
			}
		} catch (Exception e) {
			logger.error("generateBarcode ",e);
			
		}
		return json;
	}

	
	
	
	
	

}
