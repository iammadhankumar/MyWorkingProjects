package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.domain.Product;



@XmlRootElement(name="Product")
public class AddProductResponse {	
	
	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="product")
	private Product product=new Product();
	
	@XmlElement(name="kiosk")
	private long kioskId;
	
	
	@XmlElement(name="quantity")
	private long quantity;
	


//
//	@XmlElement(name="productkiosk")
//	private ProductKiosk productKiosk=new ProductKiosk();
	
	



	

	public long getQuantity() {
		return quantity;
	}
	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}
	public long getKioskId() {
		return kioskId;
	}
	public void setKioskId(long kioskId) {
		this.kioskId = kioskId;
	}
	public ResponseStatus getStatus() {
		return status;
	}
	public void setStatus(ResponseStatus status) {
		this.status = status;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
//	public ProductKiosk getProductKiosk() {
//		return productKiosk;
//	}
//	public void setProductKiosk(ProductKiosk productKiosk) {
//		this.productKiosk = productKiosk;
//	}
//	public Product getEntity() {
//		return product;
//	}
//	public void setEntity(Product product) {
//		this.product = product;
//	}
	
	

	public AddProductResponse(){
		super();
	}
	
	
	



	public AddProductResponse(ResponseStatus status,Product product,long kioskId,long quantity){
		super();
		this.status=status;
		this.product=product;
		this.kioskId=kioskId;
		this.quantity=quantity;

		
	}
	
	
	
	
	public AddProductResponse(ResponseStatus status){
		this.status=status;
	}
	
	
}
