package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.views.ProductView;


@XmlRootElement(name = "product")
public class ProductMessage {
	
	@XmlElement(name = "status")
	public ResponseStatus status;

	private Collection<ProductView> entities;

	@XmlElement(name = "ProductView")
	public Collection<ProductView> getEntities() {
		return entities;
	}
	@XmlElement(name = "count")
	public long count;
	



	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	public void setEntities(Collection<ProductView> entities) {
		this.entities = entities;
	}

	public ProductMessage(){
		super();
	}
	
	public ProductMessage(ResponseStatus status,Collection<ProductView>entities){
		super();
		this.status=status;
		this.entities=entities;
	}
	
	public ProductMessage(ResponseStatus status,Collection<ProductView> entities,long count){
		super();
		this.status=status;
		this.entities=entities;
		this.count=count;
	}
	

	
	public ProductMessage(ResponseStatus status,long count){
		super();
		this.status=status;
		this.count=count;
	}
}
