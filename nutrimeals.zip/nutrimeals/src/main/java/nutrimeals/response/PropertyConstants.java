package nutrimeals.response;

public class PropertyConstants {

	private PropertyConstants()
	{
		
	}
	public static final String CACHECONTROL = "Cache-Control";
	public static final String NOCACHE = "no-cache";
	public static final String PASSVALIDATION = "passwordValidation";
			public static final String NORECORD = "user.NoRecord";
			public static final String POSTID = "postId";
			public static final String SUCCESS ="sucessGeneralMsg";
			public static final String INTERNALERROR ="InternalError";
			public static final String ALREADYEXIST="user.AlreadyExists";	
			public static final String INVALIDCREDENTIALS = "error.invalidCredentials";
			public static final String ERROR = "error";
			public static final String ERRORDESCRIPTION = "error_description";
			public static final String INVALID= "invalid";
			public static final String ERRORCODE ="error_code";
			public static final String USERNAME = "username";
			public static final String CLIENT = "nutrimeals";
			public static final String AUTHORIZED_GRANT_TYPE = "password";
			public static final String SECRET = "nutrimeals";
			//public static final String CHANGE_PWD ="CHANGEPASSWORD";




			
			public static final String PASS = "password";
			
}
