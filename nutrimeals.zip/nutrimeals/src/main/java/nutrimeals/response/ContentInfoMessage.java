package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.domain.ContentInfo;

@XmlRootElement(name="ContentInfo")
public class ContentInfoMessage {

	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="ContentInfo")
	private ContentInfo entity=new ContentInfo();			
	public ContentInfoMessage(){
		super();
	}		
	public ContentInfo getEntity() {
		return entity;
	}
	public void setEntity(ContentInfo entity) {
		this.entity = entity;
	}
	public ContentInfoMessage(ContentInfo Contentinfo){
		super();
		setEntity(Contentinfo);
	}		
	public ContentInfoMessage(ResponseStatus status,ContentInfo Contentinfo){
		super();
		this.status=status;
		this.entity=Contentinfo;
	}
}