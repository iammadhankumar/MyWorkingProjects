package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;

import nutrimeals.domain.Order;
import nutrimeals.domain.UserInfo;

public class OrderMessage {
	
	@XmlElement(name="status")
	public ResponseStatus status;
	
	@XmlElement(name="order")
	private Order orderentities=new Order();
	
	@XmlElement(name="order")
	private UserInfo userEntity;
	

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public Order getOrderentities() {
		return orderentities;
	}

	public void setOrderentities(Order orderentities) {
		this.orderentities = orderentities;
	}

	public UserInfo getUserEntity() {
		return userEntity;
	}

	public void setUserEntity(UserInfo userEntity) {
		this.userEntity = userEntity;
	}


	public OrderMessage(ResponseStatus status, Order orderentities, UserInfo user) {
		super();
		this.status = status;
		this.orderentities = orderentities;
		this.userEntity = user;
	}

	public OrderMessage(ResponseStatus status, Order orderentities) {
		super();
		this.status = status;
		this.orderentities = orderentities;
	}
	



}
