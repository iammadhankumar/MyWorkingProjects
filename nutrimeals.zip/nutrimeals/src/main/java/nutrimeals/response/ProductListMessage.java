package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.domain.Product;


@XmlRootElement(name = "product")
public class ProductListMessage {
	
	@XmlElement(name = "status")
	public ResponseStatus status;

	private Collection<Product> entities;

	@XmlElement(name = "Product")
	public Collection<Product> getEntities() {
		return entities;
	}
	@XmlElement(name = "count")
	public long count;
	

	
	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}



	
	public ProductListMessage(ResponseStatus status,Collection<Product>entities){
		super();
		this.status=status;
		this.entities=entities;
	}
	
	public ProductListMessage(ResponseStatus status,Collection<Product>entities,long count){
		super();
		this.status=status;
		this.entities=entities;
		this.count=count;
	}
	

	
	public ProductListMessage(ResponseStatus status,long count){
		super();
		this.status=status;
		this.count=count;
	}
}
