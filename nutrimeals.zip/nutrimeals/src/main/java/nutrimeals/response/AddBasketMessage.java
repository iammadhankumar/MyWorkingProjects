package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.domain.Basket;


@XmlRootElement(name = "Bucket")
public class AddBasketMessage {
	
	@XmlElement(name = "status")
	public ResponseStatus status;

	private Collection<Basket> entities;

	@XmlElement(name = "Bucket")
	public Collection<Basket> getEntities() {
		return entities;
	}
	
	public AddBasketMessage(){
		super();
	}
	
	public AddBasketMessage(ResponseStatus status,Collection<Basket>entities){
		super();
		this.status=status;
		this.entities=entities;
	}
}

