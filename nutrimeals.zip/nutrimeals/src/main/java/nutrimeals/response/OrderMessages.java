package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;

import nutrimeals.views.OrderView;

public class OrderMessages {
	
	@XmlElement(name="status")
	public ResponseStatus status;
	
	@XmlElement(name="order")
	private Collection<OrderView> orderentities;
	
	@XmlElement(name="count")
	private long orderCount;

	
	public long getOrderCount() {
		return orderCount;
	}

	public void setOrderCount(long orderCount) {
		this.orderCount = orderCount;
	}

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public Collection<OrderView> getOrderentities() {
		return orderentities;
	}

	public void setOrderentities(Collection<OrderView> orderentities) {
		this.orderentities = orderentities;
	}

	
	public OrderMessages(ResponseStatus status,Collection<OrderView> orderentities,long orderCount)
	{
		super();
		this.status=status;
		this.orderentities=orderentities;
		this.orderCount=orderCount;
		
	}

}
