package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.domain.Product;



@XmlRootElement(name="Product")
public class ProductMessages {	
	
	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="product")
	private Product product=new Product();

	
	public Product getEntity() {
		return product;
	}
	public void setEntity(Product product) {
		this.product = product;
	}
	public ProductMessages(){
		super();
	}
	
	
	

	public ProductMessages(Product product){
		super();
		setEntity(product);
	}

	public ProductMessages(ResponseStatus status,Product product){
		super();
		this.status=status;
		this.product=product;
	}
	
	
	public ProductMessages(ResponseStatus status){
		this.status=status;
	}
	
	
}


