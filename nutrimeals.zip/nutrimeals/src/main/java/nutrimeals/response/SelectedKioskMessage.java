package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;

import nutrimeals.domain.Kiosk;

public class SelectedKioskMessage {
	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="Kiosk")
	private Kiosk entity=new Kiosk();	
	public SelectedKioskMessage(){
		super();
	}
	public Kiosk getEntity() {
		return entity;
	}
	public void setEntity(Kiosk entity) {
		this.entity = entity;
	}
	public SelectedKioskMessage(Kiosk kiosk){
		super();
		setEntity(kiosk);
	}
	public SelectedKioskMessage(ResponseStatus status,Kiosk kiosk){
		super();
		this.status=status;
		this.entity=kiosk;
	}
}