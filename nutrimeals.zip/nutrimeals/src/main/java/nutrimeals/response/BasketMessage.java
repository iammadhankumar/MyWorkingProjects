package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;

import nutrimeals.domain.Basket;



public class BasketMessage {
	
	@XmlElement(name="status")
	public ResponseStatus status;


	@XmlElement(name="basket")
	private Basket basketInfo;


	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}
	

	public Basket getBasketInfo() {
		return basketInfo;
	}

	public void setBasketInfo(Basket basketInfo) {
		this.basketInfo = basketInfo;
	}

	public BasketMessage(ResponseStatus status, Basket basketInfo) {
		super();
		this.status = status;
		this.basketInfo = basketInfo;
	}


}
