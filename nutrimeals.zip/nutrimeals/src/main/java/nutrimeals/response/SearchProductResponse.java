package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;

import nutrimeals.domain.Product;

public class SearchProductResponse {
	
	@XmlElement(name = "status")
	public ResponseStatus status;

	private Collection<Product> entities;

	@XmlElement(name = "Product")
	public Collection<Product> getEntities() {
		return entities;
	}
	@XmlElement(name = "count")
	public long count;
	

	
	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}


	public SearchProductResponse(){
		super();
	}
	
	public SearchProductResponse(ResponseStatus status,Collection<Product>entities){
		super();
		this.status=status;
		this.entities=entities;
	}
	
	public SearchProductResponse(ResponseStatus status,Collection<Product>entities,long count){
		super();
		this.status=status;
		this.entities=entities;
		this.count=count;
	}
	

}
