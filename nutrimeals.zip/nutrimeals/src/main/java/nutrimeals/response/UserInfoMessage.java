package nutrimeals.response;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.json.simple.JSONObject;

import nutrimeals.domain.UserInfo;

@XmlRootElement(name="user")
public class UserInfoMessage
{
		@XmlElement(name="status")
		public ResponseStatus status;

		@XmlElement(name="user")
		private UserInfo entity=new UserInfo();

		@XmlElement(name="token")
		private JSONObject token=new JSONObject();
		
		public ResponseStatus getStatus() {
			return status;
		}

		public void setStatus(ResponseStatus status) {
			this.status = status;
		}

		public UserInfo getEntity() {
			return entity;
		}

		public void setEntity(UserInfo entity) {
			this.entity = entity;
		}

		public JSONObject getToken() {
			return token;
		}

		public void setToken(JSONObject token) {
			this.token = token;
		}


		
	
		public UserInfoMessage(ResponseStatus status,UserInfo user){
			super();
			this.status=status;
			this.entity=user;
		}	
		
		public UserInfoMessage(ResponseStatus status,UserInfo user,JSONObject  token){
			super();
			this.status=status;
			this.entity=user;
			this.token=token;
		}	
		
		

		
		
		
		public UserInfoMessage(ResponseStatus status){
			super();
			this.status=status;
			
		}

	}


