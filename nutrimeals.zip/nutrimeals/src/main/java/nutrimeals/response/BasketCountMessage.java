package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.customdomain.BasketCount;
import nutrimeals.domain.Basket;


@XmlRootElement(name = "BasketCount")

public class BasketCountMessage {

	@XmlElement(name = "status")
	public ResponseStatus status;


	private Basket basket;
	
	private BasketCount entities;
	 

	


	@XmlElement(name = "Product")
	public BasketCount getEntities() {
		return entities;
	}
	
	public BasketCountMessage(){
		super();
	}
	
	public BasketCountMessage(ResponseStatus status,BasketCount entities){
		super();
		this.status=status;
		this.entities=entities;
	}
	

	
	
	public BasketCountMessage(ResponseStatus status,BasketCount entities,Basket basket){
		super();
		this.status=status;
		this.entities=entities;
		this.basket=basket;
	}
}


