package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.domain.RecentViewProducts;

@XmlRootElement(name="RecentViewProduct")
public class RecentViewMessage {
	
	@XmlElement(name="status")
	public ResponseStatus status;
	
	@XmlElement(name="product")
	private Collection<RecentViewProducts> entities;
	
	long count=0;

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public Collection<RecentViewProducts> getEntities() {
		return entities;
	}

	public void setEntities(Collection<RecentViewProducts> entities) {
		this.entities = entities;
	}
	
	
	public RecentViewMessage(ResponseStatus status,Collection<RecentViewProducts> entities,long count){
		super();
		this.status=status;
		this.entities=entities;
		this.count=count;
	}

}
