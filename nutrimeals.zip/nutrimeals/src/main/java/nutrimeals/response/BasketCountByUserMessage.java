package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.customdomain.BasketCountByUser;



@XmlRootElement(name = "BasketCountByUser")

public class BasketCountByUserMessage {
	
	@XmlElement(name = "status")
	public ResponseStatus status;


	
	private BasketCountByUser entities;
	
	@XmlElement(name = "Basket")
	public BasketCountByUser getEntities() {
		return entities;
	}
	
	
	public BasketCountByUserMessage(ResponseStatus status,BasketCountByUser entities){
		super();
		this.status=status;
		this.entities=entities;
	}
	

}
