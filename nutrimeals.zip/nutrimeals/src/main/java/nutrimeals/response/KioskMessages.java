package nutrimeals.response;



import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.domain.Kiosk;

@XmlRootElement(name="Kiosk")
public class KioskMessages {

	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name = "Kiosk")
	private Kiosk entity;
	

	public Kiosk getEntity() {
		return entity;
	}



	public void setEntity(Kiosk entity) {
		this.entity = entity;
	}



	public KioskMessages(){
		super();
	}
	
	
	
	public ResponseStatus getStatus() {
		return status;
	}
	public void setStatus(ResponseStatus status) {
		this.status = status;
	}
	
	public KioskMessages(ResponseStatus status,Kiosk entity){
		super();
		this.status=status;
		this.entity=entity;
	
	}
}