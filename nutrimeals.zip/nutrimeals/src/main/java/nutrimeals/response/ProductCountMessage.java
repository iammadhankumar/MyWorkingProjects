package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.customdomain.ProductCount;


@XmlRootElement(name = "ProductCount")

public class ProductCountMessage {

	@XmlElement(name = "status")
	public ResponseStatus status;

	private ProductCount entities;

	@XmlElement(name = "Product")
	public ProductCount getEntities() {
		return entities;
	}
	
	public ProductCountMessage(){
		super();
	}
	
	public ProductCountMessage(ResponseStatus status,ProductCount entities){
		super();
		this.status=status;
		this.entities=entities;
	}
	
}

