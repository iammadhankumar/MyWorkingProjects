package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.domain.Product;

@XmlRootElement(name = "product")
public class ProdutResponse {
	
	
	@XmlElement(name = "status")
	public ResponseStatus status;

	private Collection<Product> entities;
	
	@XmlElement(name = "count")
	public long count;


	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public Collection<Product> getEntities() {
		return entities;
	}

	public void setEntities(Collection<Product> entities) {
		this.entities = entities;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}
	
	public ProdutResponse(ResponseStatus status, Collection<Product> entities) {
		super();
		this.status = status;
		this.entities = entities;
	}

	public ProdutResponse(ResponseStatus status, Collection<Product> entities, long count) {
		super();
		this.status = status;
		this.entities = entities;
		this.count = count;
	}


}
