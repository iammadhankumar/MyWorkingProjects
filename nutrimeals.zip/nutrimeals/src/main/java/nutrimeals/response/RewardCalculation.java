package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;

public class RewardCalculation {
	
	@XmlElement(name="status")
	public ResponseStatus status;
	
	@XmlElement(name="grandtotal")
	public float grandTotal;
	
	@XmlElement(name="rewardsPercentage")
	public double rewardsPercentage;
	
	@XmlElement(name="discountPrice")
	public float discountedPrice;
	
	@XmlElement(name="offerPrice")
	public float offerPrice;

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public float getGrandTotal() {
		return grandTotal;
	}

	public void setGrandTotal(float grandTotal) {
		this.grandTotal = grandTotal;
	}

	public double getRewardsPercentage() {
		return rewardsPercentage;
	}

	public void setRewardsPercentage(double rewardsPercentage) {
		this.rewardsPercentage = rewardsPercentage;
	}

	public float getDiscountedPrice() {
		return discountedPrice;
	}


	public void setDiscountedPrice(float discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public float getOfferPrice() {
		return offerPrice;
	}

	public void setOfferPrice(float offerPrice) {
		this.offerPrice = offerPrice;
	}

	
	public RewardCalculation(ResponseStatus status, float grandTotal, double d, float discountedPrice,
			float offerPrice) {
		super();
		this.status = status;
		this.grandTotal = grandTotal;
		this.rewardsPercentage = d;
		this.discountedPrice = discountedPrice;
		this.offerPrice = offerPrice;
	}




}
