package nutrimeals.response;


public class MessageConstants {
	public static final String FORGET ="FORGET";
	public static final String REGISTER ="REG";
	public static final String ENHANCELIMIT ="ENHANCELIMIT";
	public static final String PHONEUPDATE ="PHONEUPDATE";
	public static final String EMAILUPDATE ="EMAILUPDATE";
	public static final String EMAILVERIFY ="EMAILVERIFY";
	public static final String PHONEVERIFY ="PHONEVERIFY";
	public static final String INVITEEMAILSUBJECT ="Invitation email for Sportizzle";
	public static final String OAUTHSPORTIZZLE ="sportizzle";
	public static final String OAUTH ="oauth/token";
	public static final String PLIVOAUTHID ="MAODYWYJFLMZM1NTA4YZ";
	public static final String PLIVOAUTHTOKEN ="YjI2ZDQ2NzgzODZkZGE0ZjFhZGI1ZDYzOWI4NzBh";
	public static final String FCMSERVERAPIKEY = "AAAAgVrXYj0:APA91bGmwNGR4qMVwkMPrjA_TBD34zxoeXal-o4TOIVq57tTME42WFvPf3pxeL6cZXX1nET397OxDDvP5Tfk72gJc1K7jHF0_UXb4Ks_zhjUZ19nxIYjJihP6ZUddkf00TpTrOhSlbM1";
	public static final String FCMURL = "https://fcm.googleapis.com/fcm/send";
	public static final String PULLSUCCESS = "PULLSUCCESS";
	public static final String PULLFAILURE ="PULLFAILURE";
	public static final String PUSHSUCCESS ="PUSHSUCCESS";
	public static final String PUSHFAILURE ="PUSHFAILURE";
	public static final String REVERSED ="REVERSED";
	public static final String SUCCESS ="SUCCESS";
	public static final String FAILURE ="FAILURE";
	public static final String PENDING ="PENDING";
	public static final String INQUIREEMAILSUBJECT ="Inquire email from Affiliate and Partner";
	public static final String LIMITREQUEST ="Limit Request";
	public static final String APPROVEUSERLIMIT ="Limit Approval";
	public static final String REJECTUSERLIMIT ="Limit Rejected";
	public static final String TRANSACTION ="Transaction";
	public static final String ACCEPT ="ACCEPT";
	public static final String REJECT ="REJECT";
	public static final String REVIEW ="REVIEW";
	public static final String LATITUDE ="(String)expr.evaluate(document, XPathConstants.STRING)";
	public static final String LONGTITUDE="(String)expr.evaluate(document, XPathConstants.STRING)";
	
	
}
