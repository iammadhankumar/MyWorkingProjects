package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.views.KioskView;

@XmlRootElement(name="Kiosk")
public class KioskMessage {

	@XmlElement(name="status")
	public ResponseStatus status;	
	private Collection<KioskView> entities;
	long count;
	//private ProductKioskCount count;

	public ResponseStatus getStatus() {
		return status;
	}
	public void setStatus(ResponseStatus status) {
		this.status = status;
	}
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	public void setEntities(Collection<KioskView> entities) {
		this.entities = entities;
	}
	@XmlElement(name = "Kiosk")
	public Collection<KioskView> getEntities() {
		return entities;
	}
	public KioskMessage(){
		super();
	}
	public KioskMessage(ResponseStatus status,Collection<KioskView> entities,long count){
		super();
		this.status=status;
		this.entities=entities;
		this.count=count;
		
	}
}