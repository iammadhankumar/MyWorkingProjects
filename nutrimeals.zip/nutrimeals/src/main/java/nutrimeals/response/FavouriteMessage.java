package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.domain.FavProduct;


@XmlRootElement(name = "product")
public class FavouriteMessage {
	
	@XmlElement(name = "status")
	public ResponseStatus status;

	private Collection<FavProduct> entities;

	@XmlElement(name = "FavProduct")
	public Collection<FavProduct> getEntities() {
		return entities;
	}
	@XmlElement(name = "count")
	public long count;
	
	public FavouriteMessage(){
		super();
	}
	
	public FavouriteMessage(ResponseStatus status,Collection<FavProduct> entities){
		super();
		this.status=status;
		this.entities=entities;
	}
	
	public FavouriteMessage(ResponseStatus status,Collection<FavProduct> entities,long count){
		super();
		this.status=status;
		this.entities=entities;
		this.count=count;
	}
	
	
	public FavouriteMessage(ResponseStatus status){
		super();
		this.status=status;
	}
}
