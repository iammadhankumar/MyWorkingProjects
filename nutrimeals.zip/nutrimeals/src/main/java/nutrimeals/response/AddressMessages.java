package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;

import nutrimeals.domain.BillingAddress;
import nutrimeals.domain.ShippingAddress;

public class AddressMessages {

	@XmlElement(name = "status")
	public ResponseStatus status;

	private Collection<ShippingAddress> shippingEntities;
	
	private Collection<BillingAddress> billingEntities;

	@XmlElement(name = "ShippingAddress")
	public Collection<ShippingAddress> getShippingEntities() {
		return shippingEntities;
	}
	
	
	@XmlElement(name = "BillingAddress")
	public Collection<BillingAddress> getBillingEntities() {
		return billingEntities;
	}
	
	
	
	public AddressMessages(ResponseStatus status,Collection<ShippingAddress> shippingEntities,Collection<BillingAddress> billingEntities){
		super();
		this.status=status;
		this.shippingEntities=shippingEntities;
		this.billingEntities=billingEntities;
	}
	
}
