package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;

import nutrimeals.domain.Rewards;

public class RewardMessages {
	
	@XmlElement(name = "status")
	private ResponseStatus status;
	
	@XmlElement(name="reward")
	private Collection<Rewards> reward;
	
	private long count;

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public Collection<Rewards> getReward() {
		return reward;
	}

	public void setReward(Collection<Rewards> reward) {
		this.reward = reward;
	}

	
	public RewardMessages(ResponseStatus status,Collection<Rewards> reward,long count){
		super();
		this.status=status;
		this.reward=reward;
		this.count=count;
	}
	
	

}
