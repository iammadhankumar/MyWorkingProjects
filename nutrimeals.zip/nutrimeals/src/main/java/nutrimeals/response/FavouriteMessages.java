package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.domain.FavProduct;



@XmlRootElement(name="FavProduct")
public class FavouriteMessages {	
	
	@XmlElement(name="status")
	public ResponseStatus status;

	

	@XmlElement(name="favproduct")
	private FavProduct fav=new FavProduct();
	
	
	
	public FavProduct getFav() {
		return fav;
	}
	public void setFav(FavProduct fav) {
		this.fav = fav;
	}
	
	
	
	
	public FavouriteMessages(ResponseStatus status,FavProduct fav){
		this.status=status;
		this.fav=fav;
	}
	
}