package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.domain.User;

@XmlRootElement(name="user")
public class UpdateUserMessage {

	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="user")
	private User _entity=new User();
	
	

	public User getUser() {
		return _entity;
	}
	public void setEntity(User user) {
		this._entity = user;
	}	
	public UpdateUserMessage(){
		super();
	}	
	public UpdateUserMessage(User user){
		super();
		setEntity(user);
	}	
	public UpdateUserMessage(ResponseStatus status,User user){
		super();
		this.status=status;
		this._entity=user;
	}	
	
	public UpdateUserMessage(ResponseStatus status){
		super();
		this.status=status;

	}
	
	
}