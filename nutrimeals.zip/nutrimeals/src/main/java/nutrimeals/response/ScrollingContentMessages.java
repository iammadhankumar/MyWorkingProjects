package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;

import nutrimeals.domain.ScrollingContent;

public class ScrollingContentMessages {
	
	@XmlElement(name = "status")
	public ResponseStatus status;
	
	@XmlElement(name = "scrollingcontent")
	public Collection<ScrollingContent> scrollingContent;
	
	
	@XmlElement(name = "count")
	public long count;


	public ResponseStatus getStatus() {
		return status;
	}


	public void setStatus(ResponseStatus status) {
		this.status = status;
	}


	public Collection<ScrollingContent> getScrollingContent() {
		return scrollingContent;
	}


	public void setScrollingContent(Collection<ScrollingContent> scrollingContent) {
		this.scrollingContent = scrollingContent;
	}


	public long getCount() {
		return count;
	}


	public void setCount(long count) {
		this.count = count;
	}
	
	public ScrollingContentMessages(ResponseStatus status,Collection<ScrollingContent> scrollingContent,long count){
		super();
		this.status=status;
		this.scrollingContent=scrollingContent;
		this.count=count;
	}

}
