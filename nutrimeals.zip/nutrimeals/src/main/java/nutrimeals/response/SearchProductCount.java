package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;

import nutrimeals.domain.Product;

public class SearchProductCount {
	
	@XmlElement(name = "status")
	public ResponseStatus status;

	private Collection<Product> entities;

	@XmlElement(name = "Product")
	public Collection<Product> getEntities() {
		return entities;
	}
	@XmlElement(name = "count")
	public long count;
	

	
	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}


	public SearchProductCount(){
		super();
	}
	
	public SearchProductCount(ResponseStatus status,Collection<Product>entities){
		super();
		this.status=status;
		this.entities=entities;
	}
	
	public SearchProductCount(ResponseStatus status,Collection<Product>entities,long count){
		super();
		this.status=status;
		this.entities=entities;
		this.count=count;
	}
	

}
