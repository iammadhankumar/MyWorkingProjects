package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.domain.UserInfo;

@XmlRootElement(name="entity")
public class UserMessage {

	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="userinfo")
	private UserInfo entity=new UserInfo();

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public UserInfo getEntity() {
		return entity;
	}

	public void setEntity(UserInfo entity) {
		this.entity = entity;
	}
	


	public UserMessage() {
		super();
	}

	public UserMessage(ResponseStatus status, UserInfo entity) {
		super();
		this.status = status;
		this.entity = entity;
	}

	




}