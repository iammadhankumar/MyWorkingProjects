package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;

import nutrimeals.domain.BillingAddress;
import nutrimeals.domain.ShippingAddress;


public class AddressMessage {
	
	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="shippingaddress")
	private ShippingAddress shippingentities=new ShippingAddress();
	
	@XmlElement(name="billingaddress")
	private BillingAddress billingentities=new BillingAddress();
	
	public ShippingAddress getShippingAddress() {
		return shippingentities;
	}
	public void setEntity(ShippingAddress shippingentities) {
		this.shippingentities = shippingentities;
	}	
	
	public BillingAddress getBillingAddress()
	{
		return billingentities;
	}
	
	public void setEntity(BillingAddress billingentities)
	{
		this.billingentities=billingentities;
	}
	
	public AddressMessage(ResponseStatus status,ShippingAddress shippingaddress){
		super();
		this.status=status;
		this.shippingentities=shippingaddress;
	}	
	

	public AddressMessage(ResponseStatus status,BillingAddress billingaddress){
		super();
		this.status=status;
		this.billingentities=billingaddress;
	}	
	
	
	public AddressMessage(ResponseStatus status,ShippingAddress shippingaddress,BillingAddress billingaddress){
		super();
		this.status=status;
		this.shippingentities=shippingaddress;
		this.billingentities=billingaddress;
	}	
	

}
