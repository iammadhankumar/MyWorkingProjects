package nutrimeals.response;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.domain.UserInfo;

@XmlRootElement(name="users")
public class UserMessages {

	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="userinfo")
	private List<UserInfo> _entity=new ArrayList<>();
	

	public ResponseStatus getStatus() {
		return status;
	}
	public void setStatus(ResponseStatus status) {
		this.status = status;
	}
	public List<UserInfo> get_entity() {
		return _entity;
	}
	public void set_entity(List<UserInfo> _entity) {
		this._entity = _entity;
	}
	
	public List<UserInfo> getUser() {
		return _entity;
	}
	public void setEntity(List<UserInfo> user) {
		this._entity = (List<UserInfo>) user;
	}	
	public UserMessages(){
		super();
	}	
	public UserMessages(List<UserInfo> user){
		super();
		setEntity(user);
	}	

	
	
	public UserMessages(ResponseStatus status,List<UserInfo> user){
		super();
		this.status=status;
		this._entity=user;
	
	}
}