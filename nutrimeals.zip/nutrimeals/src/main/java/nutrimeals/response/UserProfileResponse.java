package nutrimeals.response;

import javax.xml.bind.annotation.XmlElement;

import nutrimeals.domain.UserProfile;

public class UserProfileResponse {
	

	@XmlElement(name="status")
	public ResponseStatus status;

	@XmlElement(name="userprofile")
	private UserProfile userProfileEntity=new UserProfile();

	public UserProfileResponse(ResponseStatus status) {
		super();
		this.status = status;
	}

	public UserProfileResponse(ResponseStatus status, UserProfile userProfileEntity) {
		super();
		this.status = status;
		this.userProfileEntity = userProfileEntity;
	}

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public UserProfile getUserProfileEntity() {
		return userProfileEntity;
	}

	public void setUserProfileEntity(UserProfile userProfileEntity) {
		this.userProfileEntity = userProfileEntity;
	}

}
