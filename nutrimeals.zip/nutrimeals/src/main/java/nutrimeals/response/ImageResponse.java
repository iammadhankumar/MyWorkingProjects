package nutrimeals.response;

public class ImageResponse {
	

	
	private ResponseStatus status;	
	
	private String image;

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
	

	

	
	public ImageResponse(ResponseStatus status,String image){
		super();
		this.status=status;
		this.image=image;
		
	}
}
