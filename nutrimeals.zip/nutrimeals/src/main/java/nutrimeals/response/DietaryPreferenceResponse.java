package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;

import nutrimeals.domain.DietaryPreference;




public class DietaryPreferenceResponse {
	
	
	@XmlElement(name="status")
	public ResponseStatus status;
	
	@XmlElement(name = "DietaryPreference")
	private Collection<DietaryPreference> entities;
	
	@XmlElement(name = "count")
	private long count;

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public Collection<DietaryPreference> getEntities() {
		return entities;
	}

	public void setEntities(Collection<DietaryPreference> entities) {
		this.entities = entities;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}
	
	public DietaryPreferenceResponse() {
		super();

	}

	public DietaryPreferenceResponse(ResponseStatus status, Collection<DietaryPreference> entities, long count) {
		super();
		this.status = status;
		this.entities = entities;
		this.count = count;
	}

	
	
}
