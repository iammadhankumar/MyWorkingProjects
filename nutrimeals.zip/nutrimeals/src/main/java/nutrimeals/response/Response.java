package nutrimeals.response;


import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Response {

	@XmlElement(name="status")
	public int status=0;

	@XmlElement(name="message")
	public String msg="";

	public Response(ResponseStatus status2){
		super();
	}

	public Response(int status, String msg){
		super();
		this.status =status;
		this.msg=msg;
	}

	public Response(Response status2) {
		super();
		this.status =status2.status;
		this.msg=status2.msg;
	}
}

