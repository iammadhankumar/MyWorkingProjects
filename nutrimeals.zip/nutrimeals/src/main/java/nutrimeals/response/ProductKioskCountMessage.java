package nutrimeals.response;

import java.util.Collection;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import nutrimeals.customdomain.ProductKioskCount;
import nutrimeals.domain.Kiosk;
import nutrimeals.domain.ProductKiosk;

@XmlRootElement(name = "ProductKioskCount")
public class ProductKioskCountMessage {

	
	@XmlElement(name = "status")
	public ResponseStatus status;
	
	@XmlElement(name = "Product")
	private ProductKioskCount productKioskCount;
	
	@XmlElement(name = "Kiosk")
	private Collection<Kiosk> kioskEntities;
	
	@XmlElement(name = "Kiosk")
	private Collection<ProductKiosk> productKioskEntities;

	public ResponseStatus getStatus() {
		return status;
	}



	public void setStatus(ResponseStatus status) {
		this.status = status;
	}



	public Collection<ProductKiosk> getProductKioskEntities() {
		return productKioskEntities;
	}



	public void setProductKioskEntities(Collection<ProductKiosk> productKioskEntities) {
		this.productKioskEntities = productKioskEntities;
	}



	public void setKioskEntities(Collection<Kiosk> kioskEntities) {
		this.kioskEntities = kioskEntities;
	}



	@XmlElement(name = "Kiosk")
	public ProductKioskCount getEntities() {
		return productKioskCount;
	}
	
	
	





	public ProductKioskCount getProductKioskCount() {
		return productKioskCount;
	}



	public void setProductKioskCount(ProductKioskCount productKioskCount) {
		this.productKioskCount = productKioskCount;
	}



	public Collection<Kiosk> getKioskEntities() {
		return kioskEntities;
	}




	

	public ProductKioskCountMessage(ResponseStatus status,ProductKioskCount productKioskCount) {
		this.status=status;
		this.productKioskCount=productKioskCount;
	}
	
}
