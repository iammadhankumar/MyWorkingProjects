package nutrimeals.response;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

import nutrimeals.domain.CartTotal;
import nutrimeals.domain.UserInfo;
import nutrimeals.views.CartListView;



public class BasketMessages {
	
	@XmlElement(name="status")
	private ResponseStatus status;

	@XmlElement(name="basket")
	private List<CartListView> entities;
	
	@XmlElement(name="carttotal")
	private CartTotal cartAmountInfo;
	
	@XmlElement(name="user")
	private UserInfo user;



	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	public List<CartListView> getEntities() {
		return entities;
	}

	public void setEntities(List<CartListView> entities) {
		this.entities = entities;
	}
	
	
	
	public CartTotal getCartAmountInfo() {
		return cartAmountInfo;
	}

	public void setCartAmountInfo(CartTotal cartAmountInfo) {
		this.cartAmountInfo = cartAmountInfo;
	}

	public UserInfo getUser() {
		return user;
	}

	public void setUser(UserInfo user) {
		this.user = user;
	}
	

	public BasketMessages(ResponseStatus status, List<CartListView> entities) {
		super();
		this.status = status;
		this.entities = entities;
	}

	public BasketMessages(ResponseStatus status) {
		super();
		this.status = status;
	}

	public BasketMessages(ResponseStatus status, CartTotal cartAmountInfo, List<CartListView> entities) {
		super();
		this.status = status;
		this.cartAmountInfo = cartAmountInfo;
		this.entities = entities;
		
	}

	public BasketMessages(ResponseStatus status, List<CartListView> entities, CartTotal cartAmountInfo, UserInfo user) {
		super();
		this.status = status;
		this.entities = entities;
		this.cartAmountInfo = cartAmountInfo;
		this.user = user;
	}
	





}
