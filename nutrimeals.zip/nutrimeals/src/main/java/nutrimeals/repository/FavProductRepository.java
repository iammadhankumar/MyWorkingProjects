package nutrimeals.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import nutrimeals.domain.FavProduct;


public interface FavProductRepository extends CrudRepository<FavProduct,Long> {

	@Query(value="SELECT * FROM `tbl_favourite` WHERE `DC_PRODUCTID`=:id AND `DN_USERID`=:userId",nativeQuery=true)
	FavProduct getByProductandUserId(@Param("id") long id, @Param("userId") long userId);

	@Query(value="SELECT COUNT(*) FROM `tbl_favourite` WHERE `DN_USERID`=:userId and `DC_ACTIVE`=:t",nativeQuery=true)
	long getFavProductListsByUserAndActive(@Param("userId") long userId,@Param("t")  boolean t);

	@Query(value="select CONVERT(DC_PRODUCTID,CHAR) from tbl_favourite where DC_ACTIVE =:b and DN_USERID=:userId",nativeQuery=true)
	List<String> getFavProductListByUser(@Param("userId") long userId,@Param("b")  boolean b);

	


}
