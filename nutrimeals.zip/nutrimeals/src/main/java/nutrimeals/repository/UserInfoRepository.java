package nutrimeals.repository;

import org.springframework.data.repository.CrudRepository;

import nutrimeals.domain.UserInfo;


public interface UserInfoRepository   extends CrudRepository<UserInfo, Long> {
	
}
