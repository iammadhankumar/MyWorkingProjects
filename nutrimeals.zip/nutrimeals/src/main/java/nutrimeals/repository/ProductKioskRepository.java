package nutrimeals.repository;


import org.springframework.data.repository.CrudRepository;

import nutrimeals.domain.ProductKiosk;

public interface ProductKioskRepository extends CrudRepository<ProductKiosk, Long> {

//	@Query("FROM ProductKiosk WHERE kiosk.id=:kid AND product.id=:pid")
//	ProductKiosk getByProductAndKioskId(@Param("pid") long pid, @Param("kid") long kid);
	
	//SELECT * FROM `tbl_product_kiosk` WHERE `DN_KIOSK_ID`=1 AND `DN_PRODUCT`=7

}
