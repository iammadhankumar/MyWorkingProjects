package nutrimeals.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import nutrimeals.domain.Basket;




public interface BasketRepository extends CrudRepository<Basket, Long>{

	@Query(value="SELECT SUM(`DN_PRICE`) FROM `tbl_basket` WHERE `DN_USER_ID` =:userId AND `DB_ACTIVE`=1 AND `DN_PURCHASE`=0",nativeQuery=true)
	Float getSumOfBaskets(@Param("userId") long userId);






	
	

}
