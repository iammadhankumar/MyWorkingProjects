package nutrimeals.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import nutrimeals.domain.ContentManagement;

public interface ContentManagementRepository extends CrudRepository<ContentManagement, Long>{

	Optional<ContentManagement> findBycontentId(long contentId);





}
