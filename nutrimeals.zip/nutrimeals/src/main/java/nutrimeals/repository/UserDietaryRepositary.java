package nutrimeals.repository;

import org.springframework.data.repository.CrudRepository;

import nutrimeals.domain.UserDietaryPreference;

public interface UserDietaryRepositary extends CrudRepository<UserDietaryPreference, Long>{




}
