package nutrimeals.repository;

import org.springframework.data.repository.CrudRepository;

import nutrimeals.domain.BasketStatus;

public interface BasketStatusRepository  extends CrudRepository<BasketStatus, Long> {

	BasketStatus getBybasketStatusId(long id);

}
