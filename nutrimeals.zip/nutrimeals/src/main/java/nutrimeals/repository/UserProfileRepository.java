package nutrimeals.repository;

import org.springframework.data.repository.CrudRepository;

import nutrimeals.domain.UserProfile;

public interface UserProfileRepository  extends CrudRepository<UserProfile, Long> {

	UserProfile getUserProfileByCreditCardNumberOrSecurityCode(String creditCardNumber, String securityCode);

	//UserProfile getById(long upId);



	











}
