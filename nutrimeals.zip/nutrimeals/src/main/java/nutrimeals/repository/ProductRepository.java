package nutrimeals.repository;



import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import nutrimeals.domain.Product;



public interface ProductRepository  extends CrudRepository<Product,Long> {



	@Query(value="SELECT COUNT(*) FROM `tbl_products`",nativeQuery=true)
	long countById();

	Product getById(long id);

	long countByproductNameContaining(String searchValue);

	

	

	//long getallproductlistcount();

	


	
	

}
