package nutrimeals.repository;

import org.springframework.data.repository.CrudRepository;

import nutrimeals.domain.DietaryPreference;

public interface DietaryPreferenceRepository extends CrudRepository<DietaryPreference,Long> {

	DietaryPreference getDeitaryByDietaryIdAndActive(long dietaryId, boolean b);
}
