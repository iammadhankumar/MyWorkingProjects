package nutrimeals.repository;

import org.springframework.data.repository.CrudRepository;

import nutrimeals.domain.RewardsMaintain;

public interface RewardsMaintainRepository extends CrudRepository<RewardsMaintain, Long> {

}
