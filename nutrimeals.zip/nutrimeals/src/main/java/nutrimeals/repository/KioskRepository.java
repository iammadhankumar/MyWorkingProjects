package nutrimeals.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import nutrimeals.domain.Kiosk;



public interface KioskRepository extends CrudRepository<Kiosk,Long> {

	Kiosk getById(long kioskId);
    
	@Query("select kiosk from Kiosk kiosk where id=:kioskId and active=1")
	Kiosk getByKioskId(@Param("kioskId") long kioskId);
	
	@Query("select count(k) from Kiosk k where id in (select kiosk.id from ProductKiosk where product.id=:pid) and active=1")
	long getByProductAndActive(@Param("pid") long pid);



}
