package nutrimeals.repository;

import org.springframework.data.repository.CrudRepository;

import nutrimeals.domain.RewardsPurchaseInfo;




	public interface RewardPurchaseRepository extends CrudRepository<RewardsPurchaseInfo, Long> {


}
