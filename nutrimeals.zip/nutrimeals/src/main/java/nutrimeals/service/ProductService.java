package nutrimeals.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import nutrimeals.dao.IProductDAO;
import nutrimeals.domain.DietaryPreference;
import nutrimeals.domain.FavProduct;
import nutrimeals.domain.Product;
import nutrimeals.domain.ProductKiosk;
import nutrimeals.views.ProductView;

@Service("IProductService")
public class ProductService implements IProductService {

	@Autowired
	IProductDAO productDao;

	@Override
	public long getAllDietaryPreferenceListCount() {
		return productDao.getAllDietaryPreferenceListCount();
	}

	@Override
	public List<DietaryPreference> getAllDietaryPreferenceList(int pagenumber, int pagerecord) {
		return productDao.getAllDietaryPreferenceList(pagenumber, pagerecord);
	}


	@Override
	public List<Product> getAllProductList(int pagenumber,int pagerecord) {		
		return productDao.getAllProductList(pagenumber,pagerecord);
	}
	
	@Override
	public List<Product> searchProductList(String searchValue,long categoryId,long l, int pagenumber, int pagerecord) {
		return productDao.searchProductList(searchValue,categoryId, l,pagenumber, pagerecord);
	}
	
	@Override
	public List<FavProduct> getAllFavProductList(long userid,int pagenumber, int pagerecord) {

		return productDao.getAllFavProductList(userid,pagenumber, pagerecord);
	}
	
	@Override
	public Product getProductById(long pid) {

		return productDao.getProductById(pid);
	}
	
	@Override
	public List<Product> getProductsByCategory(long categoryId,int pagenumber, int pagerecord) {

		return productDao.getProductsByCategory(categoryId,pagenumber, pagerecord);
	}

	@Override
	public long getProductCountByCategory(long categoryId) {
		return productDao.getProductCountByCategory(categoryId);
	}

	@Override
	public List<ProductView> getAllProductByKiosk(long kid,String searchValue,long categoryId,int pagenumber,int pagerecord) {
		return productDao.getAllProductByKiosk(kid,searchValue,categoryId,pagenumber,pagerecord);
	}

	@Override
	public long getAllProductCountByKiosk(long kid,String searchValue,long categoryId) {
		return productDao.getAllProductCountByKiosk(kid,searchValue,categoryId);
	}

	@Override
	public long searchProductListCount(String searchValue, long kid) {

		return 0;
	}

	@Override
	public ProductKiosk getQuantityByKiosk(long kid, long pid) {
		return productDao.getQuantityByKiosk(kid,pid);
	}


	




	


	
}