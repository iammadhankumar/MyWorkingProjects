package nutrimeals.service;

import java.util.List;

import nutrimeals.domain.DietaryPreference;
import nutrimeals.domain.UserInfo;
import nutrimeals.domain.UserProfile;
import nutrimeals.domain.UserType;

public interface IUserInfoService {
	
	public long registerNewUser(UserInfo userObj);
	
	public UserInfo getUserByEmail(String email);
	
	public UserInfo getUserById(long  userId);
	
	public UserType getUserTypeById(long  userTypeId);
	
	public List<DietaryPreference> getDeitaryById(List<DietaryPreference> list);
	
	public long registerNewUserProfile(UserProfile userProfileObj);
	
	public void updateUser(UserInfo user);


}
