package nutrimeals.service;

import java.util.List;

import nutrimeals.domain.ContentManagement;


public interface IContentManagementService {

	List<ContentManagement> getAllContentManagement();
	
	//ContentManagement getContentManagementByContentType(int label);

	ContentManagement getContentManagementByContentType(String label);
}
