package nutrimeals.service;

import nutrimeals.domain.ContentInfo;

public interface IContentInfoService {

	public  ContentInfo getSunboxInfo();

	public ContentInfo getPrivacyPolicyInfo();

	public ContentInfo getTermsInfo();

	public void update(ContentInfo contentInfo);

}
