package nutrimeals.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import nutrimeals.dao.IVerificationDAO;
import nutrimeals.domain.VerificationCode;

@Service("IVerificationService")
public class VerificationService implements IVerificationService {
 
	
	
	@Autowired
	IVerificationDAO VerificationDAO; 
	
	
	@Override
	public long save(VerificationCode verificationcode) {

		return VerificationDAO.save(verificationcode);
	}
	
	@Override
	public void update(VerificationCode verificationcode) {
		VerificationDAO.update(verificationcode);
	}


	@Override
	public VerificationCode getVerificationByverificationId(long id) {
		return VerificationDAO.getVerificationByverificationId(id);
	}
	
	@Override
	public VerificationCode getVerificationByverificationCode(String code,long userId) {
		return VerificationDAO.getVerificationByverificationCode(code,userId);
	}
	
	@Override
	public List<VerificationCode> getVerificationListByUserId(long userId){
		return VerificationDAO.getVerificationListByUserId(userId);
	}
	


}
