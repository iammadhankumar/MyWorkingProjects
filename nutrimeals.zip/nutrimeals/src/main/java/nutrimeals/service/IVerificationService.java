package nutrimeals.service;

import java.util.List;

import nutrimeals.domain.VerificationCode;

public interface IVerificationService {

	public long save(VerificationCode verificationcode);
	
	public void update(VerificationCode verificationcode);

	public VerificationCode getVerificationByverificationId(long id);
	
	public VerificationCode getVerificationByverificationCode(String code,long userId);

	public List<VerificationCode> getVerificationListByUserId(long userId);
}
