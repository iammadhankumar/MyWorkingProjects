package nutrimeals.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import nutrimeals.dao.IContentManagementDAO;
import nutrimeals.domain.ContentManagement;


@Service
public class ContentManagementService implements IContentManagementService {

	@Autowired
	IContentManagementDAO contentManagementDAO;

	@Override
	public List<ContentManagement> getAllContentManagement() {
		return contentManagementDAO.getAllContentManagement();
	}

	@Override
	public ContentManagement getContentManagementByContentType(String label ) {
		return contentManagementDAO.getContentManagementByContentType(label);
	}

	
	
	
}
