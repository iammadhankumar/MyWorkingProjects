package nutrimeals.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import nutrimeals.dao.IContentInfoDAO;
import nutrimeals.domain.ContentInfo;

@Service("IContentInfoService")
public class ContentInfoService implements IContentInfoService {

	 @Autowired
	IContentInfoDAO contentInfoDAO;

	@Override
	public ContentInfo getSunboxInfo() {	
		return contentInfoDAO.getSunboxInfo();
	}

	@Override
	public ContentInfo getPrivacyPolicyInfo() {		
		return contentInfoDAO.getPrivacyPolicyInfo();
	}

	@Override
	public ContentInfo getTermsInfo() {		
		return contentInfoDAO.getTermsInfo();
	}

	@Override
	public void update(ContentInfo contentInfo) {		
		contentInfoDAO.update(contentInfo);
	}
}