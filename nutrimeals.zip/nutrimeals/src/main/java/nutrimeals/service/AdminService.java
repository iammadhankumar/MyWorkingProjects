package nutrimeals.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import nutrimeals.dao.IAdminDAO;
import nutrimeals.domain.Rewards;
import nutrimeals.domain.RewardsMaintain;
import nutrimeals.domain.ScrollingContent;




@Service("IAdminService")
public class AdminService implements IAdminService {
	
	@Autowired
	IAdminDAO adminDao; 
	
	@Override
	public long registerRewardInfo(Rewards reward)
	{
		 return adminDao.registerRewardInfo(reward);
	}
	
	@Override
	public void updateRewards(Rewards reward) {
      
		adminDao.updateRewards(reward);
		
	}

	@Override
	public long registerRewardsInfoByUser(RewardsMaintain rewardsMaintain)
	{
		return adminDao.registerRewardsInfoByUser(rewardsMaintain);
	}

	@Override
	public void removeRewards(long rewardId) {
		
		adminDao.removeRewards(rewardId);
	}
	
	@Override
	public void deleteRewards(long userId)
	{
		adminDao.deleteRewards(userId);
	}
	
	@Override
	public RewardsMaintain getRewardsMaintainByUser(long rewardId,long userId)
	{
		return adminDao.getRewardsMaintainByUser(rewardId, userId);
	}
	
	@Override
	public List<Rewards> getRewardsList(long userId,int pagenumber,int pagerecord)
	{
		return adminDao.getRewardsList(userId,pagenumber, pagerecord);
	}
	
	public List<Rewards> getAllRewardsList(long userId)
	{
		return adminDao.getAllRewardsList(userId);
	}

	@Override
	public long registerScrollingContentInfo(ScrollingContent scrollingContent) {

		return adminDao.registerScrollingContentInfo(scrollingContent) ;
	}
	
	@Override
	public List<ScrollingContent> getAllScrollingContentList()
	{
		return adminDao.getAllScrollingContentList();
	}
	
	@Override
	public List<ScrollingContent> getScrollingContentList(int pagenumber,int pagerecord)
	{
		return adminDao.getScrollingContentList(pagenumber,pagerecord);
	}
	
	@Override
	public Rewards getRewardByPromoCode(String code)
	{
		return adminDao.getRewardByPromoCode(code);
	}

	
	@Override
	public Rewards getRewardById(long id)
	{
		return adminDao.getRewardById(id);
	}

	@Override
	public RewardsMaintain getUsedRewardById(long id,long userId) {

		return adminDao.getUsedRewardById(id,userId);
	}

	@Override
	public List<Rewards> getRewardsListByPromocode(String promocode) {

		return adminDao.getRewardsListByPromocode(promocode);
	}

	@Override
	public List<Rewards> getOverAllRewardsList(int pagenumber, int pagerecord) {

		return adminDao.getOverAllRewardsList(pagenumber,pagerecord);
	}

	@Override
	public long getOverAllRewardsListCount() {

		return adminDao.getOverAllRewardsListCount();
	}

	@Override
	public Rewards getRewardByName(String rewardName) {

		return adminDao.getRewardByName(rewardName);
	}

	@Override
	public List<Rewards> getRewardList() {
		return adminDao.getRewardList();	}

	@Override
	public List<Rewards> getallRewardsListWithOutActiveCheck(int pagenumber, int pagerecord) {
		return adminDao.getallRewardsListWithOutActiveCheck(pagenumber,pagerecord);
	}

	@Override
	public Rewards getRewardByIdWithoutActiveCheck(long id) {
		return adminDao.getRewardByIdWithoutActiveCheck(id);
	}







}
