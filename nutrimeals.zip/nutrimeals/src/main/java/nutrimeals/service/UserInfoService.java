package nutrimeals.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import nutrimeals.dao.IUserInfoDAO;
import nutrimeals.domain.DietaryPreference;
import nutrimeals.domain.UserInfo;
import nutrimeals.domain.UserProfile;
import nutrimeals.domain.UserType;

@Service("IUserInfoService")
public class UserInfoService implements IUserInfoService {
	
	@Autowired
	IUserInfoDAO userInfoDao;

	@Override
	public long registerNewUser(UserInfo userObj) {

		return userInfoDao.registerNewUser(userObj);
	}

	@Override
	public UserInfo getUserByEmail(String email) {

		return userInfoDao.getUserByEmail(email);
	}

	@Override
	public UserInfo getUserById(long userId) {
		return userInfoDao.getUserById(userId);
	}

	@Override
	public UserType getUserTypeById(long userTypeId) {
		return userInfoDao.getUserTypeById(userTypeId);
	}

	@Override
	public List<DietaryPreference> getDeitaryById(List<DietaryPreference> id) {

		return userInfoDao.getDeitaryById(id);
	}

	@Override
	public long registerNewUserProfile(UserProfile userProfileObj) {

		return userInfoDao.registerNewUserProfile(userProfileObj);
	}

	public List<UserInfo> getAllUsersByStatus(int stat) {
		return userInfoDao.getAllUsersByStatus(stat);
	}

	public UserInfo getUserByIdWithoutActiveCheck(long user_id) {
		return userInfoDao.getUserByIdWithoutActiveCheck(user_id);
	}

	@Override
	public void updateUser(UserInfo user) {
		userInfoDao.updateUser(user); 		
	}

}
