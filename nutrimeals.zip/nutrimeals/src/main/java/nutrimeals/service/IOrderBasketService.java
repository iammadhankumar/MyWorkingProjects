package nutrimeals.service;

import nutrimeals.domain.OrderBasket;

public interface IOrderBasketService {

	public long  registerNewOrder(OrderBasket orderBasketObj);

}
