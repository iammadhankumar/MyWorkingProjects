package nutrimeals.service;

import java.util.List;

import nutrimeals.domain.Kiosk;
import nutrimeals.domain.ProductKiosk;
import nutrimeals.views.KioskView;

public interface IKioskService {

	public long registerKioskDetails(Kiosk kioskObj);	 

	public void updateKiosk(Kiosk kiosk);

	public List<Kiosk> getAllKioskDetails();	 

	public List<Kiosk> getAllSearchKioskDetails(String searchValue);

	public Kiosk getKioskById(long kiosk_id);

	public List<KioskView> getAllKioskMap( double latitude,	double longitude,int pagenumber,int pagerecord);
	
	public long getAllKioskMapCount(double latitude, double longitude);

	public List<KioskView> getAllKioskList(int all, int sortColumn, String sortType, int pagenumber, int pagerecord);

	public List<Kiosk> getKioskLocationDetail(long kiosk_id);

	public void deleteKiosk(long kiosk_id);

	public List<Kiosk> getAllKioskListByActions();

	public Kiosk getKioskByKioskId(long id);

	public Kiosk getKioskByKioskIdAction(long id);

	public Kiosk getKioskByIdWithoutAction(long kiosk_id);
	
	public Kiosk getKioskId(long kioskId);
	
    public Kiosk getKioskName(String kioskName);
    
    public Kiosk getKioskBypId(long product_id);
    
    public ProductKiosk getKioskByProductKioskId(long productkioskid);
    
	public List<Kiosk> getAllKioskListByKioskId(long kid);
	
	 public List<Kiosk> getAllKioskListUsingKioskId (List<Long> pkObj);

	public List<Kiosk> getAllKioskByProduct(long pid, int pagenumber, int pagerecord);

	public Kiosk getKioskByIdWithoutActiveCheck(long kioskId);


	


    
   // public List<Long> getKioskBypId(long product_id);
    
	//public List<Kiosk> getKioskBypId(long product_id);


	

//	public Kiosk getKioskByProductKioskId(long productkiosk_id);
}