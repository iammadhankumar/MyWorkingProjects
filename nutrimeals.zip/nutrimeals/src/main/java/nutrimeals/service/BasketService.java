package nutrimeals.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import nutrimeals.dao.IBasketDAO;
import nutrimeals.domain.Basket;
import nutrimeals.domain.BasketStatus;
import nutrimeals.domain.Kiosk;
import nutrimeals.views.CartListView;


@Service
public class BasketService implements IBasketService {

	@Autowired
	IBasketDAO basketDAO;
	
	@Override
	public Long registerNewToBasket(Basket Basket) {

		return basketDAO.registerNewToBasket(Basket);
	}
	
	
	@Override
	public List<Basket> getBasket() {		
		return basketDAO.getBasket();
	}
	



	@Override
	public void delete(long bid) {
		basketDAO.delete(bid);
	}


	@Override
	public Basket getBid(Long bid) {

		return basketDAO.getBid(bid);
	}
	public Basket getProductkioskAndUser(long productkiosk_id, long user_id) {
		return basketDAO.getProductkioskAndUser(productkiosk_id,user_id);
		
	}

	@Override
	public Basket getBasketByBid(long bid)
	{
		return basketDAO.getBasketByBid(bid);
	}

	@Override
	public void updateBasket(Basket basket) {
		basketDAO.updateBasket(basket);
	}


	@Override
	public long getBasketByIdandPurchaseCount(long userId, boolean b) {
		return basketDAO.getBasketByIdandPurchaseCount(userId,b);
	}


	@Override
	public List<Basket> getpaypalid(long paypalId) {

		return basketDAO.getpaypalid(paypalId);
	}


	@Override
	public BasketStatus setBasketStatus(long id) {

		return basketDAO.setBasketStatus(id);
	}


	@Override
	public List<Basket> getBasketByIdandPurchaseandstatus(long userId, long basketStatusId, boolean purchase) {

		return basketDAO.getBasketByIdandPurchaseandstatus(userId,basketStatusId,purchase);
	}
	
	@Override
	public void updateBasketQuantity(long quantity,long pid)
	{
		basketDAO.updateBasketQuantity(quantity,pid);
	}



	


	@Override
	public List<Basket> getAllBasketByStatus(long basketstatusId) {

		return basketDAO.getAllBasketByStatus(basketstatusId);
	}


	@Override
	public Basket getBasket(long userId) {
		return basketDAO.getBasket(userId);
	}


	@Override
	public List<Basket> getBasketlist(long user_id,int pagenumber,int pagerecord) {
		return basketDAO.getBasketlist(user_id,pagenumber,pagerecord);
	}


	@Override
	public List<CartListView> getBasketlistByUserid(long user_id) {
		return basketDAO.getBasketlistByUserid(user_id);
	}
	
	@Override
	public List<Basket> getBasketByrewardsCheck(long user_id)
	{
		return basketDAO.getBasketByrewardsCheck(user_id);
	}


@Override
	public List<Basket> getBasketBypaypalid(long paypalId) {
	return basketDAO.getBasketBypaypalid(paypalId);
	}


@Override
public List<Basket> getBasketByIdandPurchase(Long userId, boolean purchase) {
	return basketDAO.getBasketByIdandPurchase(userId,purchase);
}



@Override
public long getBasketCount(long user_id) {
	return basketDAO.getBasketCount(user_id);
}





	@Override
	public Kiosk getKioskbyProduct(long pid)
	{
		return basketDAO.getKioskbyProduct(pid);
	}


	@Override
	public List<Basket> getbasketforkioskcheck(long userId) {
		return basketDAO.getbasketforkioskcheck(userId);
	}

	@Override
	public Basket getQuantityOfBasketProduct(long user_id)
	{
		return basketDAO.getQuantityOfBasketProduct(user_id);
	}

	@Override
	public Basket getKioskByBasketProductKioskId(long productKioskId)
	{
		return basketDAO.getKioskByBasketProductKioskId(productKioskId);
	}
	
	@Override
	public Basket getProductKioskUser(long productKioskId)
	{
		return basketDAO.getProductKioskUser(productKioskId);
	}
	
	@Override
	public Basket getProductKioskByUser(long userId)
	{
		return basketDAO.getProductKioskByUser(userId);
	}


	@Override
	public List<Basket> getBasketlistByUseridwithpagination(long user_id, int pagenumber, int pagerecord) {
		return basketDAO.getBasketlistByUseridwithpagination(user_id,pagenumber,pagerecord);
	}


	@Override
	public Basket getbyproductkioskid(long id) {
		return basketDAO.getbyproductkioskid(id);
	}


	@Override
	public Basket getbasketbyproductkioskidanduserid(long id, long userId) {
		return basketDAO.getbasketbyproductkioskidanduserid(id,userId);
	}
	
	@Override
	public List<Basket> getBasketInfo(long userId)
	{
		return basketDAO.getBasketInfo(userId);
	}
	
	@Override
	public Basket getbasketbyCartDetails(long pid,long userId)
	{
		return basketDAO.getbasketbyCartDetails(pid,userId);
	}
	
	@Override
	public void UpdateBasketActive(long bid)
	{
		basketDAO.UpdateBasketActive(bid);
	}
	
	@Override
	public List<Basket> getBasketbyRewardPurchase(List<Long> bid,long userId)
	{
		return basketDAO.getBasketbyRewardPurchase(bid,userId);
	}
	
	@Override
	public List<Basket> getBasketbyList(List<Long> bid)
	{
		return basketDAO.getBasketbyList(bid);
	}
	
	@Override
	public Basket getbasketDetailsbypid(long pid,long userId)
	{
		return basketDAO.getbasketDetailsbypid(pid, userId);
	}
	
	@Override
	public Basket getBasketId(long bid)
	{
		return basketDAO.getBasketId(bid);
	}
	
	@Override
	public List<Basket> getBasketByRewards(List<Long> bid)
	{
		return basketDAO.getBasketByRewards(bid);
	}
	
	@Override
	public Basket getBasketByRewardsCheck(long bid)
	{
		return basketDAO.getBasketByRewardsCheck(bid);
	}


	@Override
	public List<Basket> getBasketbyListCheck(List<Long> bid, long userId) {
		return basketDAO.getBasketbyListCheck(bid,userId);
	}


	@Override
	public List<Basket> getBasketByUser(long userId, List<Long> bid) {
		return basketDAO.getBasketByUser(userId, bid);
	}


	@Override
	public List<Basket> getBasketListByUser(long userId) {
		return basketDAO.getBasketListByUser(userId);
	}


	@Override
	public Basket getBasketByProductKioskAndUser(long id, long userId) {
		return basketDAO.getBasketByProductKioskAndUser(id,userId);
	}


	@Override
	public long getcountofBasketlistByUserid(long user_id) {
		return 0;
	}


	@Override
	public boolean getBasketByProductKioskandUser(long id, long userId) {
		return basketDAO.getBasketByProductKioskandUser(id,userId);
	}


	@Override
	public double getSumOfBasketPrice(long userId) {
		return basketDAO.getSumOfBasketPrice(userId);
	}


	@Override
	public long getBasketCountByQuantity(long userId) {
		return basketDAO.getBasketCountByQuantity(userId);
	}


	@Override
	public Basket getBasketByBasketIdandUser(long bid, long userId) {
		return basketDAO.getBasketByBasketIdandUser(bid,userId);
	}


	@Override
	public void updaterewardsInBasket(long userId) {
		 basketDAO.updaterewardsInBasket(userId);
		
	}


	@Override
	public void removeRewards(long userId) {
		 basketDAO.removeRewards(userId);
		
	}


	@Override
	public double getSumOfBaskets(long userId) {
		return basketDAO.getSumOfBaskets(userId);
	}


	@Override
	public Basket getBasketByProductKiosk(long pkid) {
		return basketDAO.getBasketByProductKiosk(pkid);
	}

}
