package nutrimeals.validation;

import java.text.ParseException;
import java.util.List;
import java.util.regex.Pattern;

import nutrimeals.domain.DietaryPreference;

public class UserInfoValidation 
{
	public static String checkUserInfoFieldsEmpty(String firstName,String lastName, String email,String password, boolean b,long userType,List<DietaryPreference> dp,long kioskid,String foodAllergies,String dob) throws ParseException
	{
	
		
		
		if(firstName==null || firstName.isEmpty())
		{
			return "Firstname Required";
		}
		
		if(lastName==null || lastName.isEmpty())
		{
			return "Lastname Required";
		}
		
		if(email==null || email.isEmpty())
		{
			return "email Required";
		}
		
		
		if(password==null || password.isEmpty())
		{
			return "password Required";
		}
		
		if(dp==null || dp.isEmpty())
		{
			return "Please Choose Your Dietary Preference";
		}
		
		if(kioskid<=0)
		{
			return "Primary Location id Required";
		}
		
		if(foodAllergies==null || foodAllergies.isEmpty())
		{
			return "foodAllergies Required";
		}
		
		if(b==false)
		{
			return "Accept Terms And Conditions";
		}
		
		if(userType<=0)
		{
			return "UserType Required";
		}
		
		if(dob==null || dob.isEmpty())
		{
			return "Date Of Birth Required";
		}
		
		if(DateValidation.pastDateStringValidation(dob))
		{
			return "Future Date Can't be acceptable";
		}
				
		
		
		
	
		
		return "Success";
		
	}
	
	public static String checkUserProfileFieldsEmpty(String primaryLocation,List<DietaryPreference> userDietary,String foodAllergies,boolean locationService,String creditCardName,String creditCardNumber,String zipCode,String securityCode)
	{
		

		
		
	     if(primaryLocation==null || primaryLocation.isEmpty())
	     {
	    	 return "Primary Location Required";
	     }
	     
	     if(userDietary==null || userDietary.isEmpty())
	     {
	    	 return "userDietary Required";
	     }
	     
	     if(foodAllergies==null || foodAllergies.isEmpty())
	     {
	    	 return "foodAllergies Required";
	     }
	     
	     if(String.valueOf(locationService)==null) {
	    	 return "Choose location Service";
	     }
	     
	     if(creditCardNumber==null || creditCardNumber.isEmpty())
	     {
	    	 return "creditCardNumber Required";
	     }
	     
	     if(zipCode==null || zipCode.isEmpty())
	     {
	    	 return "Zipcode Required";
	     }
	     
	     if(securityCode==null || securityCode.isEmpty())
	     {
	    	 return "securityCode Required";
	     }
	     
	     return "Success";
	}
	

			
	public static boolean isNumber(String creditCardNumber) {
		
		Pattern pattern = Pattern.compile("(((\\(?\\+?[0-9]*\\)?)?[0-9_\\- \\(\\)]*$))");
		return pattern.matcher(creditCardNumber).matches();
	}
	
	public static boolean isAlphaNumericCheck(String zipcode) {
		
		Pattern pattern = Pattern.compile("(?!^[0-9]*$)(?!^[a-zA-Z]*$)^([a-zA-Z0-9]{6,15})$");
		return pattern.matcher(zipcode).matches();
	}
		
	
	public static boolean isAlphaNumeric(String password) {
		
		Pattern pattern = Pattern.compile("((?=.*[0-9])(?=.*[!?@#$%^&*()._-]).{8,})");
		return pattern.matcher(password).matches();
	}
		
	public static boolean isEmailFormat(String email) {
	 
  Pattern pattern = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
	return pattern.matcher(email).matches();
	
}

}
