package nutrimeals.validation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;

public class DateValidation {

	
    public static boolean pastDateValidation(Date date)
    {
        if(date != null)
        {
            
        Instant givenInstant = date.toInstant();
        Instant currentdate = Instant.now();
        return currentdate.isBefore(givenInstant)?true:false;
      //  return currentdate.is(givenInstant)?true:false;
        }
        return false;
    }
    
    
    public static boolean pastDateStringValidation(String dateString) throws ParseException
    {
    	 Date date=new SimpleDateFormat("dd-MM-yyyy").parse(dateString);  
        if(date != null)
        {
            
        Instant givenInstant = date.toInstant();
        Instant currentdate = Instant.now();
        return currentdate.isBefore(givenInstant)?true:false;
      //  return currentdate.is(givenInstant)?true:false;
        }
        return false;
    }
    
    
    public static boolean intervalDateValidation(Date date)
    {
        if(date != null)
        {
        	
        Instant givenInstant = date.toInstant();
        Instant currentdate = Instant.now();

        return currentdate.isBefore(givenInstant)?true:false;

        }
        return false;
    }
    
    
    
}
