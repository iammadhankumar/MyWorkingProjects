package nutrimeals.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="tbl_basket_status")
public class BasketStatus {
	

@Id
@GeneratedValue(strategy=GenerationType.AUTO)
@Column(name="DN_ID",nullable=false)
private long basketStatusId;

@Column(name="DC_BASKETSTATUS")
private  String status;

public Long getBasketStatusId() {
		return basketStatusId;
	}

	public void setBasketStatusId(Long basketStatusId) {
		this.basketStatusId = basketStatusId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setBasketStatusId(long basketStatusId) {
		this.basketStatusId = basketStatusId;
	}
	
	
	

}
