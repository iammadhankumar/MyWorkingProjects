package nutrimeals.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="user_dietary_map")
public class UserDietaryPreference {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long id;
	

//	@Column(name="DN_PROFILE_ID" , nullable = false )
//	private long userProfile;
	
	@ManyToOne ( targetEntity = DietaryPreference.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_DIETARY_ID")
	 private DietaryPreference dietaryPreference;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}


	public DietaryPreference getDietaryPreference() {
		return dietaryPreference;
	}

	

//	public long getUserProfile() {
//		return userProfile;
//	}
//
//	public void setUserProfile(long userProfile) {
//		this.userProfile = userProfile;
//	}

	public void setDietaryPreference(DietaryPreference dietaryPreference) {
		this.dietaryPreference = dietaryPreference;
	}
	
	

}
