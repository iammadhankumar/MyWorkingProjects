package nutrimeals.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_product_type")
public class ProductType {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_TYPE_ID" , nullable = false )
	private long id;




@Column(name="DC_TYPE_NAME")
private  String productTypeName;



//@Column(name="DC_TYPE_IMAGE" )
//private String productTypeImage;

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}






//public String getProductTypeImage() {
//	return productTypeImage;
//}
//
//public void setProductTypeImage(String productTypeImage) {
//	this.productTypeImage = productTypeImage;
//}
//

public String getProductTypeName() {
	return productTypeName;
}

public void setProductTypeName(String productTypeName) {
	this.productTypeName = productTypeName;
}

//@ManyToOne(fetch=FetchType.LAZY)
//@JoinColumn(name = "DN_PRODUCT_TYPE_ID")
//private ProductType productType;




}
