package nutrimeals.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Size;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="tbl_kiosk")
public class Kiosk implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long id;
	



	public long getId() {
		return id;
	}



	public void setId(long id) {
		this.id = id;
	}

	@Column(name="DN_KIOSKID" )
	private long kioskId;	
	
	@Column(name="DN_ACTIVE" )
	private boolean active;	

	@Size(min = 3, max = 80)
	@Column(name="DC_KIOSKNAME", nullable = false )
	private String kioskName;

	@Column(name="DD_CREATED_ON")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date created_on;
	
	@Transient
	private String miles;	
	
//	@OneToOne( targetEntity = Coordinate.class, fetch = FetchType.EAGER )
//	@JoinColumn (name = "DN_COORDINATE")
//	private Coordinate coordinate;
	

	@Column(name="DN_LATITUDE" )
	private double latitude;
	
	@Column(name="DN_LONGITUDE" )
	private double longitude;
	
	@Transient
	private HashMap<String,Double> coordinate;
	
	@Column(name="DN_START_TIME")
	@JsonFormat(pattern="HH:mm:ss")
	private Date start_time;
	
	@Column(name="DN_END_TIME")
	@JsonFormat(pattern="HH:mm:ss")
	private Date end_time;

	public Date getStart_time() {
		return start_time;
	}



	public void setStart_time(Date start_time) {
		this.start_time = start_time;
	}



	public Date getEnd_time() {
		return end_time;
	}



	public void setEnd_time(Date end_time) {
		this.end_time = end_time;
	}



	public HashMap<String, Double> getCoordinate() {
		return coordinate;
	}



	public void setCoordinate(HashMap<String, Double> coordinate) {
		this.coordinate = coordinate;
	}

	@Column(name="DN_ADDRESS")
	private String address;
	


	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}





	public long getKioskId() {
		return kioskId;
	}

	public void setKioskId(long kioskId) {
		this.kioskId = kioskId;
	}

	public String getKioskName() {
		return kioskName;
	}

	public void setKioskName(String kioskName) {
		this.kioskName = kioskName;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}
	
	@JsonIgnore
	@OneToMany(targetEntity = ProductKiosk.class,cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	@JoinColumn (name = "DN_KIOSK_ID")
	private List<ProductKiosk> productKiosk;

	
	
	public List<ProductKiosk> getProductKiosk() {
		return productKiosk;
	}



	public void setProductKiosk(List<ProductKiosk> productKiosk) {
		this.productKiosk = productKiosk;
	}



	public boolean isActive() {
		return active;
	}



	public void setActive(boolean active) {
		this.active = active;
	}

	
	public String getMiles() {
		return miles;
	}



	public void setMiles(String miles) {
		this.miles = miles;
	}




	}