package nutrimeals.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.fasterxml.jackson.annotation.JsonIgnore;




@Entity
@Table(name="tbl_products")
public class Product implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long id;
	
	@Column(name="PRODUCT_ID")
	private String productId;
	
	
	@Column(name="PRODUCT_NAME")
	private String productName;
	

	@Column(name="PRICE")
	private float price;

	


	@Column(name="DC_PREPARATION_METHOD",columnDefinition = "TEXT")
    private String preparationMethod;
	
	

	@Column(name="DC_ALL_INGREDIENTS",columnDefinition = "TEXT")
    private String allIngredients;


	@OneToOne(targetEntity =ProductType.class,fetch=FetchType.EAGER)
	@JoinColumn(name="DN_PRODUCT_TYPE")
	private ProductType productType;
    
	@Transient
    private boolean productFavourite;
	
	
  

    @OneToOne(targetEntity =Nutrition.class,fetch=FetchType.EAGER)
	@JoinColumn(name="DN_NUTRITION")
	private Nutrition nutrition;
   

	@JsonIgnore
	@OneToMany(targetEntity = ProductDietaryPreference.class,cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	@JoinColumn (name = "DN_PRODUCT_ID")
	private List<ProductDietaryPreference> productDietaryMap; 
	
	
	@Column(name="PRODUCT_DESCRIPTION",columnDefinition="text")
	private String productDescription;
	
	@Transient
	private long stockQuantity;
    


	public long getStockQuantity() {
		return stockQuantity;
	}

	public void setStockQuantity(long stockQuantity) {
		this.stockQuantity = stockQuantity;
	}

	public ProductType getProductType() {
		return productType;
	}

	public void setProductType(ProductType productType) {
		this.productType = productType;
	}

	@Column(name="PRODUCT_IMAGE")
	private String productImage;

 
	
	
	
	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	
	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	
	public String getPreparationMethod() {
		return preparationMethod;
	}

	public void setPreparationMethod(String preparationMethod) {
		this.preparationMethod = preparationMethod;
	}

	public String getAllIngredients() {
		return allIngredients;
	}

	public void setAllIngredients(String allIngredients) {
		this.allIngredients = allIngredients;
	}

	public Nutrition getNutrition() {
		return nutrition;
	}

	public void setNutrition(Nutrition nutrition) {
		this.nutrition = nutrition;
	}

	
	public boolean isProductFavourite() {
		return productFavourite;
	}

	public void setProductFavourite(boolean productFavourite) {
		this.productFavourite = productFavourite;
	}
	


	

}