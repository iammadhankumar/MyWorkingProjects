package nutrimeals.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="tbl_device_token")
public class DeviceToken {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long devicetoken_id;

	@Column(name="DC_DEVICE_TOKEN")
	private String deviceToken;
	
	@OneToOne ( targetEntity = User.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_USERID")
	private User user_id;
	
	
	@Column(name="DD_CREATED_ON")
	@JsonFormat(pattern="MM-dd-yyyy HH:mm:ss")
	private Date created_on;

	@Column(name="DB_ACTIVE")
	private boolean active;

	public long getDevicetoken_id() {
		return devicetoken_id;
	}

	public void setDevicetoken_id(long devicetoken_id) {
		this.devicetoken_id = devicetoken_id;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public User getUser_id() {
		return user_id;
	}

	public void setUser_id(User user_id) {
		this.user_id = user_id;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
	
	
}
