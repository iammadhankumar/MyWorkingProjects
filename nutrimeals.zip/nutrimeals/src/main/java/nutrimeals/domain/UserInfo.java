package nutrimeals.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="tbl_user_info")
public class UserInfo implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long userId;
	
	
	@Column(name="DN_ACTIVE")
	private boolean active;
	
	@Column(name="DD_CREATED_ON")
	@JsonFormat(pattern="MM-dd-yyyy HH:mm:ss")
	private Date created_on;


	@Column(name="DD_UPDATED_ON")
	@JsonFormat(pattern="MM-dd-yyyy HH:mm:ss")
	private Date updated_on;
	
	
	@Column(name="DN_DOB")
	private String dob;
	
	
	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	@Column(name="DN_FIRSTNAME")
	private String firstName;
	
	@Column(name="DN_LASTNAME")
	private String lastName;
	
	@Column(name="DN_EMAIL")
	private String email;
	
	@Column(name="DN_PASSWORD")
	private String password;
	
	@Column(name="DN_TERMS_AND_CONDITIONS")
	private boolean termsAndConditions;
	
	@Column(name="DN_SUBSCRIBE")
	private boolean subscribe;
	
	@Column(name="DN_PRIMARY_LOCATION")
	String primaryLocation;
	
	@Column(name="DN_FOOD_ALLERGIES")
	String foodAllergies;
	
	@OneToOne ( targetEntity = Kiosk.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_PRIMARY_LOCATION_PREFERENCE")
	private Kiosk primaryLocationPreference;
	
	
	public Kiosk getPrimaryLocationPreference() {
		return primaryLocationPreference;
	}

	public void setPrimaryLocationPreference(Kiosk primaryLocationPreference) {
		this.primaryLocationPreference = primaryLocationPreference;
	}

	@OneToOne ( targetEntity = UserType.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_USER_TYPE")
	private UserType userType;
	
	@JsonIgnore
	@OneToMany(targetEntity = UserDietaryPreference.class,cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	@JoinColumn (name = "DN_USER_ID")
	private List<UserDietaryPreference> userDietaryMap;

	public List<UserDietaryPreference> getUserDietaryMap() {
		return userDietaryMap;
	}

	public void setUserDietaryMap(List<UserDietaryPreference> userDietaryMap) {
		this.userDietaryMap = userDietaryMap;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}


	public Date getUpdated_on() {
		return updated_on;
	}

	public void setUpdated_on(Date updated_on) {
		this.updated_on = updated_on;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isTermsAndConditions() {
		return termsAndConditions;
	}

	public void setTermsAndConditions(boolean termsAndConditions) {
		this.termsAndConditions = termsAndConditions;
	}

	public boolean isSubscribe() {
		return subscribe;
	}

	public void setSubscribe(boolean subscribe) {
		this.subscribe = subscribe;
	}
	
	public UserType getUserType() {
		return userType;
	}

	public void setUserType(UserType userType) {
		this.userType = userType;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public String getFoodAllergies() {
		return foodAllergies;
	}

	public void setFoodAllergies(String foodAllergies) {
		this.foodAllergies = foodAllergies;
	}

	public String getPrimaryLocation() {
		return primaryLocation;
	}

	public void setPrimaryLocation(String primaryLocation) {
		this.primaryLocation = primaryLocation;
	}



	
//
//	public UserInfo() {
//		super();
//		this.userId = user.getUserId();
//		this.email = user.getEmail();
//		this.firstName =user.getFirstName();
//		this.lastName = user.getLastName(); 
//		this.password = user.getPassword();	
//		this.userType=user.getUserType();
//		this.termsAndConditions=termsAndConditions;
//		//this.profileimage=profileimage;
//		//this.latitude=latitude;
//	//	this.langitude=langitude;
//
//	}



}
