package nutrimeals.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="tbl_recentview_products")
public class RecentViewProducts {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long id;
	
	@Column(name="DN_ACTIVE")
	private boolean active;
	
	
	@Column(name="DD_CREATED_ON")
	@JsonFormat(pattern="MM-dd-yyyy HH:mm:ss")
	private Date created_on;
	
	@OneToOne(targetEntity =Product.class,fetch=FetchType.EAGER)
	@JoinColumn(name="DN_PRODUCT")
	private Product product;
	
	@OneToOne(targetEntity =User.class,fetch=FetchType.EAGER)
	@JoinColumn(name="DN_USER")
	private User user;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}
