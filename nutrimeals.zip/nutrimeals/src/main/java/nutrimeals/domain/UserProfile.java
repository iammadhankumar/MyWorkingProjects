package nutrimeals.domain;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Table(name="tbl_user_profile ")
public class UserProfile {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long profileId;
	
	@Column(name="DN_ACTIVE")
	private boolean active;

	@Column(name="DN_CREATED_ON")
	@JsonFormat(pattern="MM-dd-yyyy HH:mm:ss")
	private Date created_on;


	@Column(name="DN_UPDATED_ON")
	@JsonFormat(pattern="MM-dd-yyyy HH:mm:ss")
	private Date updated_on;
	
	@Column(name="DN_PRIMARY_LOCATION")
	private String primaryLocation;
	
//	@Transient 
//	@ManyToMany(cascade = CascadeType.ALL)
//	@LazyCollection(LazyCollectionOption.FALSE)
//	@JoinTable(name = "tbl_User_Dietary_Map", joinColumns = {
//	@JoinColumn(name = "DN_USER_ID") }, inverseJoinColumns = { @JoinColumn(name = "DN_DIETARY_ID") })
//	private List<DietaryPreference> userDietaryMap;
	
	
	@JsonIgnore
	@OneToMany(targetEntity = UserDietaryPreference.class,cascade = CascadeType.ALL)
	@LazyCollection(LazyCollectionOption.FALSE)
	@JoinColumn (name = "DN_DIETARY_ID")
	private List<UserDietaryPreference> userDietaryMap;
	

	@Column(name="DN_FOOD_ALLERGIES")
	String foodAllergies;
	
	@Column(name="DN_LOCATION_SERVICE")
	private boolean locationService;
	
	@Column(name="DN_CREDITCARD_NAME")
	private String creditCardName;
	
	@Column(name="DN_CREDITCARD_NUMBER")
	private String creditCardNumber;
	
	@Column(name="DN_ZIPCODE")
	private String zipCode;
	
	@Column(name="DN_CREDITCARD_SECURITY_CODE")
	private String securityCode;
	
	@OneToOne ( targetEntity = UserInfo.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_USER")
	private UserInfo user;

	public long getProfileId() {
		return profileId;
	}

	public void setProfileId(long profileId) {
		this.profileId = profileId;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}

	public Date getUpdated_on() {
		return updated_on;
	}

	public void setUpdated_on(Date updated_on) {
		this.updated_on = updated_on;
	}

	public String getPrimaryLocation() {
		return primaryLocation;
	}

	public void setPrimaryLocation(String primaryLocation) {
		this.primaryLocation = primaryLocation;
	}
	
	



public List<UserDietaryPreference> getUserDietaryMap() {
		return userDietaryMap;
	}

	public void setUserDietaryMap(List<UserDietaryPreference> userDietaryMap) {
		this.userDietaryMap = userDietaryMap;
	}

	//
//	public List<DietaryPreference> getUserDietaryMap() {
//		return userDietaryMap;
//	}
//
//	public void setUserDietaryMap(List<DietaryPreference> userDietaryMap) {
//		this.userDietaryMap = userDietaryMap;
//	}
//
	public String getFoodAllergies() {
		return foodAllergies;
	}

	public void setFoodAllergies(String foodAllergies) {
		this.foodAllergies = foodAllergies;
	}

	public boolean isLocationService() {
		return locationService;
	}

	public void setLocationService(boolean locationService) {
		this.locationService = locationService;
	}

	public String getCreditCardName() {
		return creditCardName;
	}

	public void setCreditCardName(String creditCardName) {
		this.creditCardName = creditCardName;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getSecurityCode() {
		return securityCode;
	}

	public void setSecurityCode(String securityCode) {
		this.securityCode = securityCode;
	}



	public UserInfo getUser() {
		return user;
	}

	public void setUser(UserInfo user) {
		this.user = user;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	

	
	

}
