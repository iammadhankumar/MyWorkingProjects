package nutrimeals.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

public class Reward implements Serializable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long id;
	
	@Column(name="DN_ACTIVE")
	private boolean active;
	
	@Column(name="DN_PROMO_CODE")
	private String promoCode;
	
	@OneToOne ( targetEntity = User.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_USER")
	private User user;
	


}
