package nutrimeals.domain;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.ws.rs.ext.ParamConverter.Lazy;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="tbl_basket")
@Lazy
public class Basket {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="BID" , nullable = false )
	private long bid;
	
	@Column(name="DN_QUANTITY")
	private long quantity;

	@JsonIgnore
	@OneToOne ( targetEntity = UserInfo.class, fetch = FetchType.EAGER )
	@JoinColumn (name ="DN_USER_ID")
	private UserInfo user;
	
	@Column(name="DD_CREATED_ON")
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date createdOn;

	@Column(name="DB_ACTIVE")
    private boolean active;

	@Column(name="DB_ACTIONS")
	private boolean actions;
	
	@Column(name="DN_PRICE")
	private float price;
	
    @Transient
	private float discountedPrice;
	
    @Transient
	private float rewardsPrice;


	@Column(name="DN_REWARDS_USED",columnDefinition = "BOOLEAN DEFAULT false")
	public boolean rewardsUsed;
	

	

	public boolean isRewardsUsed() {
		return rewardsUsed;
	}

	public void setRewardsUsed(boolean rewardsUsed) {
		this.rewardsUsed = rewardsUsed;
	}

	@OneToOne ( targetEntity = BasketStatus.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_BASKET_STATUS")
	private BasketStatus basketStatus;
	


	@OneToOne ( targetEntity = ProductKiosk.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_PRODUCTKIOSK")
	private ProductKiosk productKiosk;

	@Column(name="DN_PURCHASE",columnDefinition = "BOOLEAN DEFAULT false")
	private boolean purchase;
	
	@Transient
	private boolean instock;
	
	@OneToOne ( targetEntity = Rewards.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_REWARD")
	private Rewards reward;
	
//	@Column(name="DB_REWARDS_USED",columnDefinition = "BOOLEAN DEFAULT false")
//	private boolean rewardsUsed;
//	
//	@Column(name="DB_ACTUAL_PRICE")
//	private float actualPrice;
	
	
	public float getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(float discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public float getRewardsPrice() {
		return rewardsPrice;
	}

	public void setRewardsPrice(float rewardsPrice) {
		this.rewardsPrice = rewardsPrice;
	}
	public long getBid() {
		return bid;
	}

	public void setBid(long bid) {
		this.bid = bid;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public UserInfo getUser() {
		return user;
	}

	public void setUser(UserInfo user) {
		this.user = user;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public boolean isActions() {
		return actions;
	}

	public void setActions(boolean actions) {
		this.actions = actions;
	}

	public BasketStatus getBasketStatus() {
		return basketStatus;
	}

	public void setBasketStatus(BasketStatus basketStatus) {
		this.basketStatus = basketStatus;
	}


	public boolean isPurchase() {
		return purchase;
	}

	public ProductKiosk getProductKiosk() {
		return productKiosk;
	}

	public void setProductKiosk(ProductKiosk productKiosk) {
		this.productKiosk = productKiosk;
	}

	public void setPurchase(boolean purchase) {
		this.purchase = purchase;
	}

	public boolean isInstock() {
		return instock;
	}

	public void setInstock(boolean instock) {
		this.instock = instock;
	}

	public Rewards getReward() {
		return reward;
	}

	public void setReward(Rewards reward) {
		this.reward = reward;
	}

	/*
	 * public boolean isRewardsUsed() { return rewardsUsed; }
	 * 
	 * public void setRewardsUsed(boolean rewardsUsed) { this.rewardsUsed =
	 * rewardsUsed; }
	 * 
	 * public float getActualPrice() { return actualPrice; }
	 * 
	 * public void setActualPrice(float actualPrice) { this.actualPrice =
	 * actualPrice; }
	 * 
	 * public float getDiscountedPrice() { return discountedPrice; }
	 * 
	 * public void setDiscountedPrice(float discountedPrice) { this.discountedPrice
	 * = discountedPrice; }
//	 */
//
//	public float getRewardsPrice() {
//		return rewardsPrice;
//	}
//
//	public void setRewardsPrice(float rewardsPrice) {
//		this.rewardsPrice = rewardsPrice;
//	}
//
//

	

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	
}
