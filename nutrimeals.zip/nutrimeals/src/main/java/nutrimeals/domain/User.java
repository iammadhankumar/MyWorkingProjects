package nutrimeals.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="tbl_user")
public class User implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long user_id;

	@Column(name="DC_FACEBOOK_ID")
	private String facebook_id;



	@Size(min = 3, max = 80)
	@Column(name="DC_EMAIL", nullable = false)
	private String email;


	@Column(name="DC_FIRSTNAME")
	private String first_name;

	@Column(name="DC_LASTNAME")
	private String last_name;

	@Column(name="DC_PASSWORD")
	private String password;	


	@Column(name="DB_ACTIVE")
	private boolean active;

	@Column(name="DD_CREATED_ON")
	@JsonFormat(pattern="MM-dd-yyyy HH:mm:ss")
	private Date created_on;


	@Column(name="DD_UPDATED_ON")
	@JsonFormat(pattern="MM-dd-yyyy HH:mm:ss")
	private Date updated_on;

	@Column(name="DN_DEVICETOKEN")
	private String deviceToken;

	@Column(name="DN_DEVICETYPE")
	private String deviceType;

	@Column(name="DN_LATITUDE")
	private String latitude;

	@Column(name="DN_LANGITUDE")
	private String langitude;




	public String getLatitude() {
		return latitude;
	}




	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}




	public String getLangitude() {
		return langitude;
	}




	public void setLangitude(String langitude) {
		this.langitude = langitude;
	}




	public String getDeviceType() {
		return deviceType;
	}




	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}




	public String getDeviceToken() {
		return deviceToken;
	}




	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}






	@Column(name="DB_ACTIONS")
	private boolean actions;



	@Column(name="DN_TERMS")
	private boolean termsAndCondition;

	public String getProfileimage() {
		return profileimage;
	}




	public void setProfileimage(String profileimage) {
		this.profileimage = profileimage;
	}

	@Column(name="DN_PROMOTION")
	private boolean promotions;

	@Column(name="DN_PROFILEIMAGE")
	private String profileimage;







	public boolean isTermsAndCondition() {
		return termsAndCondition;
	}




	public void setTermsAndCondition(boolean termsAndCondition) {
		this.termsAndCondition = termsAndCondition;
	}







	public boolean isNotification() {
		return notification;
	}




	public void setNotification(boolean notification) {
		this.notification = notification;
	}


	public Date getUpdated_on() {
		return updated_on;
	}




	public void setUpdated_on(Date updated_on) {
		this.updated_on = updated_on;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Column(name="DC_SECEMAIL" )
	private String secondary_email;


	@OneToOne ( targetEntity = UserType.class, fetch = FetchType.EAGER )
	@JoinColumn (name = "DN_USER_TYPE")
	private UserType userType;




	@Column(name="DC_NOTIFICATION", columnDefinition = "boolean default false")
	private boolean notification;





	public boolean isPromotions() {
		return promotions;
	}




	public void setPromotions(boolean promotions) {
		this.promotions = promotions;
	}



	public User(){
	}









	public long getUser_id() {
		return user_id;
	}

	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}


	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}




	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}	

	public UserType getUserType() {
		return userType;
	}

	public void setUserType(UserType userType) {
		this.userType = userType;
	}

	public boolean isActions() {
		return actions;
	}
	public void setActions(boolean actions) {
		this.actions = actions;
	}	

	public String getFacebook_id() {
		return facebook_id;
	}
	public void setFacebook_id(String facebook_id) {
		this.facebook_id = facebook_id;
	}


	public String getSecondary_email() {
		return secondary_email;
	}

	public void setSecondary_email(String secondary_email) {
		this.secondary_email = secondary_email;
	}





}
