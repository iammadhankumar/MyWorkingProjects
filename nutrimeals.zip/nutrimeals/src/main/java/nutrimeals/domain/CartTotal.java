package nutrimeals.domain;

public class CartTotal {
	
	private double total;
	
	private double Tax;
	
	private double cartSubtotal;
	
	private long count;
	

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public double getTax() {
		return Tax;
	}

	public void setTax(double tax) {
		Tax = tax;
	}

	public double getCartSubtotal() {
		return cartSubtotal;
	}

	public void setCartSubtotal(double cartSubtotal) {
		this.cartSubtotal = cartSubtotal;
	}
	
	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}




}
