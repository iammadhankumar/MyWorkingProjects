package nutrimeals.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="tbl_rewards")
public class Rewards {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DN_ID" , nullable = false )
	private long id;
	
	@Column(name="DN_ACTIVE")
	private boolean active;
	
	@Column(name="DN_REWARDSNAME")
    private String rewardsName;
	
	@Column(name="DN_PARCENTAGE")
	private double percentage;
	
//	@Column(name="DN_REWARD_IMAGE")
//	private String rewardImage;
	
	@Column(name="DN_PROMOCODE")
	private String promoCode;
	
	@Column(name="DN_REWARDS_BARCODE")
	private String barcode;
	
	@Column(name="DD_CREATED_ON")																																																																																																					
	private Date createdOn;
	
	@Column(name="DN_START_DATE")
	private String  startDate;
	
	@Column(name="DN_END_DATE")
	private String  endDate;
	
	@Column(name="DN_PRODUCT_CODE")
	private String productCode;
	
	@Column(name="DN_PRODUCT_NAME")
	private String productName;
	
	@Column(name="DN_MACHINE")
	private String machine;

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getMachine() {
		return machine;
	}

	public void setMachine(String machine) {
		this.machine = machine;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	
	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public String getBarcode() {
		return barcode;
	}

	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}


	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getRewardsName() {
		return rewardsName;
	}

	public void setRewardsName(String rewardsName) {
		this.rewardsName = rewardsName;
	}

	

}
