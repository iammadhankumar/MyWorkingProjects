package nutrimeals.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_nutrition")

public class Nutrition implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID" , nullable = false )
	private long nutritionId;
	
	@Column(name="CALORIES")
	private String calories;
	
	@Column(name="PROTEIN")
	private String protein;
	 
	@Column(name="SODIUM")
	private String sodium;
	
	@Column(name="FAT")
	private String fat;
	
	@Column(name="SATURATED_FAT")
	private String saturatedfat;
	
	@Column(name="CARBS")
	private String carbs;
	
	@Column(name="FIBER")
	private String fiber;
	
	@Column(name="SUGAR")
	private String sugar;

	

	
	public long getNutritionId() {
		return nutritionId;
	}

	public void setNutritionId(long nutritionId) {
		this.nutritionId = nutritionId;
	}

	public String getCalories() {
		return calories;
	}

	public void setCalories(String calories) {
		this.calories = calories;
	}

	public String getProtein() {
		return protein;
	}

	public void setProtein(String protein) {
		this.protein = protein;
	}

	public String getSodium() {
		return sodium;
	}

	public void setSodium(String sodium) {
		this.sodium = sodium;
	}

	public String getFat() {
		return fat;
	}

	public void setFat(String fat) {
		this.fat = fat;
	}

	public String getSaturatedfat() {
		return saturatedfat;
	}

	public void setSaturatedfat(String saturatedfat) {
		this.saturatedfat = saturatedfat;
	}

	public String getCarbs() {
		return carbs;
	}

	public void setCarbs(String carbs) {
		this.carbs = carbs;
	}

	public String getFiber() {
		return fiber;
	}

	public void setFiber(String fiber) {
		this.fiber = fiber;
	}

	public String getSugar() {
		return sugar;
	}

	public void setSugar(String sugar) {
		this.sugar = sugar;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
