package nutrimeals.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import nutrimeals.customdomain.OrderInput;
import nutrimeals.helper.OrderHelper;
import nutrimeals.response.OrderInfo;
import nutrimeals.response.OrderMessage;
import nutrimeals.response.OrderMessages;


@EnableAutoConfiguration
@SpringBootApplication
@RestController
public class OrderController extends AbstractRestHandler {
	
	@Autowired
	OrderHelper orderHelper;

	
	
	@RequestMapping(value = "/placeorder", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody OrderMessage addOrderInfo(@RequestBody OrderInput orderInputObj,final HttpServletRequest request,final HttpServletResponse response) throws Exception 
	{
		return orderHelper.addOrderInfo(orderInputObj, request, response);
		
	}
	
	@RequestMapping(value = "/getorderbyid", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody OrderInfo GetMyOrder(@RequestParam(value="orderId",required=false,defaultValue="0") Long orderId,@RequestParam(value="orderNo",required=false) String orderNo,final HttpServletRequest request, final HttpServletResponse response) throws Exception 
	{
		return orderHelper.GetMyOrder(orderId, orderNo, request, response);
	}
	
	@RequestMapping(value = "/getorderlist", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody OrderMessages GetMyOrderList(@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,final HttpServletRequest request, final HttpServletResponse response) throws Exception 
	{
		return orderHelper.GetMyOrderList(pagenumber, pagerecord, request, response);
		
	}
	
}
