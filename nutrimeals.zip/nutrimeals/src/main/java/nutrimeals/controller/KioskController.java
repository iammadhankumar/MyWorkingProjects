package nutrimeals.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import nutrimeals.customdomain.SignupDomain;
import nutrimeals.helper.KioskHelper;
import nutrimeals.response.KioskMessage;
import nutrimeals.response.ResponseStatus;


@Controller
@SpringBootApplication
@RestController
public class KioskController extends AbstractRestHandler {
	
  @Autowired
  KioskHelper kioskHelper;
	
  
	@RequestMapping(value="/getnearerkiosklocation",method=RequestMethod.GET,produces="application/json")
	public @ResponseBody KioskMessage getNearerKioskLocationDetails(@RequestParam(value="latitude") double latitude,@RequestParam(value="longitude") double longitude,@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletRequest request, HttpServletResponse response)
	{
		return kioskHelper.getNearerKioskLocationDetails(latitude, longitude, pagenumber, pagerecord, request, response);
	}
	
	@RequestMapping(value="/getAllKioskList",method=RequestMethod.GET,produces="application/json")
	public @ResponseBody KioskMessage getAllKioskList(@RequestParam(value="all",required=false,defaultValue="0") int all,@RequestParam(value="sortColumn",required=false,defaultValue="0") int sortColumn,@RequestParam(value="sortType",required=false,defaultValue="0") String sortType, @RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletResponse response)
	{
		return kioskHelper.getAllKioskList(all,sortColumn,sortType,pagenumber, pagerecord, response);
	}
	
	@RequestMapping(value="/updatepreferredlocation",method=RequestMethod.PUT,produces="application/json")
	public @ResponseBody ResponseStatus updateProfile(@RequestBody SignupDomain signupObj,HttpServletRequest request, final HttpServletResponse response) throws Exception
	{
		return kioskHelper.updateProfile(signupObj, request, response);
		
	}


}