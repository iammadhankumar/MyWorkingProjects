package nutrimeals.controller;


import java.util.List;

import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import nutrimeals.customdomain.RewardsInput;
import nutrimeals.helper.AdminHelper;
import nutrimeals.response.ResponseStatus;
import nutrimeals.response.RewardCalculation;
import nutrimeals.response.RewardMessage;
import nutrimeals.response.RewardMessages;
import nutrimeals.response.UserMessage;
import nutrimeals.response.UserMessages;
import nutrimeals.customdomain.signupCustomDomain;
import nutrimeals.customdomain.KioskInput;

@EnableAutoConfiguration
@SpringBootApplication
@RestController
@MultipartConfig(maxFileSize = 1024 * 1024 * 1024, maxRequestSize = 1024 * 1024 * 1024)
public class AdminController {


	@Autowired
	AdminHelper adminHelper;




	
	@RequestMapping(value = "/viewusers", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody UserMessages viewUsers(@RequestParam(value="stat",required=false) int stat,final HttpServletResponse response) 
	{
		return adminHelper.viewUsers(stat, response);
			
	}
	
	@RequestMapping(value="/userDetails",method=RequestMethod.POST, produces="application/json")
	public @ResponseBody UserMessage viewProfile(@FormParam("email") String email,final HttpServletResponse response)
	{
		return adminHelper.viewProfile(email, response);
		
	}

	@RequestMapping(value = "/getrewardslist", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody RewardMessages getRewardList(
			@RequestParam(value = "all", required = false, defaultValue = "0") int all,
			@RequestParam(value = "pagenumber", required = false, defaultValue = "0") int pagenumber,
			@RequestParam(value = "pagerecord", required = false, defaultValue = "0") int pagerecord,
			HttpServletRequest request, HttpServletResponse response)
	{
		
		return adminHelper.getRewardList(all,pagenumber, pagerecord, request);
	}


	@RequestMapping(value = "/getrewardsbyid", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody RewardMessage getRewardById(@RequestParam(value = "rewardId") long rewardId,HttpServletRequest request, HttpServletResponse response) 
	{
		return adminHelper.getRewardById(rewardId, request);
	}


	@RequestMapping(value="/applyrewards",method=RequestMethod.POST,produces="application/json")
	public @ResponseBody RewardCalculation applyrewards(@RequestBody RewardsInput rewardsInputObj,final HttpServletRequest request, HttpServletResponse response)
	{
		return adminHelper.applyrewards(rewardsInputObj, request);
	}

	@RequestMapping(value="/removerewards",method=RequestMethod.DELETE,produces="application/json")
	public @ResponseBody ResponseStatus removerewards(@RequestParam(value="rewardId") long rewardId,@RequestParam(value="bid") List<Long> bid,final HttpServletRequest request, HttpServletResponse response)
	{
		return adminHelper.removerewards(rewardId, bid, request);
	}
	
	@RequestMapping(value="/updatekioskstatus",method=RequestMethod.PUT,produces="application/json")
	public @ResponseBody ResponseStatus updateKioskStatus(@RequestBody KioskInput kioskObj, final HttpServletRequest request,final HttpServletResponse response)
	{
		return adminHelper.updateKioskStatus(kioskObj, request, response);
		
	}
	
	
	@RequestMapping(value="/updaterewardstatus",method=RequestMethod.PUT,produces="application/json")
	public @ResponseBody ResponseStatus updateRewardsStatus(@RequestBody RewardsInput rewardObj, final HttpServletRequest request,final HttpServletResponse response)

	{
		return adminHelper.updateRewardsStatus(rewardObj, request, response);
	}
	
	@RequestMapping(value="/updateuseractivestatus",method=RequestMethod.PUT,produces="application/json")
	public @ResponseBody ResponseStatus updateUserStatus(@RequestBody signupCustomDomain userObj, final HttpServletRequest request,final HttpServletResponse response)
	{
		return adminHelper.updateUserStatus(userObj, request, response);
	}



}


	
	
	
	
	
	
	


