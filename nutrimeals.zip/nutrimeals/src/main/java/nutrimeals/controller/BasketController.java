package nutrimeals.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import nutrimeals.customdomain.AddBasketInput;
import nutrimeals.helper.BasketHelper;
import nutrimeals.response.BasketCountByUserMessage;
import nutrimeals.response.BasketMessage;
import nutrimeals.response.BasketMessages;


@Controller
@EnableAutoConfiguration
@SpringBootApplication
@RestController
public class BasketController extends AbstractRestHandler 
{
	
	@Autowired
	BasketHelper basketHelper;

	@RequestMapping(value="/addtocart",method=RequestMethod.POST,produces="application/json")
	public @ResponseBody BasketMessage addtoCart(@RequestBody AddBasketInput AddBasketInputObj,final HttpServletRequest request, HttpServletResponse response) 
	{
		return basketHelper.addtoCart(AddBasketInputObj, request, response);
		
	}
	
	@RequestMapping(value="/getcartlist",method=RequestMethod.GET,produces="application/json")
	public @ResponseBody BasketMessages getCartList(final HttpServletRequest request, HttpServletResponse response) 
	{
		return basketHelper.getCartList(request, response);
		
	}
	
	@RequestMapping(value="/getcartcountbyuserid",method=RequestMethod.GET,produces="application/json")
	public @ResponseBody BasketCountByUserMessage getBasketCountByUser(final HttpServletRequest request, HttpServletResponse response) 
	{
		return basketHelper.getBasketCountByUser(request, response);
		
	}
	
	@RequestMapping(value="/deletecart",method=RequestMethod.DELETE,produces="application/json")
	public @ResponseBody BasketMessages deleteCart(@RequestParam("bid") long bid,final HttpServletRequest request, HttpServletResponse response)
	{
		return basketHelper.deleteCart(bid, request, response);
		
	}




	
	

	

	
	
	
	

}