package nutrimeals.controller;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.FormParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import nutrimeals.customdomain.SignupDomain;
import nutrimeals.helper.UserHelper;
import nutrimeals.response.ResponseStatus;
import nutrimeals.response.UserInfoMessage;
import nutrimeals.response.UserMessage;


@Controller
@EnableAutoConfiguration
@SpringBootApplication
@RestController
public class UserInfoController {

	@Autowired
	UserHelper userHelper;

	
	@RequestMapping(value="/register",method=RequestMethod.POST,produces="application/json")
	public @ResponseBody UserInfoMessage createUser(@RequestBody SignupDomain signupObj,HttpServletRequest request, final HttpServletResponse response) throws Exception
	{
		return userHelper.createUser(signupObj, request, response);
		
	}
	
	
	@RequestMapping(value="/login", method=RequestMethod.POST,produces="application/json")
	public @ResponseBody UserInfoMessage loginUser(@FormParam("email") String email,@FormParam("password") String password,@FormParam("devicetoken") String deviceToken,@FormParam("devicetype") String deviceType,final HttpServletResponse response)
	{
		return userHelper.loginUser(email, password, deviceToken, deviceType, response);
			
	}
	
	
	@RequestMapping(value="/forgotpassword",method=RequestMethod.POST,produces="application/json")
	public @ResponseBody ResponseStatus forgetPassword(@RequestParam("email") String email,final HttpServletResponse response,final HttpServletRequest request)
	{
		return userHelper.forgetPassword(email, response, request);
		
	}
	

	@RequestMapping(value="/resetpassword",method=RequestMethod.POST,produces="application/json")
	public @ResponseBody UserMessage resetpassword(@RequestParam("email") String email,@RequestParam("newpassword") String newpassword,@RequestParam("confirmpassword") String confirmpassword,@FormParam("verificationCode") String verificationCode,final HttpServletResponse response)
	{
		return userHelper.resetpassword(email,newpassword, confirmpassword, verificationCode, response);
		
	}






	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	}
