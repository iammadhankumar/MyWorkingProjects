package nutrimeals.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import nutrimeals.helper.ProductHelper;
import nutrimeals.response.DietaryPreferenceResponse;
import nutrimeals.response.FavouriteMessage;
import nutrimeals.response.FavouriteMessages;
import nutrimeals.response.ProductMessage;
import nutrimeals.response.ProductMessages;


@Controller
@SpringBootApplication
@EnableAutoConfiguration
@RestController
public class ProductController extends AbstractRestHandler  {
	
   @Autowired
   ProductHelper productHelper;
	
	@RequestMapping(value="/getalldietarypreferencelist",method=RequestMethod.GET,produces="application/json")
	public DietaryPreferenceResponse dietaryPreferenceList(@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,HttpServletRequest request, final HttpServletResponse response) throws Exception 
	{
		return productHelper.dietaryPreferenceList(pagenumber, pagerecord, request, response);
	}
	
	
	@RequestMapping(value="/getproductbyproductid", method=RequestMethod.GET,produces="application/json")
	public @ResponseBody ProductMessages getproductbyproductid(@RequestParam("id") long id,final HttpServletResponse response,HttpServletRequest request)
	{
		return productHelper.getproductbyproductid(id, response, request);
		
	}
	
	@RequestMapping(value="/addtofavourites", method=RequestMethod.POST,produces="application/json")
	public @ResponseBody FavouriteMessages addToFavourites(@RequestParam("id")long id,final HttpServletRequest request,final HttpServletResponse response)
	{
		return productHelper.addToFavourites(id, request, response);
		
	}

	
	@RequestMapping(value="/getfavouritelists", method=RequestMethod.GET,produces="application/json")
	public @ResponseBody FavouriteMessage getFavLists(@RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletRequest request,final HttpServletResponse response)
	{
		return productHelper.getFavLists(pagenumber, pagerecord, request, response);
		
	}
	
	@RequestMapping(value="/getallproductlistbykiosk",method=RequestMethod.GET,produces="application/json")
	public @ResponseBody ProductMessage getAllProducListByKiosk(@RequestParam(value="categoryId",defaultValue="0") long categoryId,@RequestParam(value="searchValue",required=false) String searchValue,@RequestParam(value="kid",required=false,defaultValue="0") long kid, @RequestParam(value="pagenumber",required=false,defaultValue="0") int pagenumber,@RequestParam(value="pagerecord",required=false,defaultValue="0") int pagerecord,final HttpServletRequest request,final HttpServletResponse response)
	{
		return productHelper.getAllProducListByKiosk(categoryId, searchValue, kid, pagenumber, pagerecord, request, response);
		
	}



	

	
	

}
