package nutrimeals.email;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.commons.lang.StringUtils;

import nutrimeals.utils.CommonProperties;
import nutrimeals.utils.IoUtils;

public class EmailConfiguration {
	private static ResourceBundle config = getResourceBundle();

	private static final String BUNDLENAME = "emailConfig";

	private static ResourceBundle getResourceBundle() {
		ResourceBundle bundle = null;
		bundle = ResourceBundle.getBundle(BUNDLENAME);
		return bundle;
	}

	private static String getString(String key) {
		return config.getString(key);
	}

	public boolean isAuth() {
		String isAuthStr = getString("isAuth");

		if("YES".equalsIgnoreCase(isAuthStr)) 
			return true;

		return false;
	}

	public String smtpHost() {
		return getString("smtpHost");
	}

	public int smtpPort() {
		String strPort = getString("smtpPort");
		return Integer.valueOf(strPort).intValue();
	}

	public String smtpUser() {
		return getString("smtpUser");
	}

	public String smtpPassword() {
		return getString("smtpPassword");
	}


	public String getUserServiceEmailAddress() {
		return getString("userServiceEmailAddress");
	}

	//---------------------------------------------

	public String getForgotPasswordSubject() {
		return getString("forgotPassword.subject");
	}

	public String getForgotUsernameSubject() {
		return getString("forgotUsername.subject");
	}

	public String getNewUserSubject() {
		return getString("newUser.subject");
	}

	public String getPromotionAndDiscountSubject() {
		return getString("promotionDiscount.subject");
	}
	public String getOrganizationCreatedSubject() {
		return getString("organizationCreated.subject");
	}

	public String getPdfReportSubject() {
		return getString("sendPdfReport.subject");
	}

	public String getActivateUserSubject() {
		return getString("activateUser.subject");
	}
	public String getRegisterUser() {		
		return getString("newUser_register.subject");
	}

	public String getLoadCardBalanceSubject() {
		return getString("loadCardBalance.subject");
	}
	
	public String getAutoReloadBalance() {
		return getString("autoReloadBalance.subject");
	}


	public static String getCorporateFileName() {
		return getString("cotrporateuser.fileName");
	}
	
	public static String getBannerImage() {
		return getString("bannerImage");
	}
	
	public static String getFacebookLogo() {
		return getString("facebooklogo");
	}

	public String getForgotPasswordEmailMessage(String emailAddress,String firstname,String password,String URL,String logoUrl) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${username}", emailAddress);
		map.put("${firstname}", firstname);
		map.put("${password}", password);
		map.put("${url}", URL);
		map.put("${logoUrl}", logoUrl);
		String messageFile = config.getString("forgotPassword.fileName");
		return readFile(messageFile, map);
	}

	public String getForgotPasswordEmailMessage1(String emailAddress,String password,String URL,String logoUrl,
			String filepathFinal,String firstnameFinal,String imgaePathFinal) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${username}", emailAddress);		
		map.put("${password}", password);
		map.put("${url}", URL);
		map.put("${logoUrl}", logoUrl);
		map.put("${filepathFinal}", filepathFinal);
		map.put("${firstname}", firstnameFinal);
		map.put("${imagepath}", imgaePathFinal);
		String messageFile = config.getString("forgotPassword.fileName");
		return readFile(messageFile, map);
	}

	public String getLoadCardBalanceMessage(String emailAddress,String password,String URL,String logoUrl,String filePathFinal,String firstnameFinal,String amountFinal,String imagelogoFinal) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${username}", emailAddress);		
		map.put("${totalamount}", password);
		map.put("${url}", URL);
		map.put("${logoUrl}", logoUrl);
		map.put("${filePathFinal}", filePathFinal);
		map.put("${firstname}", firstnameFinal);
		map.put("${amount}", amountFinal);
		map.put("${imagepath}", imagelogoFinal);
		String messageFile = config.getString("loadcardBalance.fileName");
		return readFile(messageFile, map);
	}

	public String getForgotUsernameEmailMessage(String firstname,String email,String url) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${username}", email);
		map.put("${firstname}", firstname);
		map.put("${url}", url);
		String messageFile = config.getString("forgotUsername.fileName");
		return readFile(messageFile, map);
	}

	public String getOrganizationEmailForDirector(String orgName, String directorName, String url) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${organization_name}", orgName);
		map.put("${directorname}", directorName);
		map.put("${url}", url);
		String messageFile = config.getString("organization_director.fileName");
		return readFile(messageFile, map);
	}

	public String getNewUserMessage(String firstname, String userName, String pwd,String user_role, String url) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${username}", userName);
		map.put("${pwd}", pwd);
		map.put("${firstname}", firstname);
		map.put("${url}", url);
		map.put("${user_type}", user_role);
		String messageFile = config.getString("newUser.fileName");
		return readFile(messageFile, map);
	}

	public String getNewUserMessage1(String firstname, String url) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();		
		map.put("${firstname}", firstname);
		map.put("${url}", url);		
		String messageFile = config.getString("newUser.fileName");
		return readFile(messageFile, map);
	}

	public String getNewUserVariantMessage(String firstname, String userName, String pwd,String user_role, String org, String url) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${username}", userName);
		map.put("${pwd}", pwd);
		map.put("${firstname}", firstname);
		map.put("${url}", url);
		map.put("${user_type}", user_role);
		map.put("${organization_name}", org);
		String messageFile = config.getString("newVariantUser.fileName");
		return readFile(messageFile, map);
	}

	public String getGeneralEmailMessage(String emailContent,String senderName, String URL, String logoUrl) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${message}", emailContent);
		map.put("${sender}", senderName);
		map.put("${url}", URL);
		map.put("${logoUrl}", logoUrl);
		String messageFile = config.getString("generalEmail.fileName");
		return readFile(messageFile, map);
	}

	public String getPdfReportMessage(String receiverName ,String reportName,String URL,String logoUrl) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${receiverName}", receiverName);
		map.put("${reportName}", reportName);
		map.put("${url}", URL);
		map.put("${logoUrl}", logoUrl);
		String messageFile = reportName;		
		return readFile(messageFile, map);
	}

	//--------------------------------------

	private String readFile(String messageFile, Map<String,String> tokens) throws Exception {
		String filePath = CommonProperties.getBasePath()+CommonProperties.getContextPath()+messageFile;	
		System.out.println("FILE "+filePath);
		try {			
			String message = new IoUtils().read(filePath);
			return replaceTokens(message, tokens);
		} catch (IOException e) {			
			throw new Exception("Serious Error. Error reading " + filePath, e);
		}
	}

	private String replaceTokens(String message, Map<String, String> tokens) {
		for (Iterator<String> iterator = tokens.keySet().iterator(); iterator.hasNext();) {
			String token = (String) iterator.next();
			message = StringUtils.replace(message, token, (String)tokens.get(token));
		}
		return message;
	}
	
	
	public String sentPromotionAndDiscountMail(String email , String firstname,String admin_email,String URL) throws Exception {
		System.out.println("INN EMAIL CONFIG");
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${email}", email);
		map.put("${firstname}", firstname);
		map.put("${url}", URL);
		String messageFile = config.getString("promotion_discounts.fileName");
		return readFile(messageFile, map);
	}

	public String getNewUserActivate(String firstname, String url,String confirmLink,String basepathFinal,String filePath,String companynameFinal,String imagelogoFinal) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${firstname}", firstname);
		map.put("${url}", url);
		map.put("${confirmLink}", confirmLink);	
		map.put("${basepathFinal}", basepathFinal);	
		map.put("${filePath}", filePath);
		map.put("${companyname}", companynameFinal);
		map.put("${imagePath}", imagelogoFinal);
		String messageFile = config.getString("newUser_activate.fileName");
		return readFile(messageFile, map);
	}

	public String getNewUserActivate1(String firstname,String filepath, String url) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${firstname}", firstname);
		map.put("${filepath}", filepath);
		map.put("${url}", url);	
		//map.put("${imagepath}", facebookpathFinal);	
		/*map.put("${twitterpath}", twitterpathFinal);
		map.put("${instragrampath}", instragrampathFinal);	
		map.put("${pinterestpath}", pinterestpathFinal);	*/
		String messageFile = config.getString("newUser_register.fileName");
		return readFile(messageFile, map);
	}

	public String getContactusMailMessage(String Email,String Name, String Subject, String Content) throws Exception {

		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${user_email}", Email);
		map.put("${user_fname}", Name);
		map.put("${user_subject}", Subject);
		map.put("${user_message}", Content);
		String messageFile = config.getString("contactusMail.fileName");
		return readFile(messageFile, map);
	}

	public String getNewUserConfimation(String firstname, String url,String confirmLink, String password,String filePathFinal,String imagelogoFinal) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${firstname}", firstname);
		map.put("${url}", url);
		map.put("${companyname}", confirmLink);
		map.put("${password}", password);
		map.put("${filePathFinal}", filePathFinal);
		map.put("${imagepath}", imagelogoFinal);
		String messageFile = config.getString("compay.fileName");
		return readFile(messageFile, map);
	}

	public String getGiftCardSubject() {	
		return getString("giftCard.subject");
	}	

	public String getSendGiftEmailMessage(String emailAddress,String firstname,String password,String URL,String logoUrl) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${username}", emailAddress);
		map.put("${firstname}", firstname);
		map.put("${password}", password);
		map.put("${url}", URL);
		map.put("${logoUrl}", logoUrl);
		String messageFile = config.getString("giftCard.fileName");
		return readFile(messageFile, map);
	}

	public String sendCompanyActivationMessage(String emailAddress,String firstname,String password,String URL,String logoUrl) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${username}", emailAddress);
		map.put("${firstname}", firstname);
		map.put("${password}", password);
		map.put("${url}", URL);
		map.put("${logoUrl}", logoUrl);
		String messageFile = config.getString("giftCard.fileName");
		return readFile(messageFile, map);
	}

	public String getCompanySubject() {		
		return getString("company.subject");
	}

	public String getFreeGift(String emailAddressFinal, String uRL,
			String logoURL,String filePathFinal,String firstnameFinal,String imagepath,String amountFinal) throws Exception {		
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${username}", emailAddressFinal);		
		map.put("${url}", uRL);
		map.put("${logoUrl}", logoURL);
		map.put("${filePathFinal}", filePathFinal);
		map.put("${firstname}", firstnameFinal);
		map.put("${imagepath}", imagepath);
		map.put("${amount}", amountFinal);
		String messageFile = config.getString("freeGift.fileName");
		return readFile(messageFile, map);
	}

	public String getFreeGiftSubject() {	
		return getString("freeGift.subject");
	}

	public String getBirthdayGift(String emailAddressFinal, String uRL,
			String logoURL,String filePathFinal,String firstnameFinal,String imagepath) throws Exception {			
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${username}", emailAddressFinal);		
		map.put("${url}", uRL);
		map.put("${logoUrl}", logoURL);
		map.put("${filePathFinal}", filePathFinal);
		map.put("${firstname}", firstnameFinal);
		map.put("${imagepath}", imagepath);
		String messageFile = config.getString("birthday.fileName");	
		return readFile(messageFile, map);
	}

	public String getBirthdayGiftSubject() {		
		return getString("birthdayGift.subject");
	}

	public String getGiftCard(String firstnameFinal, String uRL,
			String sendername, String gift_amount,String description, String filename,String filepath,String filepath1,String imagelogo) throws Exception {		
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${recipientname}", firstnameFinal);
		map.put("${url}", uRL);
		map.put("${sendername}", sendername);
		map.put("${gift_amount}", gift_amount);
		map.put("${description}", description);
		map.put("${filepath}", filepath);
		map.put("${filename}", filename);
		map.put("${filepath1}", filepath1);
		map.put("${imagepath}", imagelogo);
		String messageFile = config.getString("giftCard.fileName");
		return readFile(messageFile, map);
	}

	
	
	public String getAutoReloadBalanceMessage(String emailAddress,String password,String URL,String logoUrl,String filePathFinal,String firstnameFinal,String amountFinal,String imagelogoFinal) throws Exception {
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("${username}", emailAddress);		
		map.put("${totalamount}", password);
		map.put("${url}", URL);
		map.put("${logoUrl}", logoUrl);
		map.put("${filePathFinal}", filePathFinal);
		map.put("${firstname}", firstnameFinal);
		map.put("${amount}", amountFinal);
		map.put("${imagepath}", imagelogoFinal);
		String messageFile = config.getString("autoReloadBalance.fileName");
		return readFile(messageFile, map);
	}
}