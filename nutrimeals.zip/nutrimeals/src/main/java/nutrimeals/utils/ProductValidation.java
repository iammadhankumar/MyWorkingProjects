package nutrimeals.utils;

public class ProductValidation {
	
	public static String checkProductFieldsEmpty(String productId,String productName,float price,long productType,String productImage,String productDescription,long quantity)
	{
		if(productId==null || productId.isEmpty())
		{
			return "Product Id Required";
		}
		
		if(productName==null || productName.isEmpty())
		{
			return "productName Required";
		}
		
		if(price>0)
		{
			return "price Required";
		}
		
		if(productName==null || productName.isEmpty())
		{
			return "productName Required";
		}
		
		if(productType>0)
		{
			return "productType Required";
		}
		
		if(productImage==null || productImage.isEmpty())
		{
			return "productImage Required";
		}
		
		if(productDescription==null || productDescription.isEmpty())
		{
			return "productDescription Required";
		}
		
		

		if(quantity>0)
		{
			return "quantity Required";
		}
		
		
		
	return "Success";
		
	}
}
