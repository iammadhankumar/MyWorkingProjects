package nutrimeals.utils;

import java.io.File;
import java.io.Serializable;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import nutrimeals.domain.UserInfo;
import nutrimeals.service.IUserInfoService;



public class CommonUtils implements Serializable {
	
	

	
	@Autowired
	IUserInfoService userInfoservice;
	
	private static final long serialVersionUID = 1L;
	
	
	

    private static final String CHAR_LIST =
               "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";


	private static final Logger log			= Logger.getLogger(CommonUtils.class);

	private static CommonUtils myInstance = null;
	public static CommonUtils getInstance()
	{
		if(myInstance == null)
			myInstance = new CommonUtils();
		return myInstance;
	}

	/**
	 * generate random pwd
	 * pwd contains first 4 digit of input string with 4 random numbers
	 * @param username
	 * @return generated Pwd
	 */
	public String generatePwd(String username)
	{
		String unameSub = username.substring(0, username.length()>4?3:username.length());
		return unameSub+String.valueOf ((int)(Math.random ()*10000));
	}
	
	public static String getBasicAuthHeader(String userId,String password) {
		return "Basic " + base64Encode(userId + ":" + password);
	}
	
	private static String base64Encode(String token) {
		byte[] encodedBytes = Base64.encodeBase64(token.getBytes());
		return new String(encodedBytes, Charset.forName("UTF-8"));
	}

	 private final AtomicLong LAST_TIME_MS = new AtomicLong();
	    public String uniqueCurrentTimeMS() {
	        long now = System.currentTimeMillis();
	        while(true) {
	            long lastTime = LAST_TIME_MS.get();
	            if (lastTime >= now)
	                now = lastTime+1;
	            if (LAST_TIME_MS.compareAndSet(lastTime, now))
	                return String.valueOf(now);
	        }
	    }

	/**
	 * encrypting MD5 hash method
	 * @param pwd
	 * @return encrypted text
	 */
	public String generateEncryptedPwd(String pwd){
		try {
			MessageDigest md5;
			md5 = MessageDigest.getInstance ( "MD5" );
			md5.update ( pwd.getBytes () );
			BigInteger hash = new BigInteger ( 1, md5.digest () );
			return hash.toString ( 16 ) ;
		} catch (Throwable e) {
			log.error("Error While generateEncryptedPwd:"+e);
			return null;
		}
	}



	public UserInfo getUser(final HttpServletRequest request){	
		System.out.println("USER**************");
		if(request != null && request.getUserPrincipal()!= null){
		  Principal principal = request.getUserPrincipal();
		  long user_id = Long.parseLong(principal.getName());
		  System.out.println(principal.getName());
		  UserInfo usc = userInfoservice.getUserById(user_id);
		  System.out.println(usc);
		  return (usc != null)?usc:null;
		} else {
			return null;
		}
	}

    

	public String createExportDirectory(String exportFileLocation, String userId) {
	        exportFileLocation = exportFileLocation + userId + "/";
	        File directory = new File(exportFileLocation);
	        if (!directory.exists())
	            directory.mkdir();
	        return exportFileLocation;
	    }
	   
	   public String randomNumbers() {
           List<Integer> numbers = new ArrayList<>();
           for(int i = 0; i < 10; i++){
               numbers.add(i);
           }



           Collections.shuffle(numbers);



           String result = "";
           for(int i = 0; i < 6; i++){
               result += numbers.get(i).toString();
           }
           
           return result;
       }
	   
	   
	   
	  
}
	
