package nutrimeals.utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class IoUtils {
	
	private int bufferSize = 1024;
	
	public String read(String filePath) throws IOException {
		FileInputStream       inputStream   = new FileInputStream(new File(filePath));
		ByteArrayOutputStream outputStream  = new ByteArrayOutputStream();
		copy(inputStream, outputStream);
		return outputStream.toString();
	}
	
	/**
	 * copy file 
	 * @param inputStream
	 * @param outputStream
	 * @return
	 * @throws IOException
	 */
	public int copy(InputStream inputStream, OutputStream outputStream) throws IOException {
		byte[] buffer = new byte[bufferSize];
		int totalBytesRead = 0;
		int bytesRead      = 0;
		while (-1 != (bytesRead = inputStream.read(buffer))) {
			outputStream.write(buffer, 0, bytesRead);
			totalBytesRead += bytesRead;
		}
		return totalBytesRead;
	}  

}
