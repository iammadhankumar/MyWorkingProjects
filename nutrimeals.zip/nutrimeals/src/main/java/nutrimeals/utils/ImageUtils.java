package nutrimeals.utils;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;

import javax.imageio.ImageIO;

import org.apache.log4j.Logger;

public class ImageUtils implements Serializable {

	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(ImageUtils.class);

	private static ImageUtils myImageInstance = null;
	public static ImageUtils getInstance()
	{
		if(myImageInstance == null)
			myImageInstance = new ImageUtils();
		return myImageInstance;
	}
	
	 
	public static boolean copyImages(String sourcePath,String targetPath,String targetName)
	{
		boolean flag = false;
		BufferedImage image = null;
		try {
			String[] split = sourcePath.split("\\.");
			String ext = split[split.length - 1];
			image = ImageIO.read(new File(sourcePath));
			flag = ImageIO.write(image, ext, new File(targetPath+"/"+targetName));
		} catch (IOException e) {
			log.error("Error While writeImages:"+e);
		}
		finally
		{
			if(image != null)
			{
				image.flush();
			}
		}
		return flag;
	}
}
