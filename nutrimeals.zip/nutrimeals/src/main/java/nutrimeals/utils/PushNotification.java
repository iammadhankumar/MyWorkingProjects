package nutrimeals.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Transactional
public class PushNotification implements IPush{

	protected final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public void pushMessage(String msg, long userID, long badge) {
		// TODO Auto-generated method stub
		
	}


//	@Autowired
//	private DeviceRepository deviceRepo;
//
//	public final static String API_URL_FCM = "https://fcm.googleapis.com/fcm/send";//MessageConstants.FCMURL;	
//
//	@Override
//	public void pushMessage(String msg, long userID, long badge) {
//		User user=null;		 
//		String token = "";
//		try {			
////			user=userRepo.getUserByuserIdAndNotification(userID, true);
//			if (user != null) {
//				long userId = userID;
//			//	DeviceToken dvt  =	userRepo.getDeviceTokenByUserId(userId);
//				if(dvt!=null){
//					token = dvt.getDeviceToken();
//					if(token!=null){							
//						sendMsgs(msg,badge,token);
//					}else{
//						logger.info("cannot find token");
//					}
//				}
//				else{
//					logger.info("device token empty");
//				}
//			}
//			if (user == null) {
//				token = "";
//				msg = "";
//				badge = 0;
//			}
//		} catch (Exception e) {
//			logger.error("pushMessage",e);
//		}
//	}

//	@SuppressWarnings("unchecked")
//	private void sendMsgs(String msg, long badge, String deviceToken) {
//		String token = deviceToken;
//		String SERVER_API_KEY= "AAAAF6Lec-s:APA91bHFeTkvGhuLkKK58vmk4PuJVfdbwQuw_etJY46G7xNlES4uHafFiaOPk7Dj6zvztMKcsfycy6QNmbIZtyyRH8JQdIddQWN7Pw8BuNMTPxJp2tY4kRQw6mFhea9qMpEiRgPmX4_p";//MessageConstants.FCMSERVERAPIKEY;
//		try{			
//			URL url = new URL(API_URL_FCM);
//			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//			conn.setUseCaches(false);
//			conn.setDoInput(true);
//			conn.setDoOutput(true);
//			conn.setRequestMethod("POST");
//			conn.setRequestProperty("Authorization","key="+SERVER_API_KEY);
//			conn.setRequestProperty("Content-Type","application/json");
//			JSONObject json = new JSONObject();
//			JSONObject infonotify = new JSONObject();
//			json.put("to",token.trim());
//			JSONObject info = new JSONObject();
//			info.put("title", "Front Forty"); // Notification title
//			info.put("body", msg);   // Notification Body
//			infonotify.put("message", "message from Front Forty");
//			infonotify.put("priority", "high");
//			json.put("notification", info);
//			json.put("data", infonotify);
//			OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
//			wr.write(json.toString());
//			wr.flush();
//			conn.getInputStream();
//			logger.info ("val::"+json);
//			int responseCode = conn.getResponseCode();
//			if(responseCode==200){
//				BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
//			}else if(responseCode==401){
//				logger.info("unauthorized failed::: ");
//			}else if(responseCode==501){
//				logger.info("token failed::: ");
//			}else if(responseCode==503){
//				logger.info("cannnot send failed::: ");
//			}
//		} catch (IOException e) {
//			logger.error("sendMsgs", e);
//		}catch (Exception e) {
//			logger.error("sendMsgs", e);
//		}
//	}
}