

CREATE OR REPLACE VIEW view_kiosk AS
SELECT
  `k`.`DN_ID`         AS `id`,
  `k`.`DN_ACTIVE`     AS `active`,
  `k`.`DN_KIOSKID`    AS `kioskId`,
  `k`.`DC_KIOSKNAME`  AS `kioskName`,
  `k`.`DN_LATITUDE`   AS `latitude`,
  `k`.`DN_LONGITUDE`  AS `longitude`,
  `k`.`DN_ADDRESS`    AS `address`,
  `k`.`DN_START_TIME` AS `startTime`,
  `k`.`DN_END_TIME`   AS `endTime`
FROM `tbl_kiosk` `k`
ORDER BY `k`.`DC_KIOSKNAME`;

 CREATE OR REPLACE VIEW view_cart AS
SELECT
  `b`.`BID`              AS `bid`,
  `b`.`DN_PRICE`         AS `price`,
  `b`.`DB_ACTIVE`        AS `active`,
  `b`.`DN_PURCHASE`      AS `purchase`,
  `b`.`DN_QUANTITY`      AS `quantity`,
  `b`.`DN_BASKET_STATUS` AS `basketStatus`,
  `b`.`DN_REWARD`        AS `reward`,
  `b`.`DN_REWARDS_USED`  AS `rewardsUsed`,
  `b`.`DN_USER_ID`       AS `userId`,
  `p`.`PRODUCT_NAME`     AS `productName`,
  `p`.`PRICE`            AS `productPrice`,
  `p`.`PRODUCT_IMAGE`    AS `productImage`,
  `k`.`DN_KIOSKID`       AS `kioskId`,
  `k`.`DC_KIOSKNAME`     AS `kioskName`,
  `b`.`DN_PRODUCTKIOSK`  AS `prodKiosk`
FROM (((`tbl_basket` `b`
     JOIN `tbl_product_kiosk` `pk`
       ON ((`b`.`DN_PRODUCTKIOSK` = `pk`.`DN_ID`)))
    JOIN `tbl_products` `p`
      ON ((`pk`.`DN_PRODUCT` = `p`.`DN_ID`)))
   JOIN `tbl_kiosk` `k`
     ON ((`pk`.`DN_KIOSK_ID` = `k`.`DN_ID`)));
     
     
CREATE OR REPLACE VIEW view_orders AS     
     SELECT
  `ob`.`DN_ID`            AS `id`,
  `ob`.`DN_BASKET`        AS `bid`,
  `ob`.`DN_ORDER_ID`      AS `orderId`,
  `o`.`DN_ORDER_BARCODE`  AS `orderBarcode`,
  `o`.`DN_CREATEDON`      AS `createdOn`,
  `o`.`DN_ORDERNO`        AS `orderNo`,
  `o`.`DN_USER_ID`        AS `userId`,
  `o`.`DN_PRICE`          AS `price`,
  `o`.`DN_PURCHASESTATUS` AS `purchaseStatus`,
  `o`.`DN_TRANSACTION_ID` AS `transactionId`,
  `b`.`DN_QUANTITY`       AS `quantity`,
  `b`.`DN_PRICE`          AS `basketPrice`,
  `p`.`PRODUCT_NAME`      AS `productName`,
  `p`.`PRICE`             AS `productPrice`,
  `pk`.`DN_PRODUCT`       AS `productid`
FROM ((((`tbl_order_basket` `ob`
      JOIN `tbl_order` `o`
        ON ((`ob`.`DN_ORDER_ID` = `o`.`DN_ID`)))
     JOIN `tbl_basket` `b`
       ON ((`ob`.`DN_BASKET` = `b`.`BID`)))
    JOIN `tbl_product_kiosk` `pk`
      ON ((`pk`.`DN_ID` = `b`.`DN_PRODUCTKIOSK`)))
   JOIN `tbl_products` `p`
     ON ((`pk`.`DN_PRODUCT` = `p`.`DN_ID`)))
ORDER BY `ob`.`DN_ID`;



CREATE OR REPLACE VIEW view_products AS
SELECT
  `pk`.`DN_ID`                AS `pkey`,
  `p`.`DN_ID`                 AS `id`,
  `p`.`PRICE`                 AS `price`,
  `p`.`PRODUCT_DESCRIPTION`   AS `productDescription`,
  `p`.`PRODUCT_ID`            AS `productId`,
  `p`.`PRODUCT_IMAGE`         AS `productImage`,
  `p`.`PRODUCT_NAME`          AS `productName`,
  `p`.`DC_PREPARATION_METHOD` AS `preparationMethod`,
  `p`.`DC_ALL_INGREDIENTS`    AS `allIngredients`,
  `p`.`DN_NUTRITION`          AS `nutritionId`,
  `p`.`DN_PRODUCT_TYPE`       AS `productType`,
  `n`.`CALORIES`              AS `calories`,
  `n`.`FAT`                   AS `fat`,
  `n`.`FIBER`                 AS `fiber`,
  `n`.`PROTEIN`               AS `protein`,
  `n`.`SODIUM`                AS `sodium`,
  `n`.`SUGAR`                 AS `sugar`,
  `pk`.`DN_PRODUCT_QUANTITY`  AS `stockQuantity`,
  `pk`.`DN_KIOSK_ID`          AS `kid`
FROM ((`tbl_products` `p`
    LEFT JOIN `tbl_product_kiosk` `pk`
      ON ((`pk`.`DN_PRODUCT` = `p`.`DN_ID`)))
   LEFT JOIN `tbl_nutrition` `n`
     ON ((`p`.`DN_NUTRITION` = `n`.`ID`)))
ORDER BY `pk`.`DN_ID`;