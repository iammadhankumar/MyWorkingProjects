package nutrimeals;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import javax.ws.rs.core.MediaType;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

public class KioskListTest extends NutrimealsApplicationTests {
	
	
private static final Logger logger = LogManager.getLogger(KioskListTest.class);

	
	@Autowired
    private WebApplicationContext webApplicationContext;
	
   
    private MockMvc mockMvc;



    @Before
    public void setup() {
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();

    }

	
    @Test 
    public void checkRegistationpersistance() {
    	
    	//System.out.println("access token "+checkLogin());
        try {
            MvcResult requestResult = mockMvc.perform(get("/getAllKioskList")
                      .contentType(MediaType.APPLICATION_JSON)
                      .accept(MediaType.APPLICATION_JSON))
                      .andReturn();
        
            Assert.assertNotNull(requestResult);
            Assert.assertNotNull(requestResult.getResponse());
            Assert.assertNotNull(requestResult.getResponse().getContentAsString());
            Assert.assertNotEquals("", requestResult.getResponse().getContentAsString());
            logger.info(requestResult.getResponse().getContentAsString());
            System.out.println("fmdkf"+requestResult.getResponse().getContentAsString());
            
        } catch (Exception e) {
            logger.error("",e);
        }
    }
//    
//    public String checkLogin() {
//    	String token = null;
//    	JSONObject json1=null;
//        try {
//        	HashMap<String,String> input = new HashMap<>();
//        	         input.put("email", "madhan@yopmail.com");
//        	         input.put("password", "madhan@123");
//                      MvcResult requestResult = mockMvc.perform(post("/login").content(getDataString(input))
//                      .contentType(MediaType.APPLICATION_FORM_URLENCODED)
//                      .accept(MediaType.APPLICATION_JSON))
//                      .andReturn();
//        
//            Assert.assertNotNull(requestResult);
//            Assert.assertNotNull(requestResult.getResponse());
//            Assert.assertNotNull(requestResult.getResponse().getContentAsString());
//            Assert.assertNotEquals("", requestResult.getResponse().getContentAsString());
//     
//        JSONParser parser = new JSONParser();
//		json1 = (JSONObject) parser.parse(requestResult.getResponse().getContentAsString());
//		if(json1 != null)
//		{
//		JSONObject json2 = (JSONObject) json1.get("token");
//		token = json2.get("access_token").toString();
//		System.out.println("tk  "+token);
//		}
//        } catch (Exception e) {
//            logger.error("",e);
//        }
//		return token;
//    }
// 
//	public String getDataString(HashMap<String, String> params) throws UnsupportedEncodingException{
//		StringBuilder result = new StringBuilder();
//		boolean first = true;
//		System.out.println(params);
//		for(Map.Entry<String, String> entry : params.entrySet()){
//			if (first)
//				first = false;
//			else
//				System.out.println(entry.getKey());
//			result.append("&");    
//			result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
//			result.append("=");
//			result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
//		}    
//		return result.toString();
//	}
}
