package nutrimeals;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import javax.ws.rs.core.MediaType;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;


public class DeitaryListTest extends NutrimealsApplicationTests {
	
	private static final Logger logger = LogManager.getLogger(DeitaryListTest.class);

	
	@Autowired
    private WebApplicationContext webApplicationContext;
    
    private MockMvc mockMvc;

 

    @Before
    public void setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

 

    @Test 
    public void checkRegistationpersistance() {
        try {
            MvcResult requestResult = mockMvc.perform(get("/getalldietarypreferencelist")
                      .contentType(MediaType.APPLICATION_JSON)
                      .accept(MediaType.APPLICATION_JSON))
                      .andReturn();
        
            Assert.assertNotNull(requestResult);
            Assert.assertNotNull(requestResult.getResponse());
            Assert.assertNotNull(requestResult.getResponse().getContentAsString());
            Assert.assertNotEquals("", requestResult.getResponse().getContentAsString());
            logger.info(requestResult.getResponse().getContentAsString());
            
        } catch (Exception e) {
            logger.error("",e);
        }
    }

}
